<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['appID']	= '523217764450475';
$config['appSecret']	= '9a83e5923ef35b329508854e8362cde5';
/* End of file facebook.php */
/* Location: ./application/config/facebook.php */
