<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class users extends CI_Controller {

	public function __construct(){
		
		parent::__construct();
		//$this->load->model("page_model");
		$this->load->model('user_model');
		$this->load->model('email_model');
		$this->load->model('products_model');
	}
	
	//home menu 
    public function menu(){
		$this->common->is_logged_in();
	    $data["item"]="Menu";
		$data["master_title"] = $this->config->item("sitename")." - Menu"; 
		$data["master_body"]="menu";
		$this->load->theme('mainlayout',$data);
	}
	
	
	//my page 
    public function my_page(){
		$this->common->is_logged_in();
	    $data["item"]="My page";
		$id = $this->session->userdata("userid");
		$data["userdata"] = $this->user_model->getIndividualUserData($id);
		$data["master_title"] = $this->config->item("sitename")." - My page";
		//debug($this->session->userdata("userid"));die; 
		$data["master_body"]="my_page";
		$this->load->theme('mainlayout',$data);
	}
	
	//invite friend
    public function invite_friend(){
		$this->common->is_logged_in();
	    $data["item"]="Invite friend";
		$data["master_title"] = $this->config->item("sitename")." - Invite friend"; 
		$data["master_body"] = "invite_friend";
		$this->load->theme('mainlayout',$data);
	}
	//information by admin
    public function information(){
		$this->common->is_logged_in();
	    $data["item"] = "Information";
		$data["master_title"] = $this->config->item("sitename")." - Information"; 
		$data["master_body"] = "information";
		$this->load->theme('mainlayout',$data);
	}
	
	
	 public function order_list(){
		$this->common->is_logged_in();
	    $data["item"] = "Order list";
		$data["master_title"] = $this->config->item("sitename")." - Order list"; 
		$data["master_body"] = "order_list";
		$this->load->theme('mainlayout',$data);
	}
	
	public function profile(){
		$this->common->is_logged_in();
	    $data["item"]="Address/profile";
		$data["link"] = 'active';
		$userid = $this->session->userdata("userid");
		$data["address_data"] = $this->user_model->get_address($userid);
		//debug($data["address_data"]);die;
		$data["master_title"] = $this->config->item("sitename")." - Address/profile";  
		$data["master_body"]="profile";
		$this->load->theme('mainlayout',$data);
	}
	
	
	public function add_address(){
		//$this->common->is_logged_in();
	    $data["item"]="Address";
		$data["link"] = 'active';
		$data["addressdata"] = $this->session->userdata("tempdata");
		$data["master_title"] = $this->config->item("sitename")." - Address";  
		$data["master_body"]="add_address";
		$this->load->theme('mainlayout',$data);
	}
	public function address_edited(){
		$this->common->is_logged_in();
	    $data["item"]="Address edit";
		$data["link"] = 'active';
		$userid = $this->session->userdata("userid");
		$data["address_edit"] = $this->user_model->get_address($userid);
		$data["master_title"] = $this->config->item("sitename")." - Address edit";  
		$data["master_body"]="address_edited";
		$this->load->theme('mainlayout',$data);
	}
	public function delete_address(){
		$id = $this->uri->segment(3);
		$del = $this->user_model->delete_address($id);
		echo json_encode($del);die;
	}
	public function delete_favorite(){
		$id = $this->uri->segment(3);
		$del = $this->user_model->delete_favorite($id);
		echo json_encode($del);die;
	}
	
	public function favorite(){
		$this->common->is_logged_in();
	    $data["item"]="Favorite";
		$data["link"] = 'active';
		$data["master_title"] = $this->config->item("sitename")." - Favorite";  
		$data["master_body"]="favorite";
		$this->load->theme('mainlayout',$data);
	}
	public function forgot_password(){
		$user = $this->session->userdata("userid");
		if(empty($user)){
			$data["item"]="Forgot Password";
			$data["link"] = 'active';
			$data["forgot"] = $this->session->userdata("tempdata");
			$data["master_title"] = $this->config->item("sitename")." - Forgot Password";  
			$data["master_body"]="forgot_password";
			$this->load->theme('mainlayout',$data);
		}
		else{
			redirect(base_url()."users/my_page");
		}
	}
	
	public function password_reset(){
		$user = $this->session->userdata("userid");
		if(empty($user)){
			$data["item"]="Password reset";
			$data["link"] = 'active';
			$data["master_title"] = $this->config->item("sitename")." - Password reset";  
			$data["master_body"]="password_reset";
			$this->load->theme('mainlayout',$data);
		}
		else{
			redirect(base_url()."users/my_page");
		}
	}
	
	
	public function password_setting(){
		$user = $this->session->userdata("userid");
		if(empty($user)){
			$data["userid"] = base64_decode($this->input->get("id"));
			$data["item"]="Password setting";
			$data["link"] = 'active';
			$data["password_setting"] = $this->session->userdata("tempdata");
			$data["master_title"] = $this->config->item("sitename")." - Password setting";  
			$data["master_body"]="password_setting";
			$this->load->theme('mainlayout',$data);
		}
		else{
			redirect(base_url()."users/my_page");
		}
	}

	public function password_reset_complete(){
		$user = $this->session->userdata("userid");
		if(empty($user)){
			$data["item"]="Password setting";
			$data["link"] = 'active';
			$data["signin"] = $this->session->userdata("tempdata");
			$data["master_title"] = $this->config->item("sitename")." - Password setting";  
			$data["master_body"]="password_reset_complete";
			$this->load->theme('mainlayout',$data);
			}
		else{
			redirect(base_url()."users/my_page");
		}
	}
	public function add_favorite(){
		$id = $this->uri->segment(3);
		$data = $this->user_model->add_favorite($id);
		if($data){
			$result = $data;
		}
		else{
			$result='error';
		}
		echo json_encode($result);die;
	}
	
	public function add_address_to_database(){
		
		$arr["id"] = $this->input->post("id");
		$arr["zip"] = trim($this->input->post("zip"));
		$arr["name"] = trim(mysql_real_escape_string($this->input->post("name")));
		$arr["phone"] = trim($this->input->post("phone"));
		$arr["email"] = trim(mysql_real_escape_string($this->input->post("email")));
		$arr["city"] = trim(mysql_real_escape_string($this->input->post("city")));
		$arr["apartment"] = trim(mysql_real_escape_string($this->input->post("apartment")));
		$arr["userid"] = $this->session->userdata("userid");
		
		if($arr["id"]==""){
			$arr["status"] = 1;
			$arr["created_time"] = time();
		}
		else{
			$arr["updated_time"] = time();
		}
		/*debug($arr);
		die;*/
		$data["addressdata"] = $this->session->set_userdata("tempdata",$arr);

			if($this->validations->validate_add_address($arr)){
				
				if($this->user_model->add_edit_address($arr)){
					$this->session->unset_userdata('tempdata');
					//redirect(base_url().$this->router->class."/password_reset_complete");
				}	
				else
				{
					$this->session->set_flashdata("errormsg","There is a problem updating new address,please contact admin");
					$err=1;
				}
				redirect(base_url().$this->router->class."/profile");
			}
			else{
				$err=1;
				redirect(base_url().$this->router->class."/add_address");
			}
	}
	public function forgot_password_email(){
		
		$arr["id"]="";
		$arr["email"] = trim($this->input->post("email"));
		$this->session->set_userdata("tempdata",$arr);
			if($this->validations->validate_forgot_password($arr)){
				$result=array();
				if($result = $this->user_model->forgot_password($arr)){
					$emailarr["to"] = $arr["email"];
					$emailarr['subject'] = "Your Forgotten Password is \n";
					
     			    $emailarr["message"] = "<p>Dear user</p>
				    <p>Your Password information as:</p>
					<p>Please click on the link below to reset your profile password</p>
					<p>".base_url()."users/password_setting/?id=".base64_encode($result["id"])."</p>
				    <p>Using the password, if you still not able to login into your account then contact our support</p>
				    <p>Email: ".$this->config->item('adminemail')."</p>
				    <p>Best Regards <br/>
				    ".$this->config->item('sitename')."</p>";
					//debug($emailarr);die;
					$this->email_model->sendIndividualEmail($emailarr); 
					$err=0;
					$this->session->set_flashdata("successmsg","Your password has been sent to your email. please check inbox.");
					$this->session->unset_userdata('tempdata');
					redirect(base_url().$this->router->class."/password_reset");
				}	
				else
				{
					$this->session->set_flashdata("errormsg","No such email exists in our database");
					$err=1;
				}
				redirect(base_url().$this->router->class."/forgot_password");
			}
			else{
				$err=1;
				redirect(base_url().$this->router->class."/forgot_password");
			}
	}
	
	public function reset_password(){
		
		//$id = base64_decode($this->uri->segment(3));
		$arr["id"] = base64_encode($this->input->post("id"));
		$arr["password"] = trim($this->input->post("password"));
		
		/*debug($arr);
		die;*/
		$this->session->set_userdata("tempdata",$arr);

			if($this->validations->validate_reset_password($arr)){
				$result=array();
				if($result = $this->user_model->reset_password($arr)){
					$this->session->unset_userdata('tempdata');
					redirect(base_url().$this->router->class."/password_reset_complete");
				}	
				else
				{
					$this->session->set_flashdata("errormsg","There is a problem updating new password contact admin");
					$err=1;
				}
				redirect(base_url().$this->router->class."/password_setting/?id=".$arr["id"]);
			}
			else{
				$err=1;
				redirect(base_url().$this->router->class."/password_setting/?id=".$arr["id"]);
			}
	}
	
	public function logins_check_user_login()
	{
		$login["email"] = trim(mysql_real_escape_string($this->input->post("email")));	
		$login["password"] = trim(mysql_real_escape_string($this->input->post("password")));
		$data["userdata"] = $this->session->set_userdata("tempdata",$login);
				
		if($this->common->authenticateUserLogin($login))
		{
				if($this->session->userdata('user_type') == 'buyer'){
					redirect(base_url()."products/brand_purchase");
			}
			else{
				redirect(base_url()."home/");
			}
		}
		else
		{	
			redirect(base_url()."users/signin");
		}
	}
	public function bank(){
	  $this->common->is_logged_in();
	  $userid = $this->session->userdata("userid");
	  $data["address_data"] = $this->user_model->get_address($userid);
	  $data['useraccounts']=$this->user_model->getuser_bank_accounts($userid);
	  $data["item"]="Bank Accounts";
	  $data["link"] = 'active';
	  $data["addressdata"] = $this->session->userdata("tempdata");
	  $data["master_title"] = $this->config->item("sitename")." - Bank Accounts";  
	  $data["master_body"]="my_banks";
	  $this->load->theme('mainlayout',$data);
 }
 
 public function add_bank(){
	  $this->common->is_logged_in();
	  $data["item"]="Add Bank Account";
	  $data["link"] = 'active';
	  $data["bankdata"] = $this->session->userdata("tempdata");
	  $data["master_title"] = $this->config->item("sitename")." - Add Bank Account";  
	  $data["master_body"]="add_bank";
	  $this->load->theme('mainlayout',$data);
 }
 
 public function add_bank_to_database(){
  //ebug($arr);die;
  
  $arr["id"] = trim($this->input->post("id"));
  $arr["bank_name"] = trim($this->input->post("bank_name"));
  $arr["bank_code"] = trim($this->input->post("bank_code"));
  $arr["bank_branch"] = trim(mysql_real_escape_string($this->input->post("bank_branch")));
  $arr["account_number"] = trim($this->input->post("account_number"));
  $arr["account_type"] = trim(mysql_real_escape_string($this->input->post("account_type")));
  $arr["userid"] = $this->session->userdata("userid");
  $arr["created_time"] = time();
  
  $data["bankdata"] = $this->session->set_userdata("tempdata",$arr);

   if($this->validations->validate_add_bank($arr)){
    
    if($this->user_model->add_edit_bank($arr)){
     	$this->session->unset_userdata('tempdata');
    } 
    else{
     	$this->session->set_flashdata("errormsg","There is a problem updating new bank,please contact admin");
     	$err=1;
    }
    redirect(base_url().$this->router->class."/bank");
   }
   else{
    	$err=1;
    	redirect(base_url().$this->router->class."/add_bank");
  	 }
 }
 
 public function remove_bank(){
  	$id = $this->uri->segment(3);
 	 if($this->user_model->remove_bank($id)){
  		echo 'success';die;}
  	 else{
  		echo 'error';die;
	 }
 }


 public function newsletter(){
 
   if($this->session->userdata("userid")!=="") {
   		$status = $this->uri->segment(3);
   		$id = $this->session->userdata("userid");
   		if($this->user_model->newsletters($status,$id)){
		    echo '1'; die;
    	}
  	}
  	else{
  		echo '0';die;
  	}
  }
 public function push_nottification(){
 
	  if($this->session->userdata("userid")!==""){
		$status = $this->uri->segment(3);
		$id = $this->session->userdata("userid");
		if($this->user_model->push_nottification($status,$id)){
			echo '1'; die;
		}
	  }
	  else {
		echo '0';die;
	  }
  }
}
