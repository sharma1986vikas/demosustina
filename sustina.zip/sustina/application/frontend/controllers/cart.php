<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class cart extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('user_agent');
		$this->load->model('products_model');
		$this->load->model('cart_model');
	}
		
	public function index()
	{
		$this->add_cart();	
	}
	
	public function mycart()
	{
		$data["do"] = "add";
		$data["item"] = "My cart";
		$data["cartdata"] = $this->cart_model->mycart();
		$data["master_title"] = $this->config->item("sitename")." | My cart";   // Please enter the title of page......
		$data["master_body"] = "mycart";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
	}
	
	public function add_cart()
	{
		$arr["cart_id"] = $this->input->post("cart_id");
		$arr["product_id"] = $this->input->post("product_id");
		$arr["category_id"] = $this->input->post("category_id");
		$arr["subcategory_id"] = $this->input->post("subcategory_id");
		$arr["color_id"] = $this->input->post("color_id");
		$arr["size_id"] = $this->input->post("size_id");
		$arr["condition"] = $this->input->post("condition");
		$arr["price"] = $this->input->post("price");
		$arr["discount"] = $this->input->post("discount");
		$arr["shipping"] = $this->input->post("shipping");
		$arr["tax"] = $this->input->post("tax");
		$arr["created_on"] = time();
		$arr["ip"] = $this->input->ip_address();
		$arr["browser"] = $this->agent->browser();
		$arr["status"] =1;

		$userid = $this->session->userdata("userid");
		if(!empty($userid)){
			$arr["userid"] = $userid;
			$arr["type"] = 'user';
		}
		else{
			$arr["userid"] = 1;
			$arr["type"] = 'guest';
		}
		
		//debug($arr);die;
		$this->session->set_flashdata("tempdata",$arr);	
	    /*if($this->validations->validate_property($arr))
		{
		*/	 if($this->cart_model->add_edit_cart($arr)){
				$err=0;	
				$this->session->set_flashdata("successmsg","Product added succesfully");
			}
			else{
				$err=1;
				$this->session->set_flashdata("errormsg","There was error in adding this Product.");
			}
			if($err==0){
				redirect(base_url()."cart/mycart/");
			}
			else if($err==1){
				redirect(base_url()."cart/add_cart/");
			}
			else if($err==2){
				redirect(base_url()."cart/add_cart/");
			}
		/*}
		else
		{
			
			if(empty($arr["cart_id"]))
		    {
				redirect(base_url()."products/add_property/".$arr["attribute_relation"]);
			}
			else
			{
				  redirect(base_url()."products/edit_property/".$arr["attribute_id"]);
			}
		}*/
		
	}
	
	public function delete_cart_item(){
		$id = $this->uri->segment(3);
		$del = $this->cart_model->delete_cart_item($id);
		echo $del;die;
	}
	
}