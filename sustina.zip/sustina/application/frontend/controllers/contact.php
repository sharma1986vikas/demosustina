<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class contact extends CI_Controller {

	public function __construct(){
		
		parent::__construct();
		//$this->load->model('user_model');
		$this->load->model('contact_model');
	}
	////////////////site landing page //////////////////	
	public function index(){
		$this->send_request();
	}
	public function send_request(){
		$this->common->is_logged_in();
		$data["item"] = "Contact";
		$data["master_title"] = $this->config->item("sitename")."- Contact";  
		$data["master_body"] = "contact";
		$userid = $this->session->userdata("userid");
		$data["show_conversation"] = $this->contact_model->show_conversation($userid);
		
		$this->load->theme('mainlayout',$data);
		if($this->uri->segment(3) != '' && $this->uri->segment(3)=='0')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/send_request");
		}
	}
	
	
	public function add_request(){
		$arr["sender"] = $this->session->userdata("userid");
		$arr["receiver"] = 2;
		$arr["message"]  = trim(mysql_real_escape_string($this->input->post("message")));
		$arr["created_on"] = time();
		$arr["status"] = 1;
		if($this->validations->validate_send_request($arr)){
			if($this->contact_model->add_send_request($arr)){
				$err=0;	
				$this->session->set_flashdata("successmsg","Your message has been sent succesfully");
			}
			else
			{
				$err=1;
				$this->session->set_flashdata("errormsg","There was error sending this message");
			}
			if($err==0){
				redirect(base_url().$this->router->class."/send_request/0");
			}
			else if($err==1){
				redirect(base_url().$this->router->class."/send_request/1");
			}
		}
		else{
			if($arr["id"] == ""){
				redirect(base_url().$this->router->class."/send_request");
			}
			else{
			}
		}
	}
}