<div class="header "> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1>Address</h1>
</div>
<div class="container">
  <div class="main_container">
    <div class="middle-container">
        <div class="txt-confirmation" style=" position:absolute; top: 40px;float:left; font-family: 'Open Sans', sans-serif;" id="message"> <font color='red'><?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font> </div>

      <div class="email-textbox-container">
      <form method="post" action="<?php echo base_url();?>users/add_address_to_database">
        <input type="text" class="email-textbox boder_b" name="zip" value="<?php echo $addressdata["zip"];?>" placeholder="zip" />
        <input type="text" class="email-textbox boder_b" name="name" value="<?php echo $addressdata["name"];?>"  placeholder="Name"  />
        <input type="text" class="email-textbox boder_b" name="phone" value="<?php echo $addressdata["phone"];?>"   placeholder="Phone number"  />
        <input type="text" class="email-textbox boder_b" name="email" value="<?php echo $addressdata["email"];?>"  placeholder="E-mail"  />
        <input type="text" class="email-textbox boder_b" name="city" value="<?php echo $addressdata["city"];?>"   placeholder="City"  />
        <input type="text" class="email-textbox" name="apartment" value="<?php echo $addressdata["apartment"];?>"  placeholder="Apartment"  />
        <button type="submit" class="email-signup_btn" name="facebook">Save and Use</button>
        </form>
      </div>
    </div>
  </div>
</div>
