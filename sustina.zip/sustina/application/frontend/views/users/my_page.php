<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1>My page</h1>
</div>
<!------------------main-------------------------->
<div class="main_container">
  <div class="container">
    <div class="main_content_container2">
      <div class="rate-container"> <span>coupon</span>
        <h2>$7300</h2>
      </div>
      <div class="discount">
        <div class="txt-discount-left">20% OFF Coupon</div>
        <div class="txt-discount-right">2014/11/14</div>
      </div>
      <div class="discount">
        <div class="txt-discount-left">15% OFF Coupon</div>
        <div class="txt-discount-right">2014/11/14</div>
      </div>
      <div class="discount">
        <div class="txt-discount-left">10% OFF Coupon</div>
        <div class="txt-discount-right">2014/11/14</div>
      </div>
      <div class="discount border_b">
        <div class="txt-discount-left">$100 Coupon (73)</div>
        <div class="txt-discount-right">2014/11/14</div>
      </div>
      <div class="mypage_information_container"> <a class="mypage_information" href="<?php echo base_url();?>users/information">
        <div class="mypage_information-left">Information </div>
        <div class="menu_count">2</div>
        </a> <a class="mypage_information" href="#">
        <div class="mypage_information-left">Purchase request </div>
        <div class="menu_count">2</div>
        </a> <a class="mypage_information" href="<?php echo base_url();?>users/order_list">
        <div class="mypage_information-left">Order list</div>
        </a> <a class="mypage_information" href="<?php echo base_url();?>users/profile">
        <div class="mypage_information-left">Address/Profile</div>
        </a> <a class="mypage_information" href="">
        <div class="mypage_information-left">Credit card information</div>
        </a> <a class="mypage_information" href="<?php echo base_url();?>users/bank">
        <div class="mypage_information-left">Transfer account</div>
        </a>
        <div class="mypage_information padding_t">
          <div class="mypage_information-left">
            <p>Newsletter</p>
          </div>
          <form>
            <?php if($userdata['news_letters']==1){?>
            <input type="checkbox" data-role="flipswitch" name="flip-checkbox-1" id="flip-checkbox-1"  value="0" class="newslleter" onchange="newsletter();" checked="checked">
            <?php }else{?>
            <input type="checkbox" data-role="flipswitch" name="flip-checkbox-1" id="flip-checkbox-1"  value="1" class="newslleter" onchange="newsletter();" >
            <?php }?>
          </form>
        </div>
      </div>
      <div class="mypage_information  padding_t">
        <div class="mypage_information-left">
          <p>Push Notifications</p>
        </div>
        <form>
          <?php if($userdata['push_nottifications']==1){?>
          <input type="checkbox" data-role="flipswitch" name="flip-checkbox-1" id="flip-checkbox-1"  value="0" class="push" onchange="push_nottification();" checked="checked">
          <?php }else{?>
          <input type="checkbox" data-role="flipswitch" name="flip-checkbox-1" id="flip-checkbox-1"  value="1" class="push" onchange="push_nottification();" >
          <?php }?>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<link href="<?php echo base_url();?>css/jquery.mobile-1.4.2.min.css" rel="stylesheet" type="text/css"/>
<script src="<?php echo base_url();?>js/jquery.js"></script> 
<script src="<?php echo base_url();?>js/jquery.mobile-1.4.2.min.js"></script> 
<script type="text/javascript">
var BASEURL= '<?php echo base_url();?>';
function newsletter()
{

	 var status =$('.newslleter').val();
	     $.ajax({
		 
				url:BASEURL+'users/newsletter/'+status,
				success:function(rep)
				  { 
				   if(rep == 1)
				   {
				     if(status==0)
					   {
						$('.newslleter').val(1);
						}
						else{
						$('.newslleter').val(0);
						}
					}
				  }
				
		 });
	
}
function push_nottification()
{
	 var status1 =$('.push').val();
	  $.ajax({
		     url:BASEURL+'users/push_nottification/'+status1,
				success:function(rep)
				  { 
				   if(rep == 1)
				   {
				     if(status1==0)
					   {
						$('.push').val(1);
						}
						else{
						$('.push').val(0);
						}
					}
				  }
				
		 });
	
}
</script> 
