<div class="header "> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1>Information</h1>
</div>

<div class="container">
  <div class="main_container">
    <div class="middle-container">
      <div class="favorite_main">
      
      <?php 
	  $information = $this->user_model->get_user_information();
	  if(count($information) > 0){
	  foreach($information as $k =>$v)
	  {?>
       <a href="javascript:void(0);" class="information">
        <p> <strong><?php echo $v["information_name"];?></strong><br />
          <?php echo $v["information_description"];?> <br />
          <?php echo date('Y/m/d h:i',$v["information_time"]);?></p>
        </a>
        <?php }}else{?>
        <p><strong> No information found</strong></p>
        <?php }?>
         <!--<a href="#" class="information">
        <p> <strong>Please check the amount of money assessment completed, the purchase</strong><br />
          Assessment amount will be &#165; 4,400. <br />
          2014/8/1 14:00 </p>
        </a>-->
        
        <!--<div class="information bg_none">
          <p> <strong>10% off further time-limited sale, list price!</strong> </p>
        </div>
        <div class="information bg_none">
          <p> <strong>10% off further time-limited sale, list price!</strong> </p>
        </div>
-->      </div>
    </div>
  </div>
</div>
<?php //$this->common->empty_field();?>