<div class="header "> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1><?php echo $item;?></h1>
</div>
<div class="container">
  <div class="main_container">
    <div class="middle-container">
      <div class="txt-confirmation"> <font color='red'><?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font> </div>
      <div class="email-textbox-container">
        <form method="post" action="<?php echo base_url();?>users/add_bank_to_database">
          <input class="email-textbox transfer_account boder_b margin_t" type="text" name="bank_name" value="<?php echo $bankdata["bank_name"];?>" placeholder="Bank Name"  />
          <input class="email-textbox transfer_account" type="text" name="bank_code" value="<?php echo $bankdata["bank_code"];?>" placeholder="Bank code"  />
          <a class="txt-password-forget" href="#">You do not know Bank code? You can check here.</a>
          <input class="email-textbox transfer_account boder_b margin_t" type="text" name="bank_branch" value="<?php echo $bankdata["bank_branch"];?>" placeholder="Branch number"  />
          <input class="email-textbox transfer_account" type="text" name="account_number" value="<?php echo $bankdata["account_number"];?>" placeholder="Account number"  />
          <div class="transfer_account_label_main">
            <div class="transfer_account_label border_n">
              <label>Normal account
                <input type="radio" value="1" class="check_box" name="account_type" <?php if($bankdata["account_type"]==1){echo "checked=checked";}?>/>
              </label>
            </div>
            <div class="transfer_account_label ">
              <label>Other account
                <input type="radio" value="2" class="check_box" name="account_type" <?php if($bankdata["account_type"]==2){echo "checked=checked";}?>/>
              </label>
            </div>
          </div>
          <input type="submit" class="email-signup_btn" name="facebook" value="Save" style="cursor:pointer;">
        </form>
      </div>
    </div>
  </div>
</div>
