
<div class="header "> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1 class="margin_r"><?php echo $item;?></h1>
  <a href="<?php echo base_url();?>users/address_edited" class="header_cart">Edit</a> </div>
<div class="container">
  <div class="main_container">
    <div class="middle-container">
      <div class="favorite_main">
        
        <?php if(count($address_data) > 0){
		 foreach($address_data as $key =>$val){ 
	   ?>
       <div id="del_<?php echo $val["id"];?>"  class="cart-item-container shipment">
          <div class="cart-item-left"> <?php echo $val["zip"]?><br />
            <?php echo $val["name"]?><br />
            <?php echo $val["phone"]?><br />
            <?php echo $val["apartment"]?><br />
           </div>
           <div class="cart-item-right"><a href="javascript:void(0);" onclick="return delete_address('<?php echo $val['id'];?>');">
            <p>Delete</p>
            </a></div>
             </div>
          <?php }}?>   
          
       
        <a href="<?php echo base_url();?>users/add_address" class="information">
        <p> Add new address </p>
        </a> </div>
    </div>
  </div>
</div>
<script  type="text/javascript" src="<?php echo base_url();?>js/jsfunctions.js"></script>
