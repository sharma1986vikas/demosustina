
<div class="header "> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1 class="margin_r">Address/profile</h1>
  <a href="" class="header_cart">Done</a> </div>
<div class="container">
  <div class="main_container">
    <div class="middle-container">
      <div class="favorite_main">
        
        <?php if(count($address_edit) > 0){
		 foreach($address_edit as $key =>$val){ 
	   ?>
       <div id="del_<?php echo $val["id"];?>"  class="cart-item-container shipment">
          <div class="cart-item-left"> <?php echo $val["zip"]?><br />
            <?php echo $val["name"]?><br />
            <?php echo $val["phone"]?><br />
            <?php echo $val["apartment"]?><br />
           </div>
           <div class="cart-item-right"><a href="javascript:void(0);" onclick="return delete_address('<?php echo $val['id'];?>');">
            <p>Delete</p>
            </a></div>
             </div>
          <?php }}?>   
          
       
        <a href="<?php echo base_url();?>users/add_address" class="information">
        <p> Add new address </p>
        </a> </div>
    </div>
  </div>
</div>
