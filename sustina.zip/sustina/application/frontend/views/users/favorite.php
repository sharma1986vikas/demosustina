<div class="header "> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1 class="margin_r"><?php echo $item;?></h1> </div>

<!------------------main-------------------------->
<div class="container">
  <div class="main_container">
    <div class="middle-container">
      <div class="favorite_main">
        <?php 	   
		 $fav = $this->user_model->get_myfavorite_product();
        if(count($fav) > 0){
			$i=1;foreach($fav as $k => $v){
			$val = $this->products_model->get_product_detail($v["product_id"]);
			$default_image = $this->products_model->get_default_image($v["product_id"]);
		?>
        <div id="del_<?php echo $v["id"];?>" class="cart-item-container">
          <div class="cart-item-left">
            <div class="cart-item-left-lft"><img src="<?php if($default_image <>""){ echo $this->config->item("productimageurl").$default_image;}else{echo $this->config->item("default_productimage");}?>" width="127" height="167" /></div>
            <div class="cart-item-left-ryt">
              <p><?php echo $val['title'];?><br />
                <?php echo $this->common->get_category_name($val['category']);?></p>
              <h3>$<?php echo number_format($val['price'],2);?></h3>
            </div>
          </div>
          <div class="cart-item-right"><a href="javascript:void(0);"  onclick="return delete_favorite('<?php echo $v['id'];?>');">
            <p>Delete</p>
            </a></div>
        </div>
        <?php $i++;}}else{?>
        <div class="cart-item-container">
          <div class="cart-item-left">
            <div class="cart-item-left-ryt">
              <h3>No product found in your favorite list</h3>
            </div>
          </div>
          
        </div>
        <?php }?>
      </div>
    </div>
  </div>
</div>
<script  type="text/javascript" src="<?php echo base_url();?>js/jsfunctions.js"></script>
