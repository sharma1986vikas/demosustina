<div class="header "> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1 class="margin_r">Order list</h1>
  <a href="" class="header_cart margin_r"><img src="<?php echo base_url();?>images/mypage_edit.png" /></a> </div>
<div class="container">
  <div class="main_container">
    <div class="middle-container">
      <div class="favorite_main order">
        <div class="cart-item-container">
          <div class="cart-item-left">
            <div class="cart-item-left-lft"><img src="<?php echo base_url();?>images/cart-item-img.jpg" /></div>
            <div class="cart-item-left-ryt">
              <p>Waiting for shipment <br />
                2014/03/09 14:00</p>
              <h3>$6,510</h3>
            </div>
          </div>
        </div>
        <div class="cart-item-container">
          <div class="cart-item-left">
            <div class="cart-item-left-lft"><img src="<?php echo base_url();?>images/cart-item-img.jpg" /></div>
            <div class="cart-item-left-ryt">
              <p>Shipped<br />
                2014/03/01 11:00</p>
              <h3>$6,510</h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
