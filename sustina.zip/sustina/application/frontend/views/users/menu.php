
<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1>Menu</h1>
</div>
<!---------------main----------------->
<div class="main_container">
  <div class="container">
    <div class="main_content_container"> <a href="<?php echo base_url();?>users/invite_friend">
      <div class="menu_btn"><span><img src="<?php echo base_url();?>images/menu_hrt.jpg" /></span>Invite Friends
        <div class="menu_count">2</div>
      </div>
      </a>
      <div class="menu_btn_row2">
        <div class="menu_btn_row2-left"> <a href="<?php echo base_url();?>">
          <div class="menu_btn_row2-left-content">Store</div>
          </a> </div>
        <div class="menu_btn_row2-right"> <a href="<?php echo base_url();?>home/sell_cloth">
          <div class="menu_btn_row2-right-content">Sell Cloths</div>
          </a> </div>
      </div>
      <a href="<?php echo base_url();?>users/my_page">
      <div class="menu_btn position_c"><span class="img_size"><img src="<?php echo base_url();?>images/menu_row3_img.jpg" /></span>
        <div class="clear"></div>
        My Page
        <div class="menu_count">2</div>
      </div>
      </a> <a href="<?php echo base_url();?>users/favorite">
      <div class="menu_btn"><span><img src="<?php echo base_url();?>images/menu_hrt.jpg" /></span>Favarite</div>
      </a> <a href="<?php echo base_url();?>search/">
      <div class="menu_btn"><span><img src="<?php echo base_url();?>images/menu_search.jpg" /></span>Search</div>
      </a> <a href="<?php echo base_url();?>">
      <div class="menu_btn2"><span><img src="<?php echo base_url();?>images/menu_setting.jpg" /></span>Other/Setting</div>
      </a> </div>
  </div>
</div>

<!---------------main-----------------> 
