<?php echo $this->cart_model->cron_cart();?>

<div class="main_container">
  <div class="middle-container">
    <p class="cart-top-txt">Your selected item(s) will be deleted from the cart in 18 minutes left.</p>
    <?php $mycart = $this->cart_model->mycart();
	
	if(count($mycart) !=0){
		$total=0;
		$i=1;foreach($mycart as $k =>$v){
			$total = $total + $v["price"];
			$default_image = $this->products_model->get_default_image($v["product_id"]);
	?>
    <div class="cart-item-container" id="del_<?php echo $v["cart_id"];?>">
      <div class="cart-item-left">
        <div class="cart-item-left-lft"><img src="<?php if($default_image <>""){ echo $this->config->item("productimageurl").$default_image;}else{echo $this->config->item("default_productimage");}?>" width="127" height="167"  /></div>
        <div class="cart-item-left-ryt">
          <p><?php echo $this->products_model->get_product_name_byid($v["product_id"]);?><br />
            <?php echo $this->products_model->getCategoryNameFromId($v["category_id"]);?>/ <?php $subcat =  $this->products_model->getIndividualSubCategory($v["subcategory_id"]);echo $subcat["category_name"];?></p>
          <h3>$<?php echo $v["price"];?></h3>
        </div>
      </div>
      <div class="cart-item-right"><a href="javascript:void(0);" onclick="return delete_cart_item('<?php echo $v['cart_id'];?>');"> <p>Delete</p></a></div>
    </div>
    <?php $i++;}}else{?>
        <div class="price-total-left" style="color:red;">Your cart is empty</div>
    <?php }?>
 <?php   if(count($mycart) !=0){?>
    <div class="price-block1">
      <div class="price-total-container">
        <div class="price-total-left">Price total</div>
        <div class="price-total-right">$<?php echo $total;?></div>
      </div>
      <div class="price-total-container1">
        <div class="price-total-left">Coupon use</div>
        <div class="price-total-right1">select</div>
      </div>
      <div class="price-total-container border-bottom1">
        <div class="price-total-left">
          <p>Shipping Charge</p>
          <div class="txt-freeshipping">Free shipping over %4000!</div>
        </div>
        <div class="price-total-right">$650</div>
      </div>
    </div>
    <div class="price-block1">
      <div class="price-total-container">
        <div class="price-total-left">Payment amount</div>
        <div class="price-total-right">$<?php echo $total;?></div>
      </div>
      <div class="price-total-container1	">
        <div class="price-total-left">Payment</div>
        <div class="price-total-right1">input</div>
      </div>
      <div class="price-total-container1 border-bottom1">
        <div class="price-total-left">Address for delivery</div>
        <div class="price-total-right1">input</div>
      </div>
      <input type="submit" class="email-signup_btn" name="facebook" value="Confirm the purchase">
    </div>
    <?php }?>
  </div>
</div>
<script  type="text/javascript" src="<?php echo base_url();?>js/jsfunctions.js"></script>
