
<div class="header">
  <h1 class="margin_r"><?php echo $item;?></h1>
</div>
<div class="main_container">
  <div class="middle-container">
    <div class="txt-confirmation"> Registration is complete. </div>
    <button type="button" class="email-signup_btn" name="facebook">
    <a href="<?php echo base_url();?>/home">Home</a>
    </button>
  </div>
</div>
