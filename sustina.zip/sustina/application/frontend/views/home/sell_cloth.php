<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1 ><?php echo $item;?></h1>
</div>
<div class="main_container">
  <div class="sell_cloth_main">
    <div class="sell_top_links">
      <p><a href="#">Beginner</a></p>
      <p><a href="<?php echo base_url();?>products/pickups">Brands purchase</a></p>
      <p><a href="<?php echo base_url();?>pages/fqs">FAQ</a></p>
    </div>
    <form method="post" name="add" id="add" action="<?php echo base_url();?><?php echo $this->router->class;?>/add_sell_cloth_to_database">
      <div class="middle-container">
        <div class="sell_cloths_title"> Do you sell clothes? <br />
          We will buy at this price</div>
        <div class="txt-confirmation" style="top: 185px;left: 540px;float:left; font-family: 'Open Sans', sans-serif;" id="message"> <font color='red'><?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font> </div>
        <div class="sell_cloth_select_main">
          <div class="sell_cloth_select">
            <?php $category = $this->products_model->get_all_category();?>
            <select name="category_id" id="category_id" class="sell_menu" onChange="get_price_by_category();">
              <option value="">Select Category</option>
              <?php foreach($category as $key =>$val){
			  if($val <> ""){
		  ?>
              <option value="<?php echo $val["id"];?>" <?php if($val["id"] == $selldata["category_id"]){echo 'selected="selected"';}?>><?php echo $val["category_name"];?></option>
              <?php }}?>
            </select>
            <input type="hidden" id="category_id_temp" value="<?php echo $selldata["category_id"];?>">
          </div>
          <div class="sell_cloth_select" id="data_brand">
            <?php $brand = $this->products_model->get_all_brands();?>
            <select id="brand_id" name="brand_id" class="sell_menu" onChange="get_price_by_category();">
              <option value="">Select Brand</option>
              <?php foreach($brand as $key =>$val){
			  if($val <> ""){
		  ?>
              <option value="<?php echo $val["brand_id"];?>" <?php if($val["brand_id"] == $selldata["brand_id"]){echo 'selected="selected"';}?>><?php echo $val["brand_name"];?></option>
              <?php }}?>
            </select>
            <input type="hidden" id="brand_id_temp" value="<?php echo $selldata["brand_id"];?>">
          </div>
          <p>&#165;<span id="data_price_from">0.00</span> - &#165;<span id="data_price_to">0.00</span></p>
          <input type="hidden" name="price_to" id="price_to" value=""/>
          <input type="hidden" name="price_from" id="price_from" value=""/>
        </div>
        <div class="sell_video">
          <div class="index_video">
            <video width="100%" controls>
              <source src="<?php echo base_url();?>images/mov_bbb.mp4" type="video/mp4">
              <source src="images/mov_bbb.ogg" type="video/ogg">
              Your browser does not support the video tag. </video>
          </div>
        </div>
        <div class="sell_description">
          <h1>Please check the checklist</h1>
          <div class="sell_cloth_select_main padding_t"> 
            <!--class="sell_des_content"-->
            <div>
              <input type="checkbox" name="cond1" value="1"  <?php if($selldata["cond1"]==1){echo 'checked="checked"';}?> class="checkbox"/>
              <p>There is no dirt in clothes, no scratches</p>
            </div>
            <div>
              <input type="checkbox" name="cond2" value="1" <?php if($selldata["cond2"]==1){echo 'checked="checked"';}?> class="checkbox"/>
              <p>Clothes in the brand list purchase</p>
            </div>
            <div>
              <input type="checkbox" name="cond3" value="1" <?php if($selldata["cond3"]==1){echo 'checked="checked"';}?> class="checkbox"/>
              <p>1 to 2 weeks to receive payment</p>
            </div>
          </div>
        </div>
        <div class="sell_cloth_select_main check_">
          <label> I agree with the <span><a href="">Terms &amp; Condition</a></span>
            <input type="checkbox"  class="check_box" value="1" name="terms"/>
          </label>
        </div>
        <input type="submit" class="full_w_btn sell_cloths" value="Request a bag"/>
        <!-- <h1>Search</h1>
      </a>-->
        <div class="sell_cloths_note">※ Please check here by persons under the age of 18</div>
      </div>
    </form>
  </div>
</div>
<script  type="text/javascript" src="<?php echo base_url();?>js/jsfunctions.js"></script>
