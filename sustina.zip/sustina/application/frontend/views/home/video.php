<body class="bg">
<div class="index_video bg">
  <video width="100%" controls>
    <source src="<?php echo base_url();?>images/mov_bbb.mp4" type="video/mp4">
    <source src="<?php echo base_url();?>images/mov_bbb.ogg" type="video/ogg">
    Your browser does not support the video tag. </video>
</div>
</body>
