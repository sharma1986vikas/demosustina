<?php //debug($this->session->signup_site("tempdata"));?>

<div class="header">
  <h1 class="margin_r"><?php echo $item;?></h1>
</div>
<div class="main_container">
  <div class="middle-container">
    <div class="txt-confirmation" style="top: 40px; position:absolute; float:left; font-family: 'Open Sans', sans-serif;" id="message"> <font color='red'><?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font> </div>
    <div class="email-textbox-container">
      <form name="add" id="add" method="post" action="<?php echo base_url();?><?php echo $this->router->class;?>/add_user_to_database">
        <input type="hidden" name="referal_code" value="<?php if(!empty($this->session->userdata["tempdata"]["referal_code"])){echo $this->session->userdata["tempdata"]["referal_code"];};?>" />
        <input class="email-textbox" style="border-bottom:none;" type="text" name="email" value="<?php echo $signup_site["email"];?>"  />
        <input class="email-textbox" type="password" name="password" value="<?php echo $signup_site["password"];?>"  />
        <button type="submit" class="email-signup_btn" name="facebook">sign Up</button>
      </form>
    </div>
  </div>
</div>
