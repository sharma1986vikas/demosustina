<div class="header">
  <h1 class="margin_r"><?php echo $item;?></h1>
</div>
<div class="container">
  <div class="main_container">
    <div class="middle-container">
      <div class="txt-confirmation"> We've send you an email address for your confirmation to the email addresss has been your registration.<br />
        <br />
        Please click on the link that are in the email. </div>
    </div>
  </div>
</div>
<?php $this->session->unset_userdata('tempdata');?>
