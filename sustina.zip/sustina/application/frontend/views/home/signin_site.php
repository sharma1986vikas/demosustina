<div class="header">
  <h1 class="margin_r"><?php echo $item;?></h1>
</div>
<div class="container">
<div class="main_container">
<div class="middle-container">
<div class="txt-confirmation" style="top: 40px; position:absolute; float:left; font-family: 'Open Sans', sans-serif;" id="message"> <font color='red'><?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font> </div>
<div class="email-textbox-container">
<form name="add" id="add" method="post" action="<?php echo base_url();?><?php echo $this->router->class;?>/logins_check_user_login">
<input class="email-textbox" style="border-bottom:none;" type="text" name="email" value="<?php echo $signin["email"];?>"  placeholder="E-mail" />
<input class="email-textbox" type="password" name="password" value="<?php echo $signin["password"];?>"  placeholder="Password" />
<a class="txt-password-forget" href="<?php echo base_url();?>users/forgot_password">Password Forgot</a>
<input type="submit" class="email-signup_btn" name="facebook" value="Login">
</div>
</div>
</div>
</div>
<?php $this->common->empty_filed();?>
