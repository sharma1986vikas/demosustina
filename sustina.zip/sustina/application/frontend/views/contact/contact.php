<div class="header "> <a class="toggle_icon" href="<?php echo base_url();?>users/menu">Menu</a>
  <h1 class="margin_r"><?php echo $item;?></h1>
  <a href="javascript:void(0);" class="header_cart margin_r"><img src="<?php echo base_url();?>images/mypage_edit.png" /></a> </div>
<div class="coupon_field contact">
<form method="post" action="<?php echo base_url();?>contact/add_request" id="contact_form">
  <input class="coupon_textfield" type="text" placeholder="Comment" name="message" value="<?php echo !empty($contact["message"]) ? $contact["message"] : "";?>">
  </form>
  <a class="coupon_btn" href="javascript:void(0);"  onClick="return contact_form();">Send</a> </div>
  <div class="txt-confirmation" style=" position:absolute; top: 109px;float:left; font-family: 'Open Sans', sans-serif;" id="message"> <font color='red'><?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font> </div>
<div class="chat_main">
  <?php if(count($show_conversation) > 0){
	$i=0;foreach($show_conversation as $k =>$v){    
  ?>
  <?php if($i%2==0){?>
  <div class="chat_user_side">
    <div class="chat_time">
      <p><?php echo date('Y/m/d',$v["created_on"]);?><br />
        <?php echo date('A h:i',$v["created_on"]);?></p>
    </div>
    <div class="chat_text">
      <p class="triangle-border right"><?php echo stripcslashes($v["message"]);?></p>
    </div>
  </div>
 <?php }else{?> 
  <div class="client_side">
    <div class="chat_client_main">
      <div class="chat_client_img"></div>
      <div class="chat_text">
        <p class="triangle-border left"><?php echo stripcslashes($v["message"]);?></p>
      </div>
    </div>
    <div class="chat_client_time">
      <p><?php echo date('Y/m/d',$v["created_on"]);?><br />
        <?php echo date('A h:i',$v["created_on"]);?></p>
    </div>
  </div>
  <?php }?>
  <?php $i++;}}else{?>
  <div style=" margin: 100px 550px;">No conversation found</div>
  <?php }?>
</div>
<script>
function contact_form(){
	this.document.getElementById("contact_form").submit();
}
</script>