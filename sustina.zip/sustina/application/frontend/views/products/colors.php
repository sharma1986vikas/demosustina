<!--Main content-->

<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1><?php echo $item;?> </h1>
</div>
<div class="container">
  <div class="coupon_main margin_t"> <a href="<?php echo base_url();?>search/search_result">
    <div class="coupon_c border_b">
      <div class="coupon_price"> ALL </div>
    </div>
    </a> </div>
  <div class="brands_main">
    <div class="coupon_c border_b color_main">
      <div class="coupon_price"> White </div>
      <a class="color_box colorbgw" href="<?php echo base_url();?>search/color_search/White"></a> </div>
    <div class="coupon_c border_b color_main">
      <div class="coupon_price"> Black </div>
      <a href="<?php echo base_url();?>search/color_search/Black" class="color_box colorbgb"></a> </div>
    <div class="coupon_c border_b color_main">
      <div class="coupon_price"> Gray </div>
      <a href="<?php echo base_url();?>search/color_search/Gray" class="color_box colorbgg"></a> </div>
    <div class="coupon_c border_b color_main">
      <div class="coupon_price"> Brown </div>
      <a href="<?php echo base_url();?>search/color_search/Brown" class="color_box colorbgbr"></a> </div>
    <div class="coupon_c border_b color_main">
      <div class="coupon_price"> Beige </div>
      <a href="<?php echo base_url();?>search/color_search/Beige" class="color_box colorbgbe"></a> </div>
    <div class="coupon_c border_b color_main">
      <div class="coupon_price"> Green </div>
      <a href="<?php echo base_url();?>search/color_search/Green" class="color_box colorbggr"></a> </div>
    <div class="coupon_c border_b color_main">
      <div class="coupon_price"> Blue </div>
      <a href="<?php echo base_url();?>search/color_search/Blue" class="color_box colorbgbl"></a> </div>
    <div class="coupon_c border_b color_main">
      <div class="coupon_price"> Purple </div>
      <a href="<?php echo base_url();?>search/color_search/Purple" class="color_box colorbgpu"></a> </div>
    <div class="coupon_c border_b color_main">
      <div class="coupon_price"> Yellow </div>
      <a href="<?php echo base_url();?>search/color_search/Yellow" class="color_box colorbgy"></a> </div>
    <div class="coupon_c border_b color_main">
      <div class="coupon_price"> Pink </div>
      <a href="<?php echo base_url();?>search/color_search/Pink" class="color_box colorbgpi"></a> </div>
    <div class="coupon_c border_b color_main">
      <div class="coupon_price"> Red </div>
      <a href="<?php echo base_url();?>search/color_search/Red" class="color_box colorbgre"></a> </div>
    <div class="coupon_c border_b color_main">
      <div class="coupon_price"> Orange </div>
      <a href="<?php echo base_url();?>search/color_search/Orange" class="color_box colorbg0"></a> </div>
    <div class="coupon_c border_b color_main">
      <div class="coupon_price"> Silver </div>
      <a href="<?php echo base_url();?>search/color_search/Silver" class="color_box colorbgsi"></a> </div>
    <div class="coupon_c border_b color_main border_bc">
      <div class="coupon_price"> Gold </div>
      <a href="<?php echo base_url();?>search/color_search/Gold" class="color_box colorbggo"></a> </div>
    <div class="coupon_c border_b color_main border_bc">
      <div class="coupon_price"> Other </div>
      <a href="<?php echo base_url();?>search/color_search/Other" class="color_box colorbgot"></a> </div>
  </div>
</div>

<!--/Main content-->