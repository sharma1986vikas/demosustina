<!--Main content-->

<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1><?php echo $item;?> </h1>
</div>
<div class="container">
  <div class="coupon_main margin_t"> <a href="<?php echo base_url();?>search/search_result">
    <div class="coupon_c">
      <div class="coupon_price"> ALL </div>
    </div>
    </a> <a href="<?php echo base_url();?>search/size_search/free">
    <div class="coupon_c">
      <div class="coupon_price"> FREE </div>
    </div>
    </a> <a href="<?php echo base_url();?>search/size_search/L">
    <div class="coupon_c">
      <div class="coupon_price"> L </div>
    </div>
    </a> <a href="<?php echo base_url();?>search/size_search/M">
    <div class="coupon_c">
      <div class="coupon_price"> M </div>
    </div>
    </a> <a href="<?php echo base_url();?>search/size_search/S">
    <div class="coupon_c border_b">
      <div class="coupon_price"> S </div>
    </div>
    </a> </div>
</div>

<!--/Main content-->