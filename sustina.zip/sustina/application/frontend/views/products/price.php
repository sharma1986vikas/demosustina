
<div class="header">
  <h1 class="margin_r"><?php echo $item;?> </h1>
</div>
<div class="container">
  <div class="main_container">
    <div class="middle-container">
      <div class="email-textbox-container">
        <form action="<?php echo base_url();?>search/price_search" method="post">
          <input class="email-textbox"  type="text" name="price" placeholder="<?php echo $item;?>"  id="price"/>
          <input type="submit" class="email-signup_btn" value="Search" onclick="return check_price();">
        </form>
      </div>
    </div>
  </div>
</div>
<script  type="text/javascript" src="<?php echo base_url();?>js/jsfunctions.js"></script>
