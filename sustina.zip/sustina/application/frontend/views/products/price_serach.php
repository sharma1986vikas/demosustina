<!--Main content-->

<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1><?php echo $item;?> </h1>
</div>
<div class="container">
                	<div class="coupon_main margin_t">                      
                        
                         <a href="<?php echo base_url();?>search/search_result"><div class="coupon_c">
                        	<div class="coupon_price">
                            Normal price and Sale price
                            </div>
                           
                        </div></a>
                        
                        <a href="<?php echo base_url();?>search/price_type/price"><div class="coupon_c">
                        	<div class="coupon_price">
                            Normal price
                            </div>
                            
                        </div></a>
                        
                        
                        <a href="<?php echo base_url();?>search/price_type/sale"><div class="coupon_c border_b">
                        	<div class="coupon_price">
                            Sale price
                            </div>
                            
                        </div></a>
                        
                          
                        
                       
                        
                        
                    </div>
                </div>

<!--/Main content-->