<?php
 //fetch data according to slug name
	    $slug = $this->uri->segment(3);
		$product_data = $this->products_model->get_product_detail_slug($slug);
		//debug($product_data);
		$product_snidel = $this->products_model->get_product_snidel($product_data);
		//debug($product_snidel);
		//get category slug name by id
		$category_slug = $this->products_model->get_categoryslug_byid($product_snidel[0]["category"]);
		$get_total_pdt_like = $this->products_model->get_total_product_likes($product_data["product_id"]);
		
		//get size,color
		$pdt = $this->products_model->get_variations_edit($product_data["product_id"]);
	 	$size = array();
		$color = array();
		foreach($pdt as $k=>$v){
			$size[] = $v["size_id"];
			$color[] = $v["color_id"];
		
		}	
		$size_pdt['size'] = implode(',',$size);
		$color_pdt['color'] = implode(',',$color);
		//debug($size_pdt);
		$pdt_condition = $this->products_model->get_pdt_condition($product_data["product_id"]);
?>

<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1 class="margin_r"><?php echo ucfirst($product_data['title']);?></h1>
  <a href="" class="header_cart margin_r"><img src="<?php echo base_url();?>images/mypage_edit.png"/></a> </div>

<!------------------main-------------------------->
<div class="main_container">
<div class="middle-container">
<div class="blouse-top-box-container">
  <div class="slider_main ">
    <ul class="bxslider">
      <?php foreach($this->products_model->getProductImagesOfProduct($product_data["product_id"]) as $key=>$val)
		 {
		  if($val['image_name']!="")
		  {
		  ?>
      <li><img src="<?php echo $this->config->item("productimageurl");?><?php echo $val['image_name'];?>" alt="<?php echo $val['image_name'];?>" width="127"  height="187" /> </li>
      <?php }} ?>
    </ul>
    <div class="slider_iconbox">
      <div class="cross"></div>
      <div class="title">Share a Friend</div>
      <div class="hr"></div>
      <?php 
	
	//facebook message
$title = "test";
$image =base_url()."productimagesthumbs/".$default_image;
$link = base_url()."products/product_detail/".$product_data['product_slug'];
$text = 'click this link to buy this product';
?>
      <div  class="slider_icon">
<!--      <a href="https://www.facebook.com/dialog/feed?app_id=523217764450475&display=popup&caption=<?php echo $title;?>&link=https://developers.facebook.com/docs/reference/dialogs/&picture=<?php echo $image;?>&name=Facebook%20Dialogs&description=<?php echo $text;?>&redirect_uri=<?php echo $link;?> " target="_blank"><img src="<?php echo base_url();?>images/icon_1.png" width="127" height="167" /></a>
-->
<a href="https://www.facebook.com/dialog/feed?app_id=523217764450475&display=popup&caption=<?php echo $title;?>&link=https%3A%2F%2Fdevelopers.facebook.com%2Fdocs%2F&picture=<?php echo $image;?>&name=Facebook%20Dialogs&description=<?php echo $text;?>&redirect_uri=<?php echo $link;?> " target="_blank"><img src="<?php echo base_url();?>images/icon_1.png"  /></a>
        <p>Facebook</p>
      </div>
      <div  class="slider_icon"><a target="_blank" title="Recruit with Twitter" href="http://twitter.com/share?url=<?php echo $link;?>&text=<?php echo $text;?>"  class="twitter-share-button"   data-lang="en" data-size="large" data-count="none"><img src="<?php echo base_url();?>images/icon_2.png" /></a>
        <p>Twitter</p>
      </div>
      <div  class="slider_icon"><a href="#"><img src="<?php echo base_url();?>images/icon_3.png" /></a>
        <p>Google+</p>
      </div>
      <div class="slider_icon"><a href="https://mixi.jp"><img src="<?php echo base_url();?>images/icon_4.png" /></a>
        <p>mixi</p>
      </div>
    </div>
  </div>
  <div class="blouse-snidel-txt">Name:<?php echo $product_data['title'];?></div>
  <div class="blouse-addcart-container">
    <div class="blouse-addcart-left">
      <p>$ <?php echo number_format($product_data["price"],2);?></p>
    </div>
    <?php //debug($product_data);?>
    <form id="cart_form" method="post" action="<?php echo base_url();?>cart/add_cart">
      <input type="hidden" name="product_id" value="<?php echo $product_data["product_id"];?>" />
      <input type="hidden" name="category_id" value="<?php echo $product_data["category"];?>" />
      <input type="hidden" name="subcategory_id" value="<?php echo $product_data["subcategory"];?>" />
      <input type="hidden" name="color_id" value="<?php echo $color_pdt['color'];?>" />
      <input type="hidden" name="size_id" value="<?php echo $size_pdt['size'];?>" />
      <input type="hidden" name="condition" value="<?php echo $pdt_condition["condition_id"];?>" />
      <input type="hidden" name="price" value="<?php echo $product_data["price"]?>" />
      <!-- <input type="hidden" name="discount" value="<?php ?>" />
    <input type="hidden" name="shipping" value="<?php ?>" />
    <input type="hidden" name="tax" value="<?php ?>" />-->
      
      <?php
	$is_product_added = array();
	$is_product_added = $this->products_model->is_product_added($product_data["product_id"]);
	$class = NULL;
	$txt = NULL;
	$function = NULL;
	if(count($is_product_added) ==0){
		$class = 'blouse-addcart-right';
		$txt = '<p>add to cart</p>';
		$function = 'onclick="return submit_cart();"';
	}
	else if($is_product_added["status"]==2){
		$class = 'blouse-addcart-right3';
		$txt = '<p>Sold Out</p>';
		$function = '';
	}
	else if($is_product_added["status"]==1 && count($is_product_added !=0)){
		$class = 'blouse-addcart-right2';
		$txt = '<p>waiting for<br />a cancellation</p>';
		$function = '';
	}
	
	?>
      <a href="javascript:void(0);" class="<?php echo $class?>" <?php echo $function;?>><?php echo $txt;?></a>
    </form>
  </div>
  <div class="blouse-shared-container"> <a href="#">
    <div class="shared-box shared-border"><span> <img src="<?php echo base_url();?>images/blouse-shared-hrt-img.jpg" /></span><?php echo  $get_total_pdt_like;?></div>
    </a> <a href="#">
    <div class="shared-box shared-border">Line</div>
    </a> <a href="#">
    <div class="shared-box padding_l"><span><img src="<?php echo base_url();?>images/blouse-shared-img.jpg" /></span>Shared</div>
    </a> </div>
  <div class="blouse-product-details">The product details<br />
    Size:<?php echo $this->products_model->get_size_comma_id($size);?><br />
    Color:<?php echo $this->products_model->get_color_comma_id($color);?><br />
    <?php echo $pdt_condition["condition_name"];?><br />
    <?php echo $pdt_condition["condition_description"];?><br />
    <?php echo $product_data["short_description"];?> </div>
  <div class="sbp-style-container sbp-white-bg"> <a href="javscript:void(0);">
    <div class="txt-sbp-style">New Items Snidel</div>
    </a>
    <?php
	 	//debug($product_snidel);
	      if(count($product_snidel) > 0){
		  $i=1;
		   ?>
    <div class="sbp-style-img-container">
      <div class="sbp-style-img-container1">
        <?php 
		   foreach($product_snidel as $key =>$val){
			$default_image = $this->products_model->get_default_image($val["product_id"]);
		    $is_fav_product =  $this->products_model->is_fav_product($val["product_id"]);
			
	       ?>
        <?php if($i%2==0){ $class="sbp-style-img-container1-right";}else{$class="sbp-style-img-container1-left";}?>
        <div class="<?php echo $class;?>"> <a href="<?php echo base_url();?><?php echo $this->router->class;?>/product_detail/<?php echo $val["product_slug"];?>"><img src="<?php if($default_image <>""){ echo $this->config->item("productimageurl").$default_image;}else{echo $this->config->item("default_productimage");}?>" width="127" height="187" /></a>
          <div class="sbp-hrt-container">
            <?php if($is_fav_product == true){?>
            <div class="sbp-hrt-container-left fav"> <a href="javascript:void(0);"> <img src="<?php echo base_url();?>images/sbp-hrt-img2.jpg" /></a>
              <?php }else{?>
              <div id="fav_<?php echo $val["product_id"];?>" class="sbp-hrt-container-left non_fav"> <a onclick="return add_favorite('<?php echo $val["product_id"];?>');" href="javascript:void(0);"> <img src="<?php echo base_url();?>images/sbp-hrt-img.jpg" /></a>
                <?php }?>
              </div>
              <div class="sbp-hrt-container-right">
                <div class="txt-sbp-hrt-container-right"><?php echo $val["title"];?><br />
                  $<?php echo $val["price"];?></div>
              </div>
            </div>
          </div>
          <?php $i++;} ?>
        </div>
      </div>
      <?php }else{?>
      <div  style="color:#F00;"> No Product Found </div>
      <?php }?>
      <?php  if(count($product_snidel) > 0){?>
      <a href="<?php echo base_url();?>search/category_search/<?php echo $category_slug;?>">
      <div class="txt-sbp-style-more">More</div>
      </a>
      <?php }?>
    </div>
    <?php
          //fetch data according to slug name
            $recommended_product = $this->products_model->get_recommended_product_by_allcategory($product_data);
          ?>
    <div class="sbp-style-container sbp-white-bg"> <a href="">
      <div class="txt-sbp-style">Recommended New arrivals</div>
      </a>
      <?php 
		if(count($recommended_product) > 0){
		  $i=1;
		   ?>
      <div class="sbp-style-img-container">
        <div class="sbp-style-img-container1">
          <?php 
		  foreach($recommended_product as $key =>$val){
			$default_image = $this->products_model->get_default_image($val["product_id"]);
			$is_fav_product =  $this->products_model->is_fav_product($val["product_id"]);
	       ?>
          <?php if($i%2==0){ $class="sbp-style-img-container1-right";}else{$class="sbp-style-img-container1-left";}?>
          <div class="<?php echo $class;?>"> <a href="<?php echo base_url();?><?php echo $this->router->class;?>/product_detail/<?php echo $val["product_slug"];?>"><img src="<?php if($default_image <>""){ echo $this->config->item("productimageurl").$default_image;}else{echo $this->config->item("default_productimage");}?>" width="127" height="167" /></a>
            <div class="sbp-hrt-container">
              <?php if($is_fav_product == true){?>
              <div class="sbp-hrt-container-left fav"> <a href="javascript:void(0);"> <img src="<?php echo base_url();?>images/sbp-hrt-img2.jpg" /></a>
                <?php }else{?>
                <div id="fav_<?php echo $val["product_id"];?>" class="sbp-hrt-container-left non_fav"> <a onclick="return add_favorite('<?php echo $val["product_id"];?>');" href="javascript:void(0);"> <img src="<?php echo base_url();?>images/sbp-hrt-img.jpg" /></a>
                  <?php }?>
                </div>
                <div class="sbp-hrt-container-right">
                  <div class="txt-sbp-hrt-container-right"><?php echo $val["title"];?><br />
                    $<?php echo $val["price"];?></div>
                </div>
              </div>
            </div>
            <?php $i++;} ?>
          </div>
        </div>
        <?php }else{?>
        <div  style="color:#F00;"> No Product Found </div>
        <?php }?>
        <?php  if(count($recommended_product) > 0){?>
        <a href="<?php echo base_url();?>products/recommended_products">
        <div class="txt-sbp-style-more">More</div>
        </a>
        <?php }?>
      </div>
      <div class="sbp-style-container sbp-white-bg"> <a href="">
        <div class="txt-sbp-style">Pick up Style</div>
        </a>
        <div class="sbp-style-img-container">
          <div class="sbp-style-img-container1">
            <div class="sbp-style-img-container1-left"><a href=""><img src="<?php echo base_url();?>images/pickstyle-img1.jpg" /></a></div>
            <div class="sbp-style-img-container1-right"><a href=""><img src="<?php echo base_url();?>images/pickstyle-img2.jpg" /></a></div>
          </div>
          <div class="sbp-style-img-container1">
            <div class="sbp-style-img-container1-left"><a href=""><img src="<?php echo base_url();?>images/pickstyle-img1.jpg" /></a></div>
            <div class="sbp-style-img-container1-right"><a href=""><img src="<?php echo base_url();?>images/pickstyle-img2.jpg" /></a></div>
          </div>
        </div>
        <a href="">
        <div class="txt-sbp-style-more">More</div>
        </a> </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url();?>js/jquery.bxslider.js"></script> 
<script type="text/javascript">

function submit_cart(){
	this.document.getElementById("cart_form").submit();
}


$(document).ready(function(){
  $('.bxslider').bxSlider();
});
    </script> 
<script>
	$(document).ready(function(){
	$( ".cross" ).click(function() {
		$( ".slider_iconbox" ).hide( "fast", function() {});
		});
	});
	
	</script> 
