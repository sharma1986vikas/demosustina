<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1 class="margin_r"><?php echo $item;?></h1>
  <a href="" class="header_cart margin_r"><img src="<?php echo base_url();?>images/mypage_edit.png" /></a> </div>
<div class="main_container">
<div class="middle-container">
<a href="<?php echo base_url();?>search/">
<div class="blouse-top-search-box">Search</div>
</a>
<?php 
	if(count($resultset) > 0){?>
<div class="sbp-style-img-container border-none">
<?php $i=0;foreach($resultset as $key =>$val){
		$default_image = $this->products_model->get_default_image($val["product_id"]);
		$is_fav_product =  $this->products_model->is_fav_product($val["product_id"]);
	?>
<?php if($i%2==0){?>
<div class="sbp-style-img-container1">
  <div class="sbp-style-img-container1-left"> <a href="<?php echo base_url();?>products/product_detail/<?php echo $val["product_slug"];?>"><img src="<?php if($default_image <>""){ echo $this->config->item("productimageurl").$default_image;}else{echo $this->config->item("default_productimage");}?>"width="127" height="167" /></a>
    <div class="sbp-hrt-container">
      <?php if($is_fav_product == true){?>
      <div class="sbp-hrt-container-left fav"> <a href="javascript:void(0);"> <img src="<?php echo base_url();?>images/sbp-hrt-img2.jpg" /></a>
        <?php }else{?>
        <div id="fav_<?php echo $val["product_id"];?>" class="sbp-hrt-container-left non_fav"> <a onclick="return add_favorite('<?php echo $val["product_id"];?>');" href="javascript:void(0);"> <img src="<?php echo base_url();?>images/sbp-hrt-img.jpg" /></a>
          <?php }?>
        </div>
        <div class="sbp-hrt-container-right">
          <div class="txt-sbp-hrt-container-right"><?php echo $val["title"];?><br />
            $<?php echo $val["price"];?></div>
        </div>
      </div>
    </div>
    <?php }else{?>
    <div class="sbp-style-img-container1-right"> <a href="<?php echo base_url();?>products/product_detail/<?php echo $val["product_slug"];?>"><img src="<?php if($default_image <>""){ echo $this->config->item("productimageurl").$default_image;}else{echo $this->config->item("default_productimage");}?>" width="127" height="167"/></a>
      <div class="sbp-hrt-container">
        <?php if($is_fav_product == true){?>
        <div class="sbp-hrt-container-left fav"> <a href="javascript:void(0);"> <img src="<?php echo base_url();?>images/sbp-hrt-img2.jpg" /></a>
          <?php }else{?>
          <div id="fav_<?php echo $val["product_id"];?>" class="sbp-hrt-container-left non_fav"> <a onclick="return add_favorite('<?php echo $val["product_id"];?>');" href="javascript:void(0);"> <img src="<?php echo base_url();?>images/sbp-hrt-img.jpg" /></a>
            <?php }?>
          </div>
          <div class="sbp-hrt-container-right">
            <div class="txt-sbp-hrt-container-right"><?php echo $val["title"];?><br />
              $<?php echo $val["price"];?></div>
          </div>
        </div>
      </div>
      <?php }?>
      <?php $i++;}?>
    </div>
    <?php  echo $this->pagination->create_links();?>

    <!--<a href="blouse-search2.html">
    <div class="blouse-nxt-search1">Next</div>
    </a>-->
    <?php }else{?>
    <div style="color:#F00;">No result Found</div>
    <?php }?>
  </div>
</div>
