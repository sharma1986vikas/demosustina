<?php 
class search_model extends CI_Model {
    function __construct()
    {
        parent::__construct();
    }

	//select  categories by slug 
	public function getCategoryBySlug($slug){
		$this->db->select("*");
		$this->db->from('tbl_categories');
		$where=array("parent_category" =>0,"category_status <> "=>4,'slug'=>$slug);
		$this->db->where($where);
		$query = $this->db->get();
		$resultset=$query->row_array();
		return $resultset;		
	}
   //select  categories by slug 
	public function getSubCategoryBySlug($slug){
		$this->db->select("*");
		$this->db->from('tbl_categories');
		$where=array("parent_category <> "=>0,"category_status <> "=>4,'slug'=>$slug);
		$this->db->where($where);
		$query = $this->db->get();
		$resultset=$query->row_array();
		return $resultset;		
	}
   //select barnd by slug 
   	public function getBrandBySlug($slug){
		$this->db->select("*");
		$this->db->from('tbl_brand');
		$where=array("brand_status <> "=>4,'slug'=>$slug);
		$this->db->where($where);
		$query = $this->db->get();
		$resultset=$query->row_array();
		return $resultset;		
	}
  
		
	public function getSearchProductData($searcharray=array())
	{
		
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
		 if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
	
		$sql= "select * from tbl_product ";	
		if(isset($searcharray["brand"]) && $searcharray["brand"]!="")
		{
		$sql.="join tbl_brand on (tbl_product.brand=tbl_brand.brand_id)";
		}
		if((isset($searcharray["color_id"]) && $searcharray["color_id"]!="") || (isset($searcharray["size_id"]) && $searcharray["size_id"]!=""))
		{
		$sql.="join tbl_product_attribute_relation on (tbl_product.product_id=tbl_product_attribute_relation.product_id)";
		}
		$sql.=" where 1=1";
		if(isset($searcharray["price"]) && $searcharray["price"]!="")
		{
		 $sql.= " and tbl_product.price <= '".$searcharray["price"]."'";
		}
		if(isset($searcharray["category"]) && $searcharray["category"]!="")
		{
		  $sql.= "  and  tbl_product.category = '".$searcharray["category"]."'";
		  
		}
		if(isset($searcharray["brand"]) && $searcharray["brand"]!="")
		{
	        $sql.= "  and (tbl_brand.brand_name like '".trim($searcharray["brand"])."%')";
		}
		
		if(isset($searcharray["brand_id"]) && $searcharray["brand_id"]!="")
		{
			$sql.= "  and brand = '".$searcharray["brand_id"]."'";
		}
		if(isset($searcharray["sub_category"]) && $searcharray["sub_category"]!="")
		{
			$sql.= "  and subcategory = '".$searcharray["sub_category"]."'";
		}
		if(isset($searcharray["color_id"]) && $searcharray["color_id"]!="")
		{
		$sql.= " and tbl_product_attribute_relation.color_id = '".$searcharray["color_id"]."'";
		}
		if(isset($searcharray["size_id"]) && $searcharray["size_id"]!="")
		{
		$sql.= " and tbl_product_attribute_relation.size_id = '".$searcharray["size_id"]."'";
		}
		if(isset($searcharray["condition_id"]) && $searcharray["condition_id"]!="")
		{
		$sql.= " and tbl_product.condition = '".$searcharray["condition_id"]."'";
		}
			$sql.= "  and tbl_product.product_status = '1'";
		
		if(isset($searcharray["page"]) && $searcharray["page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$sql.=" limit  $startlimit,$recordperpage";
			}
		}
		$query = $this->db->query($sql);
		$resultset=$query->result_array();
		//echo $this->db->last_query();
		 return $resultset;
	}
	
	public function getKeywordSearchProductData($searcharray=array())
	{
		
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
		 if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
	
		$sql= "select * from tbl_product ";	
		
		$sql.=" where 1=1";
		
		if(isset($searcharray["keyword"]) && $searcharray["keyword"]!="")
		{
	        $sql.= "  and (tbl_product.title like '%".trim($searcharray["keyword"])."%' or tbl_product.short_description like '%".trim($searcharray["keyword"])."%' or  tbl_product.long_description like '%".trim($searcharray["keyword"])."%')";
		}
		$sql.= "  and tbl_product.product_status = '1' order by rand()";
		
		if(isset($searcharray["page"]) && $searcharray["page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$sql.=" limit  $startlimit,$recordperpage";
			}
		}
		
		$query = $this->db->query($sql);
		$resultset=$query->result_array();
		//echo $this->db->last_query();
		 return $resultset;
	}
		
		
	
}
?>