<?php 
ob_start();
class login_model extends CI_Model { 
    function __construct(){
        parent::__construct();
    }
	
	/************************************************* Admin login functions starts **************************************************/	
	public function check_admin_login($arr){
		
		
		$this->db->select("*");
		$this->db->from("admin");
		$this->db->where(array("username" => $arr["username"]));
		$result=$this->db->get();
		//echo $this->db->last_query();die;
		$countrows=$result->num_rows();
		$result=$result->row_array();
		return $result;
		/*$checkarray=array("username"=>$arr["username"],"password"=>$arr["password"]);
		
		$this->db->select("username");
		$this->db->from("admin");
		$this->db->where($checkarray);
		$query=$this->db->get();
		$resultset=$query->row_array();
		//echo $this->db->last_query();
		if(isset($resultset["username"])){
			return $resultset["username"];
		}
		else{
			return "";	
		}*/
	}
	/************************************************* Admin login functions ends **************************************************/
}