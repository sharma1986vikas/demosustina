<?php 

class page_model extends CI_Model {

    function __construct()
    {
        parent::__construct();
    }
	/********************************************************Blog function starts***************************************************/
	public function getPageData($pagename="")

	{
		$this->db->select("*");
		$this->db->from("content_pages");
		$this->db->where(array("page_name"=>$pagename,"page_status"=>"1"));
		$query=$this->db->get();//run query 
		//echo $this->db->last_query();//execute lat query
		$resultset=$query->row_array();
		return $resultset; 
		//echo "<pre>";//print_r($resultset);
	}
	//get conent pages data for front end 
	
	public function get_contact_data($pagename=''){
		$this->db->select("*");
		$this->db->from("content_pages");
		$this->db->where(array("page_name"=>$pagename,"page_status"=>"1"));
		$query=$this->db->get();
		$resultset=$query->row_array();//echo $this->db->last_query();die;
		return $resultset; 
	}
	//update content page data from admin
	public function update_contact_data($arr=array()){
		
		if($_FILES["userfile"]["name"] !=''){
			$this->db->select("*");
			$this->db->from("content_pages");
			$this->db->where("id",$arr["id"]);
			$query = $this->db->get();
			$images = $query->row_array();
			//echo $this->db->last_query();die;
			unlink('../uploads/'.$images['image']);
		}
		$this->db->where("id",$arr["id"]);
		return $this->db->update("content_pages",$arr);	
	}
	
	public function updatepagedata($arr=array()){
		$this->db->where("id",$arr["id"]);
		return $this->db->update("content_pages",$arr);	
	}
	//update about us data for admin
	public function update_aboutus_to_database($arr){
		//print_r($arr);die;
		$this->db->where("page_name",$arr["page_name"]);
		return $this->db->update("content_pages",$arr);	
	}
	
	public function get_blog_data($arr)

	{
		$this->db->select("*");
		$this->db->from("blogs");
		$this->db->where(array("status"=>1));
		$query=$this->db->get();//run query 
		//echo $this->db->last_query();//execute lat query
		$resultset=$query->result_array();
		//echo "<pre>";
		//print_r($resultset);
		return $resultset; 
	}
	
	public function getinformationData($searcharray=array())
	{
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
	    if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
		
		
		$this->db->select("*");
		$this->db->from('tbl_information');
		if(isset($searcharray["search"]) && $searcharray["search"]!="")
		{
			$this->db->like("tbl_information.information_name",trim($searcharray["search"]));	
		}
		$where=array("information_status <>"=>"4");
		$this->db->where($where);
		$this->db->order_by("information_id desc");
		/*if(isset($searcharray["type"]) && $searcharray["type"]=="activated")
		{
			$where=array("status"=>"1");
		}*/
				
		if(isset($searcharray["page"]) && $searcharray["page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$this->db->limit($recordperpage,$startlimit);
			}
		}
		$query = $this->db->get();
	//	echo	$this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;	
	}
	
	public function getmessageData($searcharray=array())
	{
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
	    if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
		$this->db->select_max("id");
		$this->db->select("tbl_contact_request.sender,tbl_contact_request.receiver,tbl_contact_request.conversation,tbl_contact_request.created_on");
		$this->db->from('tbl_contact_request');
		if(isset($searcharray["search"]) && $searcharray["search"]!="")
		{
			$this->db->like("tbl_contact_request.message",trim($searcharray["search"]));	
		}
		$where=array("status <>"=>"4");
		$this->db->where($where);
		$this->db->group_by("conversation");
		$this->db->order_by("id desc");
		/*if(isset($searcharray["type"]) && $searcharray["type"]=="activated")
		{
			$where=array("status"=>"1");
		}*/
				
		if(isset($searcharray["page"]) && $searcharray["page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$this->db->limit($recordperpage,$startlimit);
			}
		}
		$query = $this->db->get();
		//echo	$this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;	
	}
	public function add_edit_information($arr)
	{
		//debug($arr);die;
		if($arr["information_id"]=="")
		{
			return $this->db->insert("tbl_information",$arr);	
		}	
		else
		{
			$this->db->where("information_id",$arr["information_id"]);
			return $this->db->update("tbl_information",$arr);	
		}
	}
	
		public function archive_information($id)
	{
		$where=array("information_id"=>$id);
		$array=array("information_status"=>4);
		$this->db->where($where);
		$this->db->update("tbl_information",$array);		
		
	}
		public function archive_message($id)
	{
		$where=array("conversation"=>$id);
		$array=array("status"=>4);
		$this->db->where($where);
		$this->db->update("tbl_contact_request",$array);		
		
	}
		
	public function enable_disable_information($id,$status)
	{
		$this->db->where("information_id",$id);
		$array=array("information_status"=>$status);
		$this->db->update("tbl_information",$array);		
	}
	//
	
	public function getIndividualinformation($information_id)
	{
		$this->db->select("*");
		$this->db->from("tbl_information");
		$this->db->where(array("information_id" => $information_id,"information_status <> "=>"4"));
		$query = $this->db->get(); 
		//echo $this->db->last_query();die;
		$resultset = $query->row_array();
		return $resultset;
	}
	
	public function view_message($conversation){
		$sql="select *  from( select * from tbl_contact_request where conversation ='".$conversation."' order by id desc) tmp order by tmp.id ASC";
		$query = $this->db->query($sql);
		//echo $this->db->last_query();die;
		$resultset=$query->result_array();
		//print_r($resultset);die;
	    return $resultset;
	}
}

?>