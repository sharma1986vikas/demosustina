<?php 
class contact_model extends CI_Model {
    function __construct()
    {
        parent::__construct();
    }
	
	public function add_send_request($arr = array()){
		
		$arr["conversation"] = $this->contact_model->is_conversation_exists($arr);
		 
		return $this->db->insert("tbl_contact_request",$arr);
	}
	public function is_conversation_exists($arr){
		$this->db->select("conversation");	
		$this->db->from('tbl_contact_request');
		$this->db->where("(sender='$arr[sender]' AND receiver='$arr[receiver]' OR receiver='$arr[sender]'  AND  sender='$arr[receiver]')");
		$query = $this->db->get();
		//echo $this->db->last_query();die;
		$num = $query->num_rows();
		$resultset = $query->row_array();
		if($num !=0){
			$conversation = $resultset["conversation"];
		}
		else{
			$con = $this->common->generate_conversation("tbl_contact_request","conversation",20);
			$conversation = $con;
		}
		return $conversation;
	}
	public function show_conversation($receiver){
		$this->db->select("*");
		$this->db->from("tbl_contact_request");
		$this->db->where("(sender='$receiver' OR receiver='$receiver')");
		$this->db->order_by("id desc");
		$result = $this->db->get();
		//echo $this->db->last_query();die;
		$countrows = $result->num_rows();
		$result = $result->result_array();
		return $result;
	}
	public function view_message($conversation){
		$this->db->select("*");
		$this->db->from("tbl_contact_request");
		$this->db->where(array("conversation " => $conversation));
		$this->db->order_by("id desc");
		$result = $this->db->get();
		//echo $this->db->last_query();die;
		$countrows = $result->num_rows();
		$result = $result->result_array();
		return $result;
	}
	
	public function last_message($sender){
		$this->db->select("message");	
		$this->db->from('tbl_contact_request');
		$this->db->where("(sender='$sender' OR receiver='$sender')");
		$this->db->order_by("id desc");
		$this->db->limit(1,0);
		$query = $this->db->get();
		//echo $this->db->last_query();die;
		$num = $query->num_rows();
		$resultset = $query->row_array();
		$data = strlen($resultset['message']) > 40 ? substr(stripcslashes($resultset['message']), 0,40)." ....." : stripcslashes($resultset['message']);
		return $data;
	}
}