<?php 
class cart_model extends CI_Model {
    function __construct()
    {
        parent::__construct();
    }
	
	public function cron_cart(){
		$this->db->select("*");
		$this->db->from("tbl_cart");
		$this->db->where(array("userid" => $this->session->userdata("userid"),"tbl_cart.status"=> 1));
		$query = $this->db->get();
		//echo $this->db->last_query();die;	
		$resultset = $query->result_array();
		foreach($resultset as $k =>$v){
			$start_time = $v["created_on"];
			$current_time = time();
			$diff = $current_time - $start_time;
			if($diff > 1080){
				$id = $this->db->where("cart_id",$v["cart_id"]);
				return $this->db->delete("tbl_cart",$id);
				// echo $this->db->last_query();die;
			}
			else{
				//echo "hi";die;
			}
		}
	}
	
	public function add_edit_cart($arr)
	{
		
		if($arr["cart_id"]=="")
		{
			return $this->db->insert("tbl_cart",$arr);	
		}	
		else
		{
			$id = $arr["cart_id"];
			unset($arr["cart_id"]);
			$this->db->where("cart_id",$id);
			return $this->db->update("tbl_cart",$arr);
		    //echo $this->db->last_query();die;	
		}
	}
	
	public function mycart(){
		$this->db->select("*");
		$this->db->from("tbl_cart");
		$this->db->where(array("userid" => $this->session->userdata("userid"),"tbl_cart.status"=> 1,"type" => 'user'));
		$query = $this->db->get();
		//echo $this->db->last_query();die;	
		$resultset = $query->result_array();
		return $resultset;
	}
	
	public function delete_cart_item($row_id)
	{
		$where = array("cart_id" => $row_id);
		$this->db->where($where);
		$this->db->delete("tbl_cart");
	}
}