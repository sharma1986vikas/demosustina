<?php 
class validations extends CI_Model {
 
    function __construct()
    {
        parent::__construct();
    }
	//reset password
	public function validate_change_password($arr)
	{
		if($arr["oldpassword"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter Current password");	
			$err=1;	
		}	
		else if($arr["newpassword"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter new password");	
			$err=1;	
		}
		else if(preg_match('/[#$@%^&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/',$arr["newpassword"]))
		{
			$this->session->set_flashdata("errormsg","Spacial characters are not allowed in new password");
			$err=1;	
		}
		else if(strlen($arr["newpassword"]) < 5 || strlen($arr["newpassword"]) > 15)
		{
			$this->session->set_flashdata("errormsg","Your password must be between 5 and 15 characters long ");
			$err=1;	
		}
		else if($arr["confirmnewpassword"]=="")
		{
			$this->session->set_flashdata("errormsg","Please confirm your password");	
			$err=1;	
		}
		else if(preg_match('/[#$@%^&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/',$arr["confirmnewpassword"]))
		{
			$this->session->set_flashdata("errormsg","Spacial characters are not allowed in confirm password");
			$err=1;	
		}
		else if($arr["confirmnewpassword"]!=$arr["newpassword"])
		{
			$this->session->set_flashdata("errormsg","new password and confirm password should match.");	
			$err=1;	
		}
		
		else
		{
			$err=0;	
		}
		if($err==0)
		{
			return true;	
		}
		else
		{
			return false;	
		}
	}
	
	
	/******************************************Profile validation starts ****************************************/
	public function validatepasswords($arr)
	{
		if($arr["oldpassword"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter old password");	
			$err=1;	
		}	
		else if($this->common->checkpasswordvalidity($arr))
		{
			$this->session->set_flashdata("errormsg","Wrong old password");	
			$err=1;	
		}
		else if($arr["newpassword"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter new password");	
			$err=1;	
		}
		else if(preg_match('/[#$@%^&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/',$arr["newpassword"]))
		{
			$this->session->set_flashdata("errormsg","Spacial characters are not allowed in new password");
			$err=1;	
		}
		else if(strlen($arr["newpassword"]) < 5 || strlen($arr["newpassword"]) > 15)
		{
			$this->session->set_flashdata("errormsg","Your password must be between 5 and 15 characters long ");
			$err=1;	
		}
		else if($arr["confirmnewpassword"]=="")
		{
			$this->session->set_flashdata("errormsg","Please confirm your password");	
			$err=1;	
		}
		
		else if($arr["newpassword"]!=$arr["confirmnewpassword"])
		{
			$this->session->set_flashdata("errormsg","Both passwords do not matches");	
			$err=1;	
		}
		else
		{
			$err=0;	
		}
		if($err==0)
		{
			return true;	
		}
		else
		{
			return false;	
		}
	}
	
	public function update_password($arr)
	{
		$err=0;
		if($arr["password"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter your password");
			$err=1;	
		}	
		else if($arr["confirmpassword"]=="")
		{
			$this->session->set_flashdata("errormsg","Please confirm your password");
			$err=1;	
		}
			
		
		if($err==0)
		{
			return true;	
		}
		else
		{
			return false;	
		}
	}

	
	/* signup function start*/
	public function validate_user_data($arr){
		
		   $err=0;
		   /*if($arr["first_name"]=="")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please enter first name");	
			}
			else if(preg_match('/[#$%^&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/',$arr["first_name"]))
			{
				$this->session->set_flashdata("errormsg","Spacial characters are not allowed in first name");
				$err=1;	
			}
			else if($arr["last_name"]=="")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please enter last name");	
			}
			else if(preg_match('/[#@$%^&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/',$arr["last_name"]))
			{
				$this->session->set_flashdata("errormsg","Spacial characters are not allowed in lastname");
				$err=1;	
			}*/
		   if($arr["email"]=="")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please enter Email Id");	
			}
			else if(!$this->common->validate_email($arr["email"]))
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Email should be valid");	
			}
			else if(!$this->common->validate_email_exist($arr))
			{
				$this->session->set_flashdata("errormsg","This email already exists");
				$err=1;	
			}
			/*else if($arr["username"]=="")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please enter username");	
			}
			else if(preg_match('/[#@$%^&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/',$arr["username"]))
			{
				$this->session->set_flashdata("errormsg","Spacial characters are not allowed in username");
				$err=1;	
			}
			else if(!$this->common->validate_username_exist($arr))
			{
				$this->session->set_flashdata("errormsg","This username already exists");
				$err=1;	
			}*/
			else if($arr["password"]=="" && $arr["id"] =="")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please enter password");	
			}
			else if((strlen($arr["password"]) < 5 || strlen($arr["password"]) > 15) && $arr["id"] =="")
			{
				$this->session->set_flashdata("errormsg","Your password must be between 5 and 15 characters long ");
				$err=1;	
			}
			/*else if($arr["cpassword"]=="")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please Enter Confirm password");	
			}
			else if(strlen($arr["cpassword"]) < 6 || strlen($arr["cpassword"]) > 15)
			{
				$this->session->set_flashdata("errormsg","Your password must be between 8 and 15 characters long ");
				$err=1;	
			}
			else if($arr["cpassword"] != $arr["password"])
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Both password did not matches");	
			}
			else if($arr["zip"] == "")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please Enter zip");	
			}
			else if($arr["address"] == "")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please Enter address");	
			}
			else if($arr["phone"] == "")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please Enter phone");	
			}*/
			else {
				$err=0;
			}
			if($err==1)
			{
				return false;	
			}	
			else
			{
				return true;	
			}
			
		}

	public function edit_sign_up($arr){
			
			if($arr["first_name"]=="")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please enter first name");	
			}
			else if(preg_match('/[#$%^&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/',$arr["first_name"]))
			{
				$this->session->set_flashdata("errormsg","Spacial characters are not allowed in first name");
				$err=1;	
			}
			else if($arr["last_name"]=="")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please enter last name");	
			}
			else if(preg_match('/[#@$%^&*()+=\-\[\]\';,.\/{}|":<>?~\\\\]/',$arr["last_name"]))
			{
				$this->session->set_flashdata("errormsg","Spacial characters are not allowed in lastname");
				$err=1;	
			}
			else if($arr["email"]=="")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please enter Email Id");	
			}
			else if(!$this->common->validate_email($arr["email"]))
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Email should be valid");	
			}
			else if(!$this->common->validate_email_exist($arr))
			{
				$this->session->set_flashdata("errormsg","This email  already exists");
				$err=1;	
			}
			else if($arr["password"] !="")
			{
				if(strlen($arr["password"]) < 6 || strlen($arr["password"]) > 15){
					$err=1;	
					$this->session->set_flashdata("errormsg","Your password must be between 6 and 15 characters long ");
				}
			}
			else if($arr["zip"] == "")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please Enter zip");	
			}
			else if($arr["address"] == "")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please Enter address");	
			}
			else if($arr["phone"] == "")
			{
				$err=1;
				$this->session->set_flashdata("errormsg","Please Enter phone");	
			}
			else{
				$err=0;
			}
			if($err==1)
			{
				return false;	
			}	
			else
			{
				return true;	
			}
	}
	//validation for contact us page 
	public function validate_contact_us($arr){
		if($arr["page_title"]==""){
				$err=1;
				$this->session->set_flashdata("errormsg","Please enter title");	
		}
		else if($arr["page_content"]==""){
				$err=1;
				$this->session->set_flashdata("errormsg","Please enter page content");	
		}
		else if($arr["page_content1"]==""){
				$err=1;
				$this->session->set_flashdata("errormsg","Please enter page content 1");	
		}
		else{
			$err=0;
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	
	
	public function validate_aboutus($arr){
		
		/*echo "<pre>";
		print_r($arr);die;*/
		
	   if($arr["page_content"] == ""){
			$this->session->set_flashdata("errormsg","Please enter page content");	
			$err=1;
		}
		else{
			$err=0;	
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	
	public function validate_forgot_password($arr){
		
		/*echo "<pre>";
		print_r($arr);die;*/
		if($arr["email"] == ""){
			$this->session->set_flashdata("errormsg","Please enter email");	
			$err=1;
		}
		else if(!$this->common->validate_email($arr["email"])){
			$err=1;
			$this->session->set_flashdata("errormsg","Email should be valid");	
		}
		else if(!$this->common->validate_forgot_email_exist($arr)){
			$this->session->set_flashdata("errormsg","This email  doesnot  exists in our database");
			$err=1;	
		}
		else{
			$err=0;	
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	
	public function validate_reset_password($arr){
		
		/*echo "<pre>";
		print_r($arr);die;*/
		if($arr["password"] == ""){
			$this->session->set_flashdata("errormsg","Please enter password");	
			$err=1;
		}
		else if(strlen($arr["password"]) < 6 || strlen($arr["password"]) > 15){
					$err=1;	
					$this->session->set_flashdata("errormsg","Your password must be between 6 and 15 characters long ");
				}
		else{
			$err=0;	
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	//slideshow page
	public function validate_slideshow_data($slideshowarray){
		
		
		if($slideshowarray["sld_images"]==""  && $slideshowarray["id"]=="")
		{
			$this->session->set_flashdata("errormsg","Please select image");
			$err=1;		
		}
		else if(isset($slideshowarray["sld_images"]) && $slideshowarray["sld_images"]!="" && !in_array($this->common->get_extension($slideshowarray["sld_images"]),$this->config->item("allowedimages")))
		{
			$this->session->set_flashdata("errormsg","File type is not valid");
			$err=1;	
		}
		else{
			$err=0;
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
			
	}


	public function validate_category($arr){
		
		/*echo "<pre>";
		print_r($arr);
		die;*/
		if($arr["category_name"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter category name");
			$err=1;	
		}
		else if(preg_match('/[$%^&\\[\]\;\{}|"<>?~\\\\]/',$arr["category_name"])){
			$this->session->set_flashdata("errormsg","/.@-',+()#*= spacial characters are not allowed in categoty name.");
			$err=1;	
	    }
		else if(!$this->common->check_category_name($arr)){
			$this->session->set_flashdata("errormsg","This category name already exists in our database");
			$err=1;	
		}
		
		else{
			$err=0;
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	
	public function validate_sub_category($arr)
	{
		if($arr["parent_category"]=="")
		{
			$this->session->set_flashdata("errormsg","Please choose parent category");
			$err=1;		
		}	
		else if($arr["category_name"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter sub category");
			$err=1;		
		}
		else if(!$this->common->check_sub_category_name($arr))
		{
			$this->session->set_flashdata("errormsg","Sub category already exists this category");
			$err=1;	
		}
		else
		{
			$err=0;	
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}	
	}
	
	public function validate_brand($arr){
		
		/*echo "<pre>";
		print_r($arr);
		die;*/
		if($arr["brand_name"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter brand name");
			$err=1;	
		}
		else if(preg_match('/[$%^&\\[\]\;\{}|"<>?~\\\\]/',$arr["brand_name"])){
			$this->session->set_flashdata("errormsg","special characters are not allowed in brand name.");
			$err=1;	
	    }
		else if(!$this->common->check_brand_name($arr)){
			$this->session->set_flashdata("errormsg","This brand name already exists in our database");
			$err=1;	
		}
		
		else{
			$err=0;
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	
	public function validate_product_data($arr){
		
		/*echo "<pre>";
		print_r($arr);
		die;*/
		if($arr["title"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter title");
			$err=1;	
		}
		else if($arr["category"]=="")
		{
			$this->session->set_flashdata("errormsg","Please select category");
			$err=1;	
		}
		else if($arr["subcategory"]=="")
		{
			$this->session->set_flashdata("errormsg","Please select subcategory");
			$err=1;	
		}
		else if($arr["short_description"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter short description");
			$err=1;	
		}
		else if($arr["long_description"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter long description");
			$err=1;	
		}
		else if($arr["brand"]=="")
		{
			$this->session->set_flashdata("errormsg","Please select brand");
			$err=1;	
		}
		else if($arr["price"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter price");
			$err=1;	
		}
		else if(!is_numeric($arr["price"]))
		{
			$this->session->set_flashdata("errormsg","Price should be numeric value only");
			$err=1;	
		}
		else if($arr["condition"]=="")
		{
			$this->session->set_flashdata("errormsg","Please select condition");
			$err=1;	
		}
		else{
			$err=0;
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	
	
	public function validate_property($arr){
		
		
		if($arr["attribute_name"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter property name");
			$err=1;	
		}
		else if(preg_match('/[$%^&\\[\]\;\{}|"<>?~\\\\]/',$arr["attribute_name"])){
			$this->session->set_flashdata("errormsg","special characters are not allowed in property name.");
			$err=1;	
	    }
		else if(!$this->common->check_property_name($arr)){
			$this->session->set_flashdata("errormsg","This property name under this attribute already exists");
			$err=1;	
		}
		
		else{
			$err=0;
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	
	public function validate_price($arr){
		
		/*echo "<pre>";
		print_r($arr);
		die;*/
		if($arr["category_id"]=="")
		{
			$this->session->set_flashdata("errormsg","Please select category name");
			$err=1;	
		}
		else if($arr["brand_id"]=="")
		{
			$this->session->set_flashdata("errormsg","Please select brand name");
			$err=1;	
		}
		else if($arr["price_from"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter  price from");
			$err=1;	
		}
		else if(!is_numeric($arr["price_from"]))
		{
			$this->session->set_flashdata("errormsg","Price should be a numeric value");
			$err=1;	
		}
		else if($arr["price_to"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter price to");
			$err=1;	
		}
		else if(!is_numeric($arr["price_to"]))
		{
			$this->session->set_flashdata("errormsg","Price should be a numeric value");
			$err=1;	
		}
		
		else if(!$this->common->check_price($arr)){
			$this->session->set_flashdata("errormsg","This Price already exists under this category and brand");
			$err=1;	
		}
		else{
			$err=0;
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	public function validate_sell_cloth($arr){
		
		$err=0;
		/*if($arr["category_id"]=="")
		{
			$this->session->set_flashdata("errormsg","Please select category");
			$err=1;	
		}
		else if($arr["brand_id"]=="")
		{
			$this->session->set_flashdata("errormsg","Please select brand");
			$err=1;	
		}*/
		/*else if($arr["sell_price"]=="")
		{
			$this->session->set_flashdata("errormsg","Please select brand or category no price found");
			$err=1;	
		}*/
	 if($arr["cond1"] !=1 && $arr["cond2"]!=1 && $arr["cond3"]!=1)
		{
			$this->session->set_flashdata("errormsg","Please select atleast one condition for selling");
			$err=1;	
		}
		else if($arr["terms"]=="")
		{
			$this->session->set_flashdata("errormsg","Please agree to terms and conditions");
			$err=1;	
		}
		else{
			$err=0;
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	
	public function validate_add_address($arr){
		
		/*echo "<pre>";
		print_r($arr);
		die;*/
		if($arr["zip"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter zip");
			$err=1;	
		}
		else if(preg_match('/[$%^&\\[\]\;\{}|"<>?~\\\\]/',$arr["zip"])){
			$this->session->set_flashdata("errormsg","special characters are not allowed in zip.");
			$err=1;	
	    }
		else if($arr["name"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter name");
			$err=1;	
		}
		else if($arr["phone"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter phone");
			$err=1;	
		}
		else if($arr["email"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter email");
			$err=1;	
		}
		else if(!$this->common->validate_email($arr["email"]))
		{
			$err=1;
			$this->session->set_flashdata("errormsg","Email should be valid");	
		}
		
		else if($arr["city"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter city");
			$err=1;	
		}
		else if($arr["apartment"]=="")
		{
			$this->session->set_flashdata("errormsg","Please enter apartment");
			$err=1;	
		}
		
		else{
			$err=0;
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	
	public function validate_add_referal_code($arr){
		
		
		$err=0;
		
		if($arr["referal_code"] <> "")
		{
		   if(!$this->common->check_referal_code($arr)){
				$this->session->set_flashdata("errormsg","No such referal code exists, wrong information");
				$err=1;	
			}
		}
		else{
			$err=0;
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	public function validate_invite_friend($arr){
		
		$err=0;
		
		if($arr["number"] == "")
		{
		   	$this->session->set_flashdata("errormsg","Please choose number of friends");
			$err=1;	
		}
		else if(!is_numeric($arr["number"]))
		{
		   	$this->session->set_flashdata("errormsg","It should be numeric");
			$err=1;	
		}
		else if($arr["type"] == "")
		{
		   	$this->session->set_flashdata("errormsg","Please select type");
			$err=1;	
		}
		else if($arr["value"] == "")
		{
		   	$this->session->set_flashdata("errormsg","Please enter value");
			$err=1;	
		}
		else if(!is_numeric($arr["value"]))
		{
		   	$this->session->set_flashdata("errormsg","It should be numeric");
			$err=1;	
		}
		else{
			$err=0;
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	public function validate_add_bank($arr){
  
  if($arr["bank_name"]=="")
  {
   $this->session->set_flashdata("errormsg","Please enter bank name");
   $err=1; 
  }
  
  else if($arr["bank_code"]=="")
  {
   $this->session->set_flashdata("errormsg","Please enter bank code");
   $err=1; 
  }
  else if($arr["bank_branch"]=="")
  {
   $this->session->set_flashdata("errormsg","Please enter branch number");
   $err=1; 
  }
  else if($arr["account_number"]=="")
  {
   $this->session->set_flashdata("errormsg","Please enter account number");
   $err=1; 
  }
  else if($arr["account_type"]=="")
  {
   $this->session->set_flashdata("errormsg","Please enter account type");
   $err=1; 
  }
  
  else{
   $err=0;
  }
  if($err==1)
  {
   return false; 
  } 
  else
  {
   return true; 
  }
 }
 
 public function validate_information($arr){
		
		$err=0;
		if($arr["information_name"] == "")
		{
		   	$this->session->set_flashdata("errormsg","Please enter information name");
			$err=1;	
		}
		else if($arr["information_description"] == "")
		{
		   	$this->session->set_flashdata("errormsg","Please enter information description");
			$err=1;	
		}
		else{
			$err=0;
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
	
	public function validate_send_request($arr){
		
		$err=0;
		if($arr["sender"]==""){
			$this->session->set_flashdata("errormsg","Please login first to post comment");
			$err=1;	
		}
		else if($arr["message"] == "")
		{
		   	$this->session->set_flashdata("errormsg","Please enter comment");
			$err=1;	
		}
		else{
			$err=0;
		}
		if($err==1)
		{
			return false;	
		}	
		else
		{
			return true;	
		}
	}
 
}