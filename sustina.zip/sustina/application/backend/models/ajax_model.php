<?php 
class ajax_model extends CI_Model {
    function __construct()
    {
        parent::__construct();
    }
	public function showIngredientsPrice($search=array())
	{
		$i=0;
		$ingredient_id=$search["ingredient_id"];
		$this->db->select("*");
		$this->db->from("ad_on_ingredients");
		$this->db->where(array("id"=>$ingredient_id,"ingredient_status"=>"1"));
		//$this->db->where(array("ingredient_status"=>"1"));	
		$query=$this->db->get();
		$resultset=$query->row_array();
		echo $resultset['ingredient_price'];
		
	}

}
?>