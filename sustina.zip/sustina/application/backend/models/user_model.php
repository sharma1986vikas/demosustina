<?php 
class user_model extends CI_Model {
    function __construct()
    {
        parent::__construct();
    }
	


	public function get_myfavorite_product(){
		
		$this->db->select("*");	
		$this->db->from('tbl_favorite');
		$where = array("userid" => $this->session->userdata("userid"),"status" =>1);
		$this->db->where($where);
		$this->db->order_by("id desc");
		$query = $this->db->get();
	    //echo $this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;	
	}
	
	public function last_login(){
		$arr = array("last_login" => time());
		$this->db->where(array('id' => $this->session->userdata("userid")));
		return $this->db->update("tbl_users",$arr);
		//echo $this->db->last_query();die;
	}
	
	public function get_user(){
		$this->db->select("*");	
		$this->db->from('tbl_users');
		$where=array("status" =>1,"archive <> " => 1);
		$this->db->where($where);
		$this->db->order_by("name asc");
		$query = $this->db->get();
	    //echo $this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;	
	}
	
	public function get_address($id){
		$this->db->select("*");	
		$this->db->from('tbl_users_address');
		$where=array("userid" =>$id,"status <>" =>4);
		$this->db->where($where);
		$query = $this->db->get();
	    //echo $this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;	
	}
	public function get_total_friend(){
		$this->db->select("*");	
		$this->db->from('tbl_users');
		$where=array("referal_code" =>$this->session->userdata("user_uniq"));
		$this->db->where($where);
		$query = $this->db->get();
	    //echo $this->db->last_query();die;
		$resultset = $query->result_array();
		return count($resultset);	
	}
	public function add_favorite($id){
		$arr["product_id"] = $id;
		$arr["userid"] = $this->session->userdata("userid");
		$arr["created_on"] = time();
		$arr["status"] = 1;
		return $this->db->insert("tbl_favorite",$arr);
	}
	//edit user for admin
	 public function add_edit_user($arr){
		if($arr["id"] == ""){	
		 	$arr["password"] = $this->common->salt_password($arr);//generate salted password 
			return $this->db->insert("tbl_users",$arr);
		}
		else{
			//if password is not empty then generate new password
			if($arr["password"] <> ""){
				$arr["password"] = $this->common->salt_password($arr);//generate salted password 
			}
			else{
				unset($arr["password"]);
			}
			$id= $arr["id"];
			unset($arr["id"]);
			$arr["status"] =1;
			$this->db->where(array("id"=>$id));
			return $this->db->update("tbl_users",$arr);
			//echo $this->db->last_query();die;
		}
	 }
	 
	  public function add_google_userdata($arr){ 
	
	    if(!empty($arr['gid']))
		{
			return $this->db->insert("tbl_users",$arr);
		}
	    
	}
	  public function add_edit_userdata($arr){ 
	
	 if($arr['fbid'] !='' && $arr["tid"] =="" && $arr["gid"] =="")
		{
			return $this->db->insert("tbl_users",$arr);
		}
		else if($arr['gid'] =='' && $arr['fbid'] =='' && $arr["tid"] !="")
		{
			return $this->db->insert("tbl_users",$arr);
		}
	}
	  public function add_edit_address($arr){
		if($arr["id"] == ""){	
			return $this->db->insert("tbl_users_address",$arr);
		}
		else{
			$id= $arr["id"];
			unset($arr["id"]);
			$arr["status"] =1;
			$this->db->where(array("id"=>$id));
			return $this->db->update("tbl_users_address",$arr);
			//echo $this->db->last_query();die;
		}
	 }
	 
	
	 public function verify_email($id)  
	{	
		$this->db->select('count(*) as count');
		$this->db->from('tbl_users');
		$this->db->where(array('id'=>$id,'user_status' => 0));
		$query = $this->db->get();
		//echo $this->db->last_query();die;
		$verfied = $query->row_array();
		if($verfied["count"] > 0){
			$arr = array("user_status"=>1);
			$this->db->where(array('id'=>$id));
			$result = $this->db->update("tbl_users",$arr);
			$data='0';
		}
		else{
			$data='1';
		}
		return $data;
	}
	
	public function forgot_password($arr){
		
		$this->db->select('*');
		$this->db->from('tbl_users');
		$this->db->where(array('email' => $arr["email"],'user_status <>' => 4));
		$query = $this->db->get();
		//echo $this->db->last_query();die;
		$resultset = $query->row_array();
		return $resultset;
	}
	public function update_forgot_password($arr){
		$email = $arr["email"];
		unset($arr["email"]);
		$this->db->where(array("email" => $email));
		return $this->db->update("tbl_users",$arr);
		//echo $this->db->last_query();die;
	}
	public function reset_password($arr)
	{
		if($arr["password"] <> ""){
			$arr["password"] = $this->common->salt_password($arr);//generate salted password 
		}
		$id = base64_decode($arr["id"]);
		unset($arr["id"]);
		$this->db->where(array("id"=>$id));
		return $this->db->update("tbl_users",$arr);	
		//echo $this->db->last_query();die;
	}
	function get_user_data($user_id){
		$this->db->select('*');
		$this->db->from('tbl_users');
		$this->db->where(array('id' => $user_id));
		$query = $this->db->get();
		//echo $this->db->last_query();
		$resultset = $query->row_array();
		return $resultset;
	}
	function delete_address($id){
		$arr = array("status" => 4);
		$this->db->where(array("id" => $id));
		return $this->db->update("tbl_users_address",$arr);	
		//echo $this->db->last_query();die;
	}
	
	function delete_favorite($id){
		$arr = array("status" => 4);
		$this->db->where(array("id" => $id));
		return $this->db->update("tbl_favorite",$arr);	
		//echo $this->db->last_query();die;
	}
	
	
	function getUserData($searchdata=array())

	{
    
		$recordperpage="";
		$startlimit="";
		if(!isset($searchdata["page"]) || $searchdata["page"]=="")

		{

			$searchdata["page"]=0;	

		}

	    if(!isset($searchdata["countdata"]))

		{	

			if(isset($searchdata["per_page"]) && $searchdata["per_page"]!="")

			{

				$recordperpage=$searchdata["per_page"];	

			}

			else

			{

				$recordperpage=1;

			}

			if(isset($searchdata["page"]) && $searchdata["page"]!="")

			{

				$startlimit=$searchdata["page"];	

			}

			else

			{

				$startlimit=0;

			}

		}

		$searcharray=array("status"=>"user_status","verified"=>"email_verified");

		$this->db->select("*,tbl_users.id as user_id");

		$this->db->from("tbl_users");

		//$this->db->join("ugk_countries","ugk_countries.id=tbl_users.country_id");
        
		$this->db->where(array("tbl_users.user_status <> "=>4));
        if($searchdata['from']!="" && $searchdata['to']!="")
		{
		$from_data=explode('-',$searchdata['from']);
        $to_data=explode('-',$searchdata['to']);       
        $from=mktime(0, 0, 1, $from_data[1], $from_data[2], $from_data[0]);
		$to=mktime(23, 59, 59, $to_data[1], $to_data[2], $to_data[0]);
        $this->db->where("tbl_users.created_on >=",$from);
		$this->db->where("tbl_users.created_on <=",$to);
		}

		if(count($searchdata)!=0)

		{		

			foreach($searchdata as $key=>$val)

			{

				if(isset($searcharray[$key]) && $searchdata[$key]!="")

				{

					if(array_key_exists($key,$searcharray))

					{

						$where=array($searcharray[$key]=>$val);

						$this->db->where($where);

					}

				}

			}		

		}

		if(isset($searchdata["search"]) && $searchdata["search"]!="search" && $searchdata["search"]!="")
		{
			//$this->db->like('tbl_users.firstname', trim($searchdata["search"]));
			//$this->db->or_like('tbl_users.middlename', trim($searchdata["search"]));
			//$this->db->or_like('tbl_users.lastname', trim($searchdata["search"]));
			$this->db->or_like('tbl_users.email', trim($searchdata["search"]));
		}

		$where=array('user_status <> '=>'4');

		$this->db->where($where);
		if(isset($searchdata["per_page"]) && $searchdata["per_page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$this->db->limit($recordperpage,$startlimit);
			}
		}
		$query = $this->db->get();
//echo $this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;
	}

	public function getIndividualUserData($userid)
	{
		$this->db->select("*,tbl_users.id as user_id");
		$this->db->from("tbl_users");
		$this->db->where(array("tbl_users.user_status <> "=>4,"tbl_users.id"=>$userid));
		$query=$this->db->get();	
		//echo $this->db->last_query();	die;
		return $query->row_array();
	}

	public function enable_disable_user($userid,$status)
	{
		$where=array("id"=>$userid);
		$arr=array("user_status"=>$status);
		$this->db->where($where);
		return $this->db->update("tbl_users",$arr);	
	}

	public function archive_user($userid){
		$where=array("id"=>$userid);
		$arr=array("user_status"=>4);
		$this->db->where($where);
		return $this->db->update("tbl_users",$arr);	
	}
	
	public function getTotalUsers()
    {
		$this->db->select("*");
		$this->db->from("tbl_users");
		$where=array("user_status <> "=>4);
		$this->db->where($where);
		$query=$this->db->get();
		$resultset=$query->result_array();
		//echo $this->db->last_query();
		return count($resultset);
	}
	
	public function getuser_bank_accounts($id){
		  $this->db->select("*"); 
		  $this->db->from('tbl_bank');
		  $where=array("userid" =>$id,"status <>" =>4);
		  $this->db->where($where);
		  $query = $this->db->get();
		  $resultset=$query->result_array();
		  return $resultset; 
 	}
  
  public function add_edit_bank($arr){
	  if($arr["id"] == ""){ 
	  	 return $this->db->insert("tbl_bank",$arr);
	  }
	  else{
		   $id= $arr["id"];
		   unset($arr["id"]);
		   $arr["status"] =1;
		   $this->db->where(array("id"=>$id));
		   return $this->db->update("tbl_users_address",$arr);
		   //echo $this->db->last_query();die;
	  }
  }
  
   public function remove_bank($id){
	  $arr = array("status" => 4);
	  $this->db->where(array("id" => $id));
	  return $this->db->update("tbl_bank",$arr); 
   }
 
   public function newsletters($status,$id){
	  $arr = array("news_letters" => $status);
	  $this->db->where(array("id" => $id));
	  return $this->db->update("tbl_users",$arr); 
	}
 
	public function push_nottification($status,$id){
	  $arr = array("push_nottifications" => $status);
	  $this->db->where(array("id" => $id));
	  return $this->db->update("tbl_users",$arr); 
	 }
	 
	 public function get_user_information(){
		$this->db->select("*");
		$this->db->from("tbl_users");
		$this->db->where(array("id" =>$this->session->userdata("userid"),"user_status <> "=>"4"));
		$query=$this->db->get(); 
		//echo $this->db->last_query();die;
		$res = $query->row_array();
		$lst_login = $res["last_login"];
		
		$to = ($lst_login - 2*24*3600);
		$this->db->select("*");
		$this->db->from("tbl_information");
		$this->db->where(array("information_status <> " => "4","information_time >=" =>$to));
		$this->db->order_by("information_id","DESC");
		$query = $this->db->get();
		//echo $this->db->last_query();die;
		$resultset = $query->result_array();
		return $resultset;
	}
}
?>
