<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class pages extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('page_model');
		$this->load->model('contact_model');
	}
	/**********************************************************Page functions starts ************************************************/
	public function index()
	{
		$this->manage_page();	
	}
	public function manage_page()
	{
		$pagename=$this->uri->segment(3);
		
		if($pagename == 'contact')
		{
			$data["do"]="edit";
			$data["resultset"]=$this->page_model->get_contact_data($pagename);
			$data["update_contact_to_database"]='update_contact_to_database';//function to be called on save
			$data["item"]="Contact us";
			$data["master_title"]="Contact us";   
			$data["master_body"]="manage_contact";  
			$this->load->theme('mainlayout',$data);	 
		}
		else if($pagename == 'about_us')
		{
			$data["do"]="edit";
			$data["resultset"]=$this->page_model->get_contact_data($pagename);
			$data["update_aboutus_to_database"]='update_aboutus_to_database';//function to be called on save
			$data["item"]="About us";
			$data["master_title"]="About us";   
			$data["master_body"]="manage_about";  
			$this->load->theme('mainlayout',$data);	 
		}
		else if($pagename == 'partners')
		{
			$data["do"]="edit";
			$data["resultset"]=$this->page_model->get_contact_data($pagename);
			$data["update_parnter_to_database"]='update_parnter_to_database';//function to be called on save
			$data["item"]="Partner Content";
			$data["master_title"]="Partner Content";   
			$data["master_body"]="manage_partner"; 
			$this->load->theme('mainlayout',$data);	 
		}
		
		else if($pagename == 'food_club')
		{
			$data["do"]="edit";
			$data["resultset"]=$this->page_model->get_contact_data($pagename);
			$data["update_club_to_database"]='update_club_to_database';//function to be called on save
			$data["item"]="Food Club Content";
			$data["master_title"]="Food Club Content";   
			$data["master_body"]="manage_club_content"; 
			//echo  "<pre>";
			//print_r($data);die;
			$this->load->theme('mainlayout',$data);	 
		}
		else if($pagename == 'week_rest')
		{
			$data["do"]="edit";
			$data["resultset"]=$this->page_model->get_contact_data($pagename);
			$data["update_week_rest_to_database"]='update_week_rest_to_database';//function to be called on save
			$data["item"]="Week's  restaurants";
			$data["master_title"]="Week's  restaurants";   
			$data["master_body"]="manage_week_rest"; 
			$this->load->theme('mainlayout',$data);	 
		}
		else if($pagename == 'quick_easy')
		{
			$data["do"] = "edit";
			$data["resultset"] = $this->page_model->get_contact_data($pagename);
			$data["update_quick_easy_to_database"] = 'update_quick_easy_to_database';//function to be called on save
			$data["item"]="Quick & easy";
			$data["master_title"] = "Quick & easy";   
			$data["master_body"] = "manage_quick_easy"; 
			$this->load->theme('mainlayout',$data);	 
		}
		else{
		}
	}
	
	//update week rest.
	public function update_quick_easy_to_database()
	{
		$arr["id"]=$this->input->post("id");
		$arr["page_name"] = trim($this->input->post("page_name"));
		$arr["page_title"] = trim($this->input->post("page_title"));
		$arr["page_content"] = trim($this->input->post("page_content"));
		$arr["image"] = $_FILES["userfile"]["name"];
		$arr["page_status"] = 1;
		
		if($arr["image"] != "")
		{
			$arr["image"] = time().".".$this->common->get_extension($_FILES["userfile"]["name"]);
		}
		else
		{
			$arr["image"] = $this->input->post("image");	
		}
		//echo "<pre>"; 
		//print_r($arr);die;
		if($this->validations->validate_week_rest_us($arr))
		{
			if($this->page_model->update_contact_data($arr))
			{
				if($arr["image"] != $this->input->post("image"))
				{
					$config['upload_path'] = '../uploads/';
					$config['allowed_types'] = '*';
					$config['file_name'] = $arr["image"];
					$this->upload->initialize($config);
					if($this->upload->do_upload()){
						$err=0;
					}		
					else {
						//echo $this->upload->display_errors();die;
						$this->session->set_flashdata("successmsg","There is some error uploading the files to server. Please contact server admin");		
					}		
				}
				$this->session->set_flashdata("successmsg","quick easy updated successffuly");
				$err=0;
			}
			else
			{
				$this->session->set_flashdata("errormsg","There is error editing quick easy. Please contact database admin");
				$err=1;
			}
		}
		else
		{
			redirect(base_url()."pages/manage_page/quick_easy/edit");
			$err=1;	
		}
		//echo "hiii";die;
		redirect(base_url()."pages/manage_page/quick_easy/edit");
	}
	
	//update week rest.
	public function update_week_rest_to_database()
	{
		$arr["id"]=$this->input->post("id");
		$arr["page_name"] = trim($this->input->post("page_name"));
		$arr["page_title"] = trim($this->input->post("page_title"));
		$arr["page_content"] = trim($this->input->post("page_content"));
		$arr["image"] = $_FILES["userfile"]["name"];
		$arr["page_status"] = 1;
		
		if($arr["image"] != "")
		{
			$arr["image"] = time().".".$this->common->get_extension($_FILES["userfile"]["name"]);
		}
		else
		{
			$arr["image"] = $this->input->post("image");	
		}
		//echo "<pre>"; 
		//print_r($arr);die;
		if($this->validations->validate_week_rest_us($arr))
		{
			if($this->page_model->update_contact_data($arr))
			{
				if($arr["image"] != $this->input->post("image"))
				{
					$config['upload_path'] = '../uploads/';
					$config['allowed_types'] = '*';
					$config['file_name'] = $arr["image"];
					$this->upload->initialize($config);
					if($this->upload->do_upload()){
						$err=0;
					}		
					else {
						//echo $this->upload->display_errors();die;
						$this->session->set_flashdata("successmsg","There is some error uploading the files to server. Please contact server admin");		
					}		
				}
				$this->session->set_flashdata("successmsg","week restaurants updated successffuly");
				$err=0;
			}
			else
			{
				$this->session->set_flashdata("errormsg","There is error editing week restaurants . Please contact database admin");
				$err=1;
			}
		}
		else
		{
			redirect(base_url()."pages/manage_page/week_rest/edit");
			$err=1;	
		}
		//echo "hiii";die;
		redirect(base_url()."pages/manage_page/week_rest/edit");
	}
	
	//update contact us page to admin
	public function update_contact_to_database()
	{
		$arr["id"]=$this->input->post("id");
		$arr["page_name"] = trim($this->input->post("page_name"));
		$arr["page_title"] = trim($this->input->post("page_title"));
		$arr["page_content"] = trim($this->input->post("page_content"));
		$arr["page_content1"] = trim($this->input->post("page_content1"));
		$arr["image"] = $_FILES["userfile"]["name"];
		$arr["page_status"] = 1;
		
		if($arr["image"] != "")
		{
			$arr["image"] = time().".".$this->common->get_extension($_FILES["userfile"]["name"]);
		}
		else
		{
			$arr["image"] = $this->input->post("image");	
		}
		//echo "<pre>"; 
		//print_r($arr);die;
		if($this->validations->validate_contact_us($arr))
		{
			if($this->page_model->update_contact_data($arr))
			{
				if($arr["image"] != $this->input->post("image"))
				{
					$config['upload_path'] = '../uploads/';
					$config['allowed_types'] = '*';
					$config['file_name'] = $arr["image"];
					$this->upload->initialize($config);
					if($this->upload->do_upload()){
						$err=0;
					}		
					else {
						//echo $this->upload->display_errors();die;
						$this->session->set_flashdata("successmsg","There is some error uploading the files to server. Please contact server admin");		
					}		
				}
				$this->session->set_flashdata("successmsg","Contact us updated successffuly");
				$err=0;
			}
			else
			{
				$this->session->set_flashdata("errormsg","There is error editing contact us page . Please contact database admin");
				$err=1;
			}
		}
		else
		{
			redirect(base_url()."pages/manage_page/contact/edit");
			$err=1;	
		}
		redirect(base_url()."pages/manage_page/contact/edit");
	}
//update about us data
	public function update_aboutus_to_database()
	{
		$arr["page_content"] = trim($this->input->post("page_content"));
		$arr["page_name"] = trim($this->input->post("page_name"));
		//print_r($arr);die;
		if($this->validations->validate_aboutus($arr))
		{
			
			if($this->page_model->update_aboutus_to_database($arr))
			{
				$this->session->set_flashdata("successmsg","about us updated successffuly");
				$err=0;
			}
			else
			{
				$this->session->set_flashdata("errormsg","there was a problem updating about us ");
				$err=1;	
			}
		}
		else
		{
			
			$err=1;	
		}
		redirect(base_url()."pages/manage_page/about_us/edit");	
	}
	//partner content for admin
	public function update_parnter_to_database()
	{
		$arr["page_content"] = trim($this->input->post("page_content"));
		$arr["page_name"] = trim($this->input->post("page_name"));
		if($this->validations->validate_aboutus($arr))
		{
			
			if($this->page_model->update_aboutus_to_database($arr))
			{
				$this->session->set_flashdata("successmsg","partner updated successffuly");
				$err=0;
			}
			else
			{
				$this->session->set_flashdata("errormsg","there was a problem updating partner");
				$err=1;	
			}
		}
		else
		{
			redirect(base_url()."pages/manage_page/partners/edit");
			$err=1;	
		}
		redirect(base_url()."pages/manage_page/partners/edit");	
	}
	//food club content for admin
	public function update_club_to_database()
	{
		$arr["page_title"] = trim($this->input->post("page_title"));
		$arr["page_content"] = trim($this->input->post("page_content"));
		$arr["page_name"] = trim($this->input->post("page_name"));
		if($this->validations->validate_foodclub($arr))
		{
			
			if($this->page_model->update_aboutus_to_database($arr))
			{
				$this->session->set_flashdata("successmsg","club updated successffuly");
				$err=0;
			}
			else
			{
				$this->session->set_flashdata("errormsg","there was a problem updating club content");
				$err=1;	
			}
		}
		else
		{
			redirect(base_url()."pages/manage_page/food_club/edit");
			$err=1;	
		}
		redirect(base_url()."pages/manage_page/food_club/edit");	
	}
	
	/*public function update_contact_information()
	{
		$arr["contact_number"]=$this->input->post("contact_number");
		$arr["contact_email"]=$this->input->post("contact_email");
		$arr["contact_fax"]=$this->input->post("contact_fax");	
		if($this->validations->validate_contact_information($arr))
		{
			if($this->page_model->update_contact_information($arr))
			{
				$this->session->set_flashdata("successmsg","Contact Information updated successffuly");
				$err=0;
			}
			else
			{
				$err=1;	
			}
		}
		else
		{
			$err=1;	
		}
		redirect(base_url()."pages/manage_page/contact_info");	
	}*/
	public function get_image_Extension($imagename)
	{
		$imagename=explode(".",$imagename);
		return $imagename[1];
	}

	public function upload_images()
	{
		$config['upload_path'] = '../ckeditorimages/';
		$config['allowed_types'] = '*';
		$config['file_name']=$_FILES['upload']['name'];
		$this->upload->initialize($config);
		$validimages=array("jpg","gif","png","jpeg","bmp");
		if(in_array($this->get_image_Extension($_FILES['upload']['name']),$validimages))
		{
			if($this->upload->do_upload('upload'))
			{
				$arr=$this->upload->data();
				$url = $this->config->item("ckeditorimages").$arr['file_name'];
			}
			else
			{
				$message = "Error moving uploaded file. Check the script is granted Read/Write/Modify permissions.";	
			}
		}
		else
		{
			$message = "Only images file with ".implode(",",$validimages)." extensions are allowed";	
		}
		 $funcNum = $_GET['CKEditorFuncNum'] ;
		echo "<script type='text/javascript'>window.parent.CKEDITOR.tools.callFunction($funcNum, '$url', '$message');</script>";
	}
	
	
	public function manage_information()
	{	
		
		$data["item"]="information";
		$data["master_title"]=$this->config->item("sitename")." | Manage information";   // Please enter the title of page......
		$data["master_body"]="manage_information";  //  Please use view name in this field please do not include '.php' for including view name
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=isset($_GET["per_page"]) ? $_GET["per_page"] : ""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
           		 redirect(BASEURL.'404');
            }
			else{
            	$page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url'] = base_url().$this->router->class."/manage_information/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows'] = count($this->page_model->getinformationData($countdata));   
		$config["uri_segment"] = (isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"] = $config["per_page"];
		$searcharray["page"] = $config["uri_segment"];
		$data["resultset"] = $this->page_model->getinformationData($searcharray);
		$this->load->theme('mainlayout',$data);	
	}
	
	public function add_information()
	{
		$data["do"]="add";
		$data["item"]="information";
		$data["informationdata"]=$this->session->flashdata("tempdata");
		$data["add_information_to_database"] = "add_information_to_database";
		$data["master_title"]=$this->config->item("sitename")." | Add information";   // Please enter the title of page......
		$data["master_body"]="add_information";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		if($this->uri->segment(3)!='' && $this->uri->segment(3)=='0')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_information");
		}
	}
	
	public function edit_information()
	{
		$data["do"]="edit";
		$brandid=$this->uri->segment(3);
		$data["informationdata"]=$this->page_model->getIndividualinformation($brandid);	
		$data["add_information_to_database"] = "add_information_to_database";
		$data["master_title"]=$this->config->item("sitename")." | Edit information";   // Please enter the title of page......
		$data["master_body"]="add_information";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		if($this->uri->segment(4)!='' && $this->uri->segment(4)=='2')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_information");
		}
	}
	
	public function add_information_to_database()
	{
		$arr["information_id"] = $this->input->post("information_id");
		$arr["information_name"] = $this->input->post("information_name");
		$arr["information_description"] = $this->input->post("information_description");
		$arr["information_status"] = 1;	
		$arr["information_time"] = time();
		
		$this->session->set_flashdata("tempdata",$arr);	
		
		if($this->validations->validate_information($arr))
		{
			//print_r($arr);
			if($this->page_model->add_edit_information($arr)){
				if($arr["information_id"] == ''){
					$err=0;	
					$this->session->set_flashdata("successmsg","information added succesfully");
				}
				else{
					$err=2;	
					$this->session->set_flashdata("successmsg","information edited succesfully");
				}
			}	
			else
			{
				$err=1;
				$this->session->set_flashdata("errormsg","There was error in adding this information.");
			}
			if($err==0){
				redirect(base_url().$this->router->class."/add_information"."/0");
			}
			else if($err==1){
				redirect(base_url().$this->router->class."/add_information"."/1");
			}
			else if($err==2){
				redirect(base_url().$this->router->class."/edit_information/".$arr["information_id"]."/2");
			}
		}
		else
		{
			if($arr["information_id"] == ''){
				$err=1;	
				redirect(base_url().$this->router->class."/add_information");
			}
			else{
				$err=1;	
				redirect(base_url().$this->router->class."/edit_information/".$arr["information_id"]);
			}
		}
		
	}
	
	public function archive_information()
	{
		$delid=$this->uri->segment(3);
		if($delid!='')
		{	
			$this->page_model->archive_information($delid);
			$this->session->set_flashdata("successmsg","information archived successfully");	
			redirect(base_url().$this->router->class."/manage_information");
		}
		else
		{
			$data=$this->input->post("chk");
			if(!isset($_REQUEST["chk"]) && count($_REQUEST["chk"])==0)
			{
				$this->session->set_flashdata("errormsg","No information selected");	
				redirect(base_url().$this->router->class."/manage_information");	
			}
			foreach($data as $key=>$val)
			{
				$this->page_model->archive_information($val);
			}
			
			$this->session->set_flashdata("successmsg","Selected information archived successfully");	
			redirect(base_url().$this->router->class."/manage_information");
		}	
	}
	
	
	
	public function enable_disable_information()
	{
		$categoryid = $this->uri->segment(3);
		$status = $this->uri->segment(4);
		if($status == 0)
		{
			$show_status = "deactivated";	
		}	
		else
		{
			$show_status = "activated";	
		}
		
		$this->page_model->enable_disable_information($categoryid,$status);
		$this->session->set_flashdata("successmsg","information ".$show_status." successfully");	
		redirect(base_url().$this->router->class."/manage_information");
	}
	
	public function view_information()
	{
		$id=$this->uri->segment(3);
		
		if($id == "" || $id == 0)
		{
			$data["master_item"]="error";
			$data["master_title"]="Page not found";   // Please enter the title of page......
			$data["master_body"]=$this->config->item("error_page");  //  Please use view name in this field please do not include '.php' for including view name
			$this->load->theme('mainlayout',$data);  // Loading theme	
			die;			
		}
		else
		{
			$data["resultset"]=$this->page_model->getIndividualinformation($id);
		}
		$data["item"] = "information";
		$data["master_title"] = $this->config->item("sitename")." | View information";   // Please enter the title of page......
		$data["master_body"] = "view_information";  //  Please use view name in this field please do not include '.php' for including view name
		$this->load->theme('mainlayout',$data);	
	}
	
	
	public function manage_message()
	{	
		
		$data["item"] = "Message";
		$data["master_title"] = $this->config->item("sitename")." | Manage Message";   // Please enter the title of page......
		$data["master_body"] = "manage_message";  //  Please use view name in this field please do not include '.php' for including view name
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=isset($_GET["per_page"]) ? $_GET["per_page"] : ""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
           		 redirect(BASEURL.'404');
            }
			else{
            	$page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url'] = base_url().$this->router->class."/manage_message/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows'] = count($this->page_model->getmessageData($countdata));   
		$config["uri_segment"] = (isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"] = $config["per_page"];
		$searcharray["page"] = $config["uri_segment"];
		$data["resultset"] = $this->page_model->getmessageData($searcharray);
		$this->load->theme('mainlayout',$data);	
	}
	
	public function view_message()
	{
		$id = $this->uri->segment(3);
		$data["conversation"] = $id;
		$data["resultset"] = $this->page_model->view_message($id);
		//debug($data["resultset"]);die;
		$data["item"] = "View message";
		$data["master_title"] = $this->config->item("sitename")." | View message";   // Please enter the title of page......
		$data["master_body"] = "view_message";  //  Please use view name in this field please do not include '.php' for including view name
		$this->load->theme('mainlayout',$data);	
		if($this->uri->segment(4) != '' && $this->uri->segment(4)=='0')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/view_message/".$id);
		}
	}
	
	public function add_request(){
		
		$conversation = $this->input->post("conversation");
		$arr["sender"] = 2;
		$arr["receiver"] = $this->input->post("receiver");
		$arr["message"]  = trim(mysql_real_escape_string($this->input->post("message")));
		$arr["created_on"] = time();
		$arr["status"] = 1;
		$data["resultset"] = $this->page_model->view_message($conversation);

		//debug($arr);die;
		if($this->validations->validate_send_request($arr)){
			if($this->contact_model->add_send_request($arr)){
				$err=0;	
				$this->session->set_flashdata("successmsg","Your message has been sent succesfully");
			}
			else
			{
				$err=1;
				$this->session->set_flashdata("errormsg","There was error sending this message");
			}
			if($err==0){
				redirect(base_url().$this->router->class."/view_message/".$conversation."/0");
			}
			else if($err==1){
				redirect(base_url().$this->router->class."/view_message/".$conversation."/1");
			}
		}
		else{
			redirect(base_url().$this->router->class."/view_message/".$conversation);
		}
	}
	public function archive_message()
	{
		$delid=$this->uri->segment(3);
		if($delid!='')
		{	
			$this->page_model->archive_message($delid);
			$this->session->set_flashdata("successmsg","message archived successfully");	
			redirect(base_url().$this->router->class."/manage_message");
		}
		else
		{
			$data=$this->input->post("chk");
			if(!isset($_REQUEST["chk"]) && count($_REQUEST["chk"])==0)
			{
				$this->session->set_flashdata("errormsg","No message selected");	
				redirect(base_url().$this->router->class."/manage_message");	
			}
			foreach($data as $key=>$val)
			{
				$this->page_model->archive_message($val);
			}
			
			$this->session->set_flashdata("successmsg","Selected message archived successfully");	
			redirect(base_url().$this->router->class."/manage_message");
		}	
	}
	/**********************************************************Page functions starts ************************************************/
}

?>