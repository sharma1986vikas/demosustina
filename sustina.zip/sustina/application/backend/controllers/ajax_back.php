<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ajax_back extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('ajax_model');
		//$this->load->model('category_model');
		//$this->load->helper('url');
	}
		
	public function showIngredientsPrice($ingredient_id)
	{
		$ingredient_id;
		/*$CountryId;
		$data["item"]="City";
		$data["master_title"]="Add City";  
		$data["master_body"]="add_city"; */
		echo $result = $this->ajax_model->showIngredientsPrice($ingredient_id);
		
	}
}
?>