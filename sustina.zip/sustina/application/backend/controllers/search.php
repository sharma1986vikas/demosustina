<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class search extends CI_Controller {

	public function __construct(){
		
		parent::__construct();
		//$this->load->model("page_model");
		$this->load->model('user_model');
		$this->load->model('email_model');
		$this->load->model('products_model');
		$this->load->model('search_model');
	}
	
	//request a cloth
    public function index(){
		$this->common->is_logged_in();
		//debug($data["featured"]);die;
	    $data["item"]="Search";
		$data["master_title"] = $this->config->item("sitename")." -Search"; 
	    $data["master_body"]="index";
		$this->load->theme('mainlayout',$data);
	}
	//request a cloth
    public function refine_search(){
		$this->common->is_logged_in();
		
	    $data["item"]="Advance Search";
		$data["master_title"] = $this->config->item("sitename")." -Advance Search"; 
	    $data["master_body"]="refine_search";
		$this->load->theme('mainlayout',$data);
	}
	
	
	public function category_search()
	{
		$this->common->is_logged_in();
	    $category_slug=$this->uri->segment(3);
		$result = $this->search_model->getCategoryBySlug($category_slug);
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/category_search/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->search_model->getSearchProductData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
	
	
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		 $searcharray["category"]=$result["id"];
		
		
		$data["item"]=ucfirst($result["category_name"]);
		$data["resultset"]=$this->search_model->getSearchProductData($searcharray);
		$data["master_title"] = $this->config->item("sitename")."-Category Search"; 
		$data["master_body"]="search_result";
		$this->load->theme('mainlayout',$data);
	}
	
	public function brand_search()
	{
		$this->common->is_logged_in();
	    /*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/brand_search/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->search_model->getSearchProductData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
	
	
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
	    $searcharray["brand"]=$this->uri->segment(3);
		
		
		$data["item"]=ucfirst($this->uri->segment(3));
		$data["resultset"]=$this->search_model->getSearchProductData($searcharray);
		$data["master_title"] = $this->config->item("sitename")."-Brand Search"; 
		$data["master_body"]="search_result";
		$this->load->theme('mainlayout',$data);
	}
	public function brands_search()
	{
		$this->common->is_logged_in();
		$brand_slug=$this->uri->segment(3);
		$result = $this->search_model->getBrandBySlug($brand_slug);
	    /*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url'] = base_url().$this->router->class."/brands_search/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata =array();
		$countdata =$_GET;
		$countdata["countdata"] = "yes";	
		
		$config['total_rows']=count($this->search_model->getSearchProductData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
	
	
		$searcharray = array();
		$searcharray = $_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$searcharray["brand_id"]=$result['brand_id'];
		
		
		$data["item"]=ucfirst($result['brand_name']);
		$data["resultset"]=$this->search_model->getSearchProductData($searcharray);
		$data["master_title"] = $this->config->item("sitename")."-Brand Search"; 
		$data["master_body"]="search_result";
		$this->load->theme('mainlayout',$data);
	}
	
	public function subcategory_search()
	{
		$this->common->is_logged_in();
	    $category_slug=$this->uri->segment(3);
		$result = $this->search_model->getSubCategoryBySlug($category_slug);
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/subcategory_search/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->search_model->getSearchProductData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
	
	
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$searcharray["sub_category"]=$result["id"];
		
		$data["item"]=ucfirst($result["category_name"]);
		$data["resultset"]=$this->search_model->getSearchProductData($searcharray);
		$data["master_title"] = $this->config->item("sitename")."- SubCategory Search"; 
		$data["master_body"]="search_result";
		$this->load->theme('mainlayout',$data);
	}
	
	public function color_search()
	{
		$this->common->is_logged_in();
	    $slug=$this->uri->segment(3);
		$result = $this->products_model->get_color_by_name($slug);
		
		if($result['attribute_id']!="")
		{
		$id=$result["attribute_id"];	
		}
		else
		{
		$id='00';	
		}
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/color_search/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->search_model->getSearchProductData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
	
	
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$searcharray["color_id"]= $id;
		
		
		$data["item"]=ucfirst($result["attribute_name"]);
		$data["resultset"]=$this->search_model->getSearchProductData($searcharray);
		$data["master_title"] = $this->config->item("sitename")."- color Search"; 
		$data["master_body"]="search_result";
		$this->load->theme('mainlayout',$data);
	}
	
	public function size_search()
	{
		$this->common->is_logged_in();
	    $slug=$this->uri->segment(3);
		$result = $this->products_model->get_size_by_name($slug);
		if($result["attribute_id"]!="")
		{
		$id=$result["attribute_id"];	
		}
		else
		{
		$id='00';	
		}
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/size_search/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->search_model->getSearchProductData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
	
	
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$searcharray["size_id"]= $id;
		
		
		$data["item"]=ucfirst($result["attribute_name"]);
		$data["resultset"]=$this->search_model->getSearchProductData($searcharray);
		$data["master_title"] = $this->config->item("sitename")."- color Search"; 
		$data["master_body"]="search_result";
		$this->load->theme('mainlayout',$data);
	}
	
	
	public function price_search()
	{
		$this->common->is_logged_in();
	   	$arr["price"] = $this->input->post("price");
		
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/price_search/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->search_model->getSearchProductData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
	
	
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$searcharray["price"]= trim($arr["price"]);
		
		$data["item"]="Price Serach";
		$data["resultset"]=$this->search_model->getSearchProductData($searcharray);
		$data["master_title"] = $this->config->item("sitename")."- Price Search"; 
		$data["master_body"]="search_result";
		$this->load->theme('mainlayout',$data);
	}
	//////////////////////////////////////////////////////////////////////////////////////////
	public function search_result()
	{
		$this->common->is_logged_in();
	   	$arr["keyword"] = $this->input->post("keyword");
		
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/search_result/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->search_model->getKeywordSearchProductData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
	
	
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$searcharray["keyword"]= trim($arr["keyword"]);
		
		if($searcharray["keyword"]=="")
		{
			$data["item"]='All';
		}
		else
		{
			$data["item"]=$searcharray["keyword"];
		}
		
		$data["resultset"]=$this->search_model->getKeywordSearchProductData($searcharray);
		$data["master_title"] = $this->config->item("sitename")."- ".$data["item"]; 
		$data["master_body"]="search_result";
		$this->load->theme('mainlayout',$data);
	}
	//////////////////////////////////////////////////////////////////////////////////////////
	public function price_type()
	{
		$this->common->is_logged_in();
	   	$type=$this->uri->segment(3);
		
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/price_type/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->search_model->getSearchProductData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
	
	
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$searcharray["type"]= $type;
		
		if($searcharray["type"]=="sale")
		{
			$data["item"]='Sale Products';
		}
		else
		{
			$data["item"]='products';
		}
		
		$data["resultset"]=$this->search_model->getSearchProductData($searcharray);
		$data["master_title"] = $this->config->item("sitename")."-".$data["item"]; 
		$data["master_body"]="search_result";
		$this->load->theme('mainlayout',$data);
	}
	

}
