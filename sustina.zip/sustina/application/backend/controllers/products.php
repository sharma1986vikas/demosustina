<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class products extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('products_model');
		$this->load->helper('url');
		$this->load->library('encrypt');
		$this->load->library('upload');
	}
		
	public function index()
	{
		$this->manage_brand();	
	}
	/*attributes starts*/	
	
	public function manage_attribute()
	{	
		
		$data["item"]="Attribute";
		$data["master_title"]=$this->config->item("sitename")." | Manage Attribute";   // Please enter the title of page......
		$data["master_body"]="manage_attribute";  //  Please use view name in this field please do not include '.php' for including view name
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=isset($_GET["per_page"]) ? $_GET["per_page"] : ""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/manage_attribute/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->products_model->getAttributeData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$data["resultset"]=$this->products_model->getAttributeData($searcharray);
		$this->load->theme('mainlayout',$data);	
	}
	
	public function enable_disable_attribute()
	{
		$id=$this->uri->segment(3);
		$status=$this->uri->segment(4);
		
		if($status==0)
		{
			$show_status="deactivated";	
		}	
		else
		{
			$show_status="activated";	
		}
		
		$this->products_model->enable_disable_attribute($id,$status);
		$this->session->set_flashdata("successmsg","attribute ".$show_status." successfully");	
		redirect(base_url().$this->router->class."/manage_attribute");
	}
	/*
	attributes ends
	*/
	//
	public function add_property()
	{
		$data["attribute_relation"] = $this->uri->segment(3);
		$data["do"] = "add";
		$data["item"] = "Property";
		$data["propertydata"] = $this->session->flashdata("tempdata");
		$data["add_property_to_database"] = "add_property_to_database";
		$data["master_title"] = $this->config->item("sitename")." | Add property";   // Please enter the title of page......
		$this->load->theme("head",$data);//load head in view
		$this->load->view("products/add_property",$data);//load view
		
		if($this->uri->segment(4)!='' && $this->uri->segment(4)=='0')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_attribute");
		}
	}
	
	public function edit_property()
	{
		$data["do"] = "edit";
		$data["item"] = "Property";
		$attribute_id = $this->uri->segment(3);
		$data["propertydata"] = $this->products_model->getIndividualProperty($attribute_id);	
		$data["add_property_to_database"] = "add_property_to_database";
		$data["master_title"] = $this->config->item("sitename")." | Add property";   // Please enter the title of page......
		$this->load->theme("head",$data);//load head in view
		$this->load->view("products/add_property",$data);//load view
		
		if($this->uri->segment(4)!='' && $this->uri->segment(4)=='0')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_attribute");
		}
	}
	
	public function add_property_to_database()
	{
		
		$type = trim($this->input->post("type"));
		//$arr["attribute_relation"] = trim($this->input->post("attribute_relation"));
		
		if($type == "add")
		{
			$arr["type"] = trim($this->input->post("type"));
			$arr["attribute_relation"] = trim($this->input->post("attribute_relation"));
		    $arr["attribute_name"]=trim(mysql_real_escape_string($this->input->post("attribute_name")));
			$arr["attribute_status"] = 1;	
			$arr["attribute_created_time"] = time();
			
			
		}
		else
		{
			$arr["type"] = trim($this->input->post("type"));
			$arr["attribute_id"] = trim($this->input->post("attribute_id"));
		    $arr["attribute_name"]=trim(mysql_real_escape_string($this->input->post("attribute_name")));
			$arr["attribute_status"] = 1;	
			$arr["attribute_created_time"] = time();
		}
		
		$this->session->set_flashdata("tempdata",$arr);	
	    if($this->validations->validate_property($arr))
		{
			
			
			unset($arr["type"]);
			if($type =="add")
		    {
			        if($this->products_model->add_property($arr)){
			        $err=0;	
					$this->session->set_flashdata("successmsg","property added succesfully");
					}
					else
					{
						$err=1;
						$this->session->set_flashdata("errormsg","There was error in adding this property.");
					}
					if($err==0){
					
						redirect(base_url()."products/add_property/".$arr['attribute_id']."/0");
					}
					else if($err==1){
					redirect(base_url()."products/add_property/".$arr['attribute_id']."/1");
						
					}
					else if($err==2){
						redirect(base_url()."products/add_property/".$arr['attribute_id']."/2");
						
					}
			}
			else
			{
			
			        if($this->products_model->edit_property($arr)){
			        $err=0;	
					$this->session->set_flashdata("successmsg","property edit succesfully");
					}
					else
					{
						$err=1;
						$this->session->set_flashdata("errormsg","There was error in edit this property.");
					}
					if($err==0){
						redirect(base_url()."products/edit_property/".$arr['attribute_id']."/0");
					}
					elseif($err==1){
					redirect(base_url()."products/edit_property/".$arr['attribute_id']."/1");
						
					}
					else if($err==2){
						redirect(base_url()."products/edit_property/".$arr['attribute_id']."/2");
					}
				
			}
		
		}
		else
		{
			
			if($type =="add")
		    {
				redirect(base_url()."products/add_property/".$arr["attribute_relation"]);
			}
			else
			{
				  redirect(base_url()."products/edit_property/".$arr["attribute_id"]);
			}
		}
		
	}
	
	
	public function archive_property()
	{
		$delid=$this->uri->segment(3);
		if($delid!='')
		{	
			$this->products_model->archive_property($delid);
			$this->session->set_flashdata("successmsg","property archived successfully");	
			redirect(base_url().$this->router->class."/manage_attribute");
		}
		else
		{
			$data=$this->input->post("chk");
			if(!isset($_REQUEST["chk"]) && count($_REQUEST["chk"])==0)
			{
				$this->session->set_flashdata("errormsg","No property selected");	
				redirect(base_url().$this->router->class."/manage_property");	
			}
			foreach($data as $key=>$val)
			{
				$this->products_model->archive_property($val);
			}
			
			$this->session->set_flashdata("successmsg","Selected property archived successfully");	
			redirect(base_url().$this->router->class."/manage_attribute");
		}	
	}
	
	
	
	/************************************brand category price starts*******************************************/
	
	public function manage_price()
	{	
		$data["item"]="Price";
		$data["master_title"]=$this->config->item("sitename")." | Manage Price";   // Please enter the title of page......
		$data["master_body"]="manage_price";  //  Please use view name in this field please do not include '.php' for including view name
		
		//print_r($data);die;
		$page=isset($_GET["per_page"]) ? $_GET["per_page"] : ""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/manage_price/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->products_model->getPriceData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$data["resultset"]=$this->products_model->getPriceData($searcharray);
		$this->load->theme('mainlayout',$data);	
	}
	
	public function add_price()
	{
		$data["do"]="add";
		$data["item"]="Price";
		$data["pricedata"]=$this->session->flashdata("tempdata");
		$data["add_price_to_database"] = "add_price_to_database";
		$data["master_title"]=$this->config->item("sitename")." | Add price";   // Please enter the title of page......
		$data["master_body"]="add_price";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		if($this->uri->segment(3)!='' && $this->uri->segment(3)=='0')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_price");
		}
	}
	
	public function edit_price()
	{
		$data["do"]="edit";
		$brandid=$this->uri->segment(3);
		$data["pricedata"]=$this->products_model->getIndividualPrice($brandid);	
		$data["add_price_to_database"] = "add_price_to_database";
		$data["master_title"]=$this->config->item("sitename")." | Edit price";   // Please enter the title of page......
		$data["master_body"]="add_price";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		if($this->uri->segment(4)!='' && $this->uri->segment(4)=='2')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_price");
		}
	}
	
	public function add_price_to_database()
	{
		$arr["price_id"] = $this->input->post("price_id");
		$arr["brand_id"] = $this->input->post("brand_id");
		$arr["category_id"] = $this->input->post("category_id");
		$arr["price_from"] = $this->input->post("price_from");
		$arr["price_to"] = $this->input->post("price_to");
		$arr["price_status"] = 1;	
		
		if($arr["price_id"]==""){
			$arr["price_created_time"] = time();
		}
		else{
			$arr["price_updated_time"] = time();
		}
		$this->session->set_flashdata("tempdata",$arr);	
		
		if($this->validations->validate_price($arr))
		{
			//print_r($arr);
			if($this->products_model->add_edit_price($arr)){
				if($arr["price_id"] == ''){
					$err=0;	
					$this->session->set_flashdata("successmsg","price added succesfully");
				}
				else{
					$err=2;	
					$this->session->set_flashdata("successmsg","price edited succesfully");
				}
			}	
			else
			{
				$err=1;
				$this->session->set_flashdata("errormsg","There was error in adding this price.");
			}
			if($err==0){
				redirect(base_url().$this->router->class."/add_price"."/0");
			}
			else if($err==1){
				redirect(base_url().$this->router->class."/add_price"."/1");
			}
			else if($err==2){
				redirect(base_url().$this->router->class."/edit_price/".$arr["price_id"]."/2");
			}
		}
		else
		{
			if($arr["price_id"] == ''){
				$err=1;	
				redirect(base_url().$this->router->class."/add_price");
			}
			else{
				$err=1;	
				redirect(base_url().$this->router->class."/edit_price/".$arr["price_id"]);
			}
		}
		
	}
	
	public function archive_price()
	{
		$delid=$this->uri->segment(3);
		if($delid!='')
		{	
			$this->products_model->archive_price($delid);
			$this->session->set_flashdata("successmsg","price archived successfully");	
			redirect(base_url().$this->router->class."/manage_price");
		}
		else
		{
			$data=$this->input->post("chk");
			if(!isset($_REQUEST["chk"]) && count($_REQUEST["chk"])==0)
			{
				$this->session->set_flashdata("errormsg","No price selected");	
				redirect(base_url().$this->router->class."/manage_price");	
			}
			foreach($data as $key=>$val)
			{
				$this->products_model->archive_price($val);
			}
			
			$this->session->set_flashdata("successmsg","Selected price archived successfully");	
			redirect(base_url().$this->router->class."/manage_price");
		}	
	}
	
	public function enable_disable_price()
	{
		$categoryid=$this->uri->segment(3);
		$status=$this->uri->segment(4);
		if($status==0)
		{
			$show_status="deactivated";	
		}	
		else
		{
			$show_status="activated";	
		}
		
		$this->products_model->enable_disable_price($categoryid,$status);
		$this->session->set_flashdata("successmsg","price ".$show_status." successfully");	
		redirect(base_url().$this->router->class."/manage_price");
	}
	
	
	public function view_price()
	{
		$id=$this->uri->segment(3);
		
		if($id == "" || $id == 0)
		{
			$data["master_item"]="error";
			$data["master_title"]="Page not found";   // Please enter the title of page......
			$data["master_body"]=$this->config->item("error_page");  //  Please use view name in this field please do not include '.php' for including view name
			$this->load->theme('mainlayout',$data);  // Loading theme	
			die;			
		}
		else
		{
			$data["resultset"]=$this->products_model->getIndividualPrice($id);
		}
		$data["item"]="price";
		$data["master_title"] = $this->config->item("sitename")." | View price";   // Please enter the title of page......
		$data["master_body"] = "view_price";  //  Please use view name in this field please do not include '.php' for including view name
		$this->load->theme('mainlayout',$data);	
	}
	/************************************brand category price ends*******************************************/
	/*brands starts */
	
	public function manage_brand()
	{	
		
		$data["item"]="Brand";
		$data["master_title"]=$this->config->item("sitename")." | Manage Brand";   // Please enter the title of page......
		$data["master_body"]="manage_brand";  //  Please use view name in this field please do not include '.php' for including view name
		
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=isset($_GET["per_page"]) ? $_GET["per_page"] : ""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/manage_brand/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->products_model->getBrandData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$data["resultset"]=$this->products_model->getBrandData($searcharray);
		$this->load->theme('mainlayout',$data);	
	}
	
	public function add_brand()
	{
		$data["do"]="add";
		$data["item"]="Brand";
		$data["branddata"]=$this->session->flashdata("tempdata");
		$data["add_brand_to_database"] = "add_brand_to_database";
		$data["master_title"]=$this->config->item("sitename")." | Add brand";   // Please enter the title of page......
		$data["master_body"]="add_brand";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		if($this->uri->segment(3)!='' && $this->uri->segment(3)=='0')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_brand");
		}
	}
	
	public function edit_brand()
	{
		$data["do"]="edit";
		$brandid=$this->uri->segment(3);
		$data["branddata"]=$this->products_model->getIndividualBrand($brandid);	
		$data["add_brand_to_database"] = "add_brand_to_database";
		$data["master_title"]=$this->config->item("sitename")." | Edit Category";   // Please enter the title of page......
		$data["master_body"]="add_brand";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		if($this->uri->segment(4)!='' && $this->uri->segment(4)=='2')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_brand");
		}
	}
	
	public function add_brand_to_database()
	{
		$arr["brand_id"] = trim($this->input->post("brand_id"));
		$arr["brand_name"]=trim(mysql_real_escape_string($this->input->post("brand_name")));
		$arr["brand_status"] = 1;	
		if($arr["brand_id"]==""){
			$arr["brand_created_time"] = time();
		}
		else{
			$arr["brand_updated_time"] = time();
		}
		$this->session->set_flashdata("tempdata",$arr);	
		if($arr["brand_id"] == ""){
			
			//to create slug for product
			$string = $arr['brand_name'];
			$table = 'tbl_brand';
			$field = 'slug';
			$key = 'brand_id';
			$value = '';
			$arr['slug'] = $this->common->create_unique_slug($string,$table,$field,$key,$value);
		}
		else{
			$string = $arr['brand_name'];
			$table = 'tbl_brand';
			$field = 'slug';
			$key = 'brand_id';
			$value = $arr["brand_id"];
			$arr['slug'] = $this->common->create_unique_slug($string,$table,$field,$key,$value);
		}
		if($this->validations->validate_brand($arr))
		{
			//print_r($arr);
			if($this->products_model->add_edit_brand($arr)){
				if($arr["brand_id"] == ''){
					$err=0;	
					$this->session->set_flashdata("successmsg","brand added succesfully");
				}
				else{
					$err=2;	
					$this->session->set_flashdata("successmsg","brand edited succesfully");
				}
			}	
			else
			{
				$err=1;
				$this->session->set_flashdata("errormsg","There was error in adding this brand.");
			}
			if($err==0){
				redirect(base_url().$this->router->class."/add_brand"."/0");
			}
			else if($err==1){
				redirect(base_url().$this->router->class."/add_brand"."/1");
			}
			else if($err==2){
				redirect(base_url().$this->router->class."/edit_brand/".$arr["brand_id"]."/2");
			}
		}
		else
		{
			if($arr["brand_id"] == ''){
				$err=1;	
				redirect(base_url().$this->router->class."/add_brand");
			}
			else{
				$err=1;	
				redirect(base_url().$this->router->class."/edit_brand/".$arr["brand_id"]);
			}
		}
		
	}
	
	public function archive_brand()
	{
		$delid=$this->uri->segment(3);
		if($delid!='')
		{	
			$this->products_model->archive_brand($delid);
			$this->session->set_flashdata("successmsg","brand archived successfully");	
			redirect(base_url().$this->router->class."/manage_brand");
		}
		else
		{
			$data=$this->input->post("chk");
			if(!isset($_REQUEST["chk"]) && count($_REQUEST["chk"])==0)
			{
				$this->session->set_flashdata("errormsg","No brand selected");	
				redirect(base_url().$this->router->class."/manage_brand");	
			}
			foreach($data as $key=>$val)
			{
				$this->products_model->archive_brand($val);
			}
			
			$this->session->set_flashdata("successmsg","Selected brands archived successfully");	
			redirect(base_url().$this->router->class."/manage_brand");
		}	
	}
	
	public function enable_disable_brand()
	{
		$categoryid=$this->uri->segment(3);
		$status=$this->uri->segment(4);
		if($status==0)
		{
			$show_status="deactivated";	
		}	
		else
		{
			$show_status="activated";	
		}
		
		$this->products_model->enable_disable_brand($categoryid,$status);
		$this->session->set_flashdata("successmsg","brand ".$show_status." successfully");	
		redirect(base_url().$this->router->class."/manage_brand");
	}
	
	
	public function view_brand()
	{
		$id=$this->uri->segment(3);
		
		if($id == "" || $id == 0)
		{
			$data["master_item"]="error";
			$data["master_title"]="Page not found";   // Please enter the title of page......
			$data["master_body"]=$this->config->item("error_page");  //  Please use view name in this field please do not include '.php' for including view name
			$this->load->theme('mainlayout',$data);  // Loading theme	
			die;			
		}
		else
		{
			$data["resultset"]=$this->products_model->getIndividualBrand($id);
		}
		$data["item"]="Brand";
		$data["master_title"] = $this->config->item("sitename")." | View brand";   // Please enter the title of page......
		$data["master_body"] = "view_brand";  //  Please use view name in this field please do not include '.php' for including view name
		$this->load->theme('mainlayout',$data);	
	}
	/*brands  ends*/
	/**********************************************************Category functions ************************************************/
	
	public function manage_category()
	{		
		$data["item"]="Category";
		$data["master_title"]=$this->config->item("sitename")." | Manage Categories";   // Please enter the title of page......
		$data["master_body"]="manage_category";  //  Please use view name in this field please do not include '.php' for including view name
		
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=isset($_GET["per_page"]) ? $_GET["per_page"] : ""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }
		else{
            if(!is_numeric($page)){
            	redirect(BASEURL.'404');
            }
			else{
            	$page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url()."products/manage_category/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->products_model->getCategoryData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$data["resultset"]=$this->products_model->getCategoryData($searcharray);
		$this->load->theme('mainlayout',$data);	
	}
	
	public function add_category()
	{
		$data["do"]="add";
		$data["item"]="Category";
		$data["categorydata"]=$this->session->flashdata("tempdata");
		$data["add_category_to_database"] = "add_category_to_database";
		$data["master_title"]=$this->config->item("sitename")." | Add Category";   // Please enter the title of page......
		$data["master_body"]="add_category";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		
		if($this->uri->segment(3)!=''&& $this->uri->segment(3)=='0')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_category");
		}
	}
	
	public function edit_category()
	{
		$data["do"]="edit";
		$categoryid=$this->uri->segment(3);
		$data["categorydata"]=$this->products_model->getIndividualCategory($categoryid);	
		$data["add_category_to_database"] = "add_category_to_database";
		$data["master_title"]=$this->config->item("sitename")." | Edit Category";   // Please enter the title of page......
		$data["master_body"]="add_category";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		
		if($this->uri->segment(4)!='' && $this->uri->segment(4)=='2')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_category");
		}
	}
	
	public function add_category_to_database()
	{
		$arr["id"] = trim($this->input->post("id"));
		$arr["category_name"]=trim(mysql_real_escape_string($this->input->post("category_name")));
		$arr["category_status"] = 1;	
		$this->session->set_flashdata("tempdata",$arr);	
		
		if($arr["id"] == ""){
			
			//to create slug for product
			$string = $arr['category_name'];
			$table = 'tbl_categories';
			$field = 'slug';
			$key = 'id';
			$value = '';
			$arr['slug'] = $this->common->create_unique_slug($string,$table,$field,$key,$value);
		}
		else{
			$string = $arr['category_name'];
			$table = 'tbl_categories';
			$field = 'slug';
			$key = 'id';
			$value = $arr["id"];
			$arr['slug'] = $this->common->create_unique_slug($string,$table,$field,$key,$value);
		}
		
		if($this->validations->validate_category($arr))
		{
			//print_r($arr);
			if($this->products_model->add_edit_category($arr)){
				if($arr["id"] == ''){
					$err=0;	
					$this->session->set_flashdata("successmsg","category added succesfully");
				}
				else{
					$err=2;	
					$this->session->set_flashdata("successmsg","category edited succesfully");
				}
			}	
			else
			{
				$err=1;
				$this->session->set_flashdata("errormsg","There was error in adding this category.");
			}
			if($err==0){
				redirect(base_url().$this->router->class."/add_category"."/0");
			}
			else if($err==1){
				redirect(base_url().$this->router->class."/add_category"."/1");
			}
			else if($err==2){
				redirect(base_url().$this->router->class."/edit_category/".$arr["id"]."/2");
			}
		}
		else
		{
			if($arr["id"]==""){
				$err=1;	
				redirect(base_url().$this->router->class."/add_category");
			}
			else{
				$err=1;	
				redirect(base_url().$this->router->class."/edit_category/".$arr["id"]);
			}
		}
		
	}
	
	public function archive_category()
	{
		$delid=$this->uri->segment(3);
		if($delid!='')
		{	
			$this->products_model->archive_category($delid);
			$this->session->set_flashdata("successmsg","Category archived successfully");	
			redirect(base_url().$this->router->class."/manage_category");
		}
		else
		{
			$data=$this->input->post("chk");
			if(!isset($_REQUEST["chk"]) && count($_REQUEST["chk"])==0)
			{
				$this->session->set_flashdata("errormsg","No category selected");	
				redirect(base_url().$this->router->class."/manage_category");	
			}
			foreach($data as $key=>$val)
			{
				$this->products_model->archive_category($val);
			}
			
			$this->session->set_flashdata("successmsg","Selected categories archived successfully");	
			redirect(base_url().$this->router->class."/manage_category");
		}	
	}
	
	public function enable_disable_category()
	{
		$categoryid=$this->uri->segment(3);
		$status=$this->uri->segment(4);
		if($status==0)
		{
			$show_status="deactivated";	
		}	
		else
		{
			$show_status="activated";	
		}
		
		$this->products_model->enable_disable_category($categoryid,$status);
		$this->session->set_flashdata("successmsg","Category ".$show_status." successfully");	
		redirect(base_url().$this->router->class."/manage_category");
	}
	
	
	public function view_category()
	{
		$categoryid=$this->uri->segment(3);
		$data["resultset"]=$this->products_model->getIndividualCategory($categoryid);
		$data["item"]="Category";
		$data["master_title"] = $this->config->item("sitename")." | View category";   // Please enter the title of page......
		$data["master_body"] = "view_category";  //  Please use view name in this field please do not include '.php' for including view name
		$this->load->theme('mainlayout',$data);	
	}
	/**********************************************************Category functions end ************************************************/

	
	/**********************************************************Sub Category functions ************************************************/
	
	public function manage_sub_category()
	{
		
		$data["item"]="Sub cat";
		$data["master_title"]= $this->config->item("sitename")." | Sub-Categories";   // Please enter the title of page......
		$data["master_body"]="manage_sub_category";  //  Please use view name in this field please do not include '.php' for including view name
		
			/*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            	redirect(BASEURL.'404');
            }
			else{
            	$page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/manage_sub_category/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->products_model->getSubCategoryData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$data["resultset"]=$this->products_model->getSubCategoryData($searcharray);
		#$data["resultset"]=$this->products_model->getSubCategoryData($_GET);
		$this->load->theme('mainlayout',$data);	
	}
	public function view_sub_category()
	{
		$categoryid=$this->uri->segment(3);
		$data["resultset"]=$this->products_model->getIndividualSubCategory($categoryid);
		$data["item"]="Sub Category";
		$data["master_title"] = $this->config->item("sitename")." | View sub-category";   // Please enter the title of page......
		$data["master_body"] = "view_sub_category";  //  Please use view name in this field please do not include '.php' for including view name
		$this->load->theme('mainlayout',$data);	
	}
	public function archive_sub_category()
	{
		$delid=$this->uri->segment(3);
		if($delid!='')
		{	
			$this->products_model->archive_sub_category($delid);
			$this->session->set_flashdata("successmsg","Subcategory archived successfully");	
			redirect(base_url().$this->router->class."/manage_sub_category");
		}
		else
		{
			$data=$this->input->post("chk");
			if(!isset($_REQUEST["chk"]) && count($_REQUEST["chk"])==0)
			{
				$this->session->set_flashdata("errormsg","No sub-category selected");	
				redirect(base_url().$this->router->class."/manage_sub_category");	
			}
			foreach($data as $key=>$val)
			{
				$this->products_model->archive_sub_category($val);
			}
			
			$this->session->set_flashdata("successmsg","Selected Subcategory archived successfully");	
			redirect(base_url().$this->router->class."/manage_sub_category");
		}	
	}
	
	public function enable_disable_sub_category()
	{
		$categoryid=$this->uri->segment(3);
		$status=$this->uri->segment(4);
		if($status==0)
		{
			$show_status="deactivated";	
		}	
		else
		{
			$show_status="activated";	
		}
		
		$this->products_model->enable_disable_category($categoryid,$status);
		$this->session->set_flashdata("successmsg","Subcategory ".$show_status." successfully");	
		redirect(base_url()."products/manage_sub_category");
	}
	
	public function add_sub_category()
	{
		$data["do"]="add";
		$data["item"]="Sub category";
		$data["categorydata"]=$this->session->flashdata("tempdata");
		$data["add_sub_category_to_database"] = "add_sub_category_to_database";
		$data["master_title"]= $this->config->item("sitename")." | Add sub category";   // Please enter the title of page......
		$data["master_body"]="add_sub_category";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		
		if($this->uri->segment(3) != ''&& $this->uri->segment(3) == '0')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_sub_category");
		}
	}
	
	public function edit_sub_category()
	{
		$data["do"]="edit";
		$categoryid=$this->uri->segment(3);
		$data["categorydata"]=$this->products_model->getIndividualCategory($categoryid);
		$data["add_sub_category_to_database"] = "add_sub_category_to_database";
		$data["master_title"]=$this->config->item("sitename")." | Edit sub category";   // Please enter the title of page......
		$data["master_body"]="add_sub_category";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		
		if($this->uri->segment(4)!='' && $this->uri->segment(4)=='2')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_sub_category");
		}
	}
	
	public function add_sub_category_to_database()
	{
		$arr["id"] = $this->input->post("id");
		$arr["category_name"] = trim(mysql_real_escape_string($this->input->post("category_name")));	
		$arr["parent_category"] = trim($this->input->post("parent_category"));
		$this->session->set_flashdata("tempdata",$arr);	
		if($arr["id"] == ""){
			
			//to create slug for product
			$string = $arr['category_name'];
			$table = 'tbl_categories';
			$field = 'slug';
			$key = 'id';
			$value = '';
			$arr['slug'] = $this->common->create_unique_slug($string,$table,$field,$key,$value);
		}
		else{
			$string = $arr['category_name'];
			$table = 'tbl_categories';
			$field = 'slug';
			$key = 'id';
			$value = $arr["id"];
			$arr['slug'] = $this->common->create_unique_slug($string,$table,$field,$key,$value);
		}
		if($this->validations->validate_sub_category($arr))
		{
			if($this->products_model->add_edit_sub_category($arr))
			{
				if($arr["id"] == ''){
					$err=0;	
					$this->session->set_flashdata("successmsg","Sub-category added succesfully");
				}
				else{
					$err=2;	
					$this->session->set_flashdata("successmsg","Sub-category edited succesfully");
				}
			}	
			else
			{
				$this->session->set_flashdata("errormsg","There was an error in adding this sub-category.");
				$err=1;
			}
			
			if($err==0){
				redirect(base_url().$this->router->class."/add_sub_category"."/0");
			}
			else if($err==1){
				redirect(base_url().$this->router->class."/add_sub_category"."/1");
			}
			else if($err==2){
				redirect(base_url().$this->router->class."/edit_sub_category/".$arr["id"]."/2");
			}
		}
		else
		{
			if($arr["id"]==""){
				$err=1;	
				redirect(base_url().$this->router->class."/add_sub_category");
			}
			else{
				$err=1;	
				redirect(base_url().$this->router->class."/edit_sub_category/".$arr["id"]);
			}
		}
	}
	
	/**********************************************************Sub Category functions ends************************************************/

	public function manage_product()
	{
		
		$data["item"]="Product";
		$data["master_title"] = $this->config->item("sitename")." | Manage Product";   // Please enter the title of page......
		$data["master_body"] = "manage_product";  //  Please use view name in this field please do not include '.php' for including view name
		
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/manage_product/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->products_model->getProductData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$data["resultset"]=$this->products_model->getProductData($searcharray);
		//print_r($data["resultset"]);die;
		#$data["resultset"]=$this->products_model->getProductData($_GET);
		$this->load->theme('mainlayout',$data);	
	}
	
	public function add_product()
	{
		$data["do"]="add";
		$data["item"]="Product";
		$data["productdata"]=$this->session->flashdata("tempdata");
		$data["add_product_to_database"] = "add_product_to_database";
		$data["master_title"]= $this->config->item("sitename")." | Add Product";// Please enter the title of page......
		$data["master_body"]="add_product";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		
		if($this->uri->segment(3) != '' && $this->uri->segment(3) == '0')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_product");
		}
	}
	
	public function edit_product()
	{
		$data["do"] = "edit";
		$productid = $this->uri->segment(3);
		$data["productdata"]=array();
		$data["productdata"] = $this->products_model->getIndividualProductData($productid);
		$data["productdata"]['productimages'] = $this->products_model->get_product_images($productid);
		//print_r($data["productdata"]['productimages']);die;
		$data["productdata"]["display_image"]= $this->products_model->get_product_display_images($productid);
		
		$data["add_product_to_database"] = "add_product_to_database";
		$data["master_title"] = $this->config->item("sitename")." | Edit product";   // Please enter the title of page......
		$data["master_body"]="add_product";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		
		if($this->uri->segment(4)!='' && $this->uri->segment(4)=='2')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_product");
		}
	}
	
	
	public function get_subcategory($cat_id = NULL,$subcat_id =NULL){
	
		$data = $this->products_model->get_category_byid($cat_id);
		/*echo "<pre>";print_r($data);die;*/
		//if subcategory exists then there will be a drop down other wise empty drop down 
		if($data > 0){
			$result ='<select name="subcategory" id="subcategory" style="width:220px; height:35px;" >';
			$result .='<option value="">Select subcategory</option>';
			$i=0;
			foreach($data as $key => $val)
			{
				if($subcat_id == $val['id'])
					{$msg .= ' selected=selected';}else {$msg = '';}
					$result .='<option value='.$val['id'].' '.$msg.'>'.$val['category_name'].'</option>';
					$i++;
				}
			$result .='</select>';
			}
			else{
				$result ='<select name="subcategory" id="subcategory" style="width:220px; height:35px;" >';
				$result .='<option value="">Select subcategory</option>';
				$result .='</select>';
			}
		echo $result;
	}
	public function add_product_to_database()
	{
		$arr["do"] = $this->input->post("do");//comes from hidden field
		$arr["product_id"] = $this->input->post("product_id");
		$arr["title"] = trim(mysql_real_escape_string($this->input->post("title")));	
		$arr["category"] = trim($this->input->post("category"));
		$arr["subcategory"] = trim($this->input->post("subcategory"));
		$arr["short_description"] = trim($this->input->post("short_description"));
		$arr["long_description"] = trim($this->input->post("long_description"));
		$arr["brand"] = trim($this->input->post("brand"));
		$arr["price"] = trim($this->input->post("price"));
		$arr["condition"] = trim($this->input->post("condition"));
		$arr["meta_tag"] = trim(mysql_real_escape_string($this->input->post("meta_tag")));
		$arr["product_availability"] = trim(mysql_real_escape_string($this->input->post("product_availability")));
		$arr["discount"] = trim($this->input->post("discount"));
		$img["productimages"] = $this->input->post("productimage");
		$img["display_image"] = $this->input->post("display_image");
        

		if($arr["product_id"] == ""){
			$arr["product_created_time"] = time();
			$arr["product_status"] = 1;
			//to create slug for product
			$string = $arr['title'];
			$table = 'tbl_product';
			$field = 'product_slug';
			$key = 'product_id';
			$value = '';
			$arr['product_slug'] = $this->common->create_unique_slug($string,$table,$field,$key,$value);
		}
		else{
			$arr["product_updated_time"] = time();
			$arr["product_status"] = 1;
			//to create slug for product
			$string = $arr['title'];
			$table = 'tbl_product';
			$field = 'product_slug';
			$key = 'product_id';
			$value = $arr["product_id"];
			$arr['product_slug'] = $this->common->create_unique_slug($string,$table,$field,$key,$value);
		}
		
		
		//add multiple variation for a product
		$data['color'] = $this->input->post("color");//color attribute
		$data['size'] = $this->input->post("size");//size attribute
		$data['quantity'] = $this->input->post("quantity");//quantity under this 
		
		
		$this->session->set_flashdata("tempdata",$arr);	
		
		if($this->validations->validate_product_data($arr))
		{
			$do = $arr["do"];
			unset($arr["do"]);
			//echo $this->products_model->add_edit_product($arr);die;
			if($this->products_model->add_edit_product($arr))
			{
				if($do=="add"){
					//on addition pass id
					$data['product_id'] = $this->db->insert_id();
				}
				else{//on edit pass product id  
					$data['product_id'] = $arr['product_id'];
				}
				//add variations of product 
				$product_variation = $this->products_model->add_product_variations($data,$do);
				if($do=="add"){
					
					  ///// insert *******************************default_image*************************8 //////
					   $product_attribute_images_deafult["product_id"] = $data['product_id'];
					   $product_attribute_images_deafult["image_name"] = $img["display_image"];
					   $product_attribute_images_deafult["isDefault"]="1";
					   $product_attribute_images_deafult["image_status"]="1";
					   
					   $this->products_model->insert_product_image($product_attribute_images_deafult);
					//////support images //////		
					foreach($img["productimages"] as $k=>$v){
						if($v!=""){
							$product_attribute_images["product_id"] = $data['product_id'];
							$product_attribute_images["image_name"] = $v;
							$product_attribute_images["isDefault"] = "0";		
							$product_attribute_images["image_status"] = "1";	
							$this->products_model->insert_product_image($product_attribute_images);
						}	
					 }//images ends
				}
				else{
						
						///// default_image //////
					   $this->products_model->delete_product_display_image($data['product_id']);
					   $this->products_model->delete_product_support_image($data['product_id']);
					   
					     $product_attribute_images_deafult["product_id"] = $data['product_id'];
					   $product_attribute_images_deafult["image_name"] = $img["display_image"];
					   $product_attribute_images_deafult["isDefault"] = "1";
					   $product_attribute_images_deafult["image_status"] = "1";
					   $this->products_model->insert_product_image($product_attribute_images_deafult);
					   
					      //////support images //////		
						foreach($img["productimages"] as $k=>$v){
							if($v!=""){
								$product_attribute_images1["product_id"] = $data['product_id'];
								$product_attribute_images1["image_name"] = $v;
								$product_attribute_images1["isDefault"] = "0";		
								$product_attribute_images1["image_status"] = "1";	
								
								$this->products_model->insert_product_image($product_attribute_images1);
							}	
						 }
						
				}
				if($arr["product_id"] == ''){
					$err=0;	
					$this->session->set_flashdata("successmsg","Product added succesfully");
				}
				else{
					$err=2;	
					$this->session->set_flashdata("successmsg","Product edited succesfully");
				}
			}	
			else
			{
				$this->session->set_flashdata("errormsg","There was an error in adding this Product.");
				$err=1;
			}
			
			if($err==0){
				redirect(base_url().$this->router->class."/add_product"."/0");
			}
			else if($err==1){
				if($arr["product_id"]==""){
					redirect(base_url().$this->router->class."/add_product");
				}
				else{
					redirect(base_url().$this->router->class."/edit_product/".$arr["product_id"]);
				}
				//redirect(base_url().$this->router->class."/add_product"."/1");
			}
			else if($err==2){
				redirect(base_url().$this->router->class."/edit_product/".$arr["product_id"]."/2");
			}
		}
		else
		{
			if($arr["product_id"]==""){
				$err=1;	
				redirect(base_url().$this->router->class."/add_product");
			}
			else{
				$err=1;	
				redirect(base_url().$this->router->class."/edit_product/".$arr["product_id"]);
			}
		}
	}
	
	public function getSubCategoryFromCategory()
	{
		$data["resultset"]=$this->products_model->getSubCategoryFromCategory($_GET);
		echo $data["resultset"];
		die;	
	}
	
	public function enable_disable_product()
	{
		$productid=$this->uri->segment(3);
		$status=$this->uri->segment(4);
		if($status==0)
		{
			$show_status="deactivated";	
		}	
		else
		{
			$show_status="activated";	
		}
		
		$this->products_model->enable_disable_product($productid,$status);
		$this->session->set_flashdata("successmsg","Product ".$show_status." successfully");	
		redirect(base_url().$this->router->class."/manage_product");
	}
	
	public function archive_product_property()
	{
		$delid = $this->uri->segment(3);
		if($delid !='')
		{	
			$this->products_model->archive_product_property($delid);
			$this->session->set_flashdata("successmsg","Product's property archived successfully");	
			redirect(base_url().$this->router->class."/manage_product");
		}
	}
	
	public function archive_product()
	{
		$delid = $this->uri->segment(3);
		if($delid !='')
		{	
			$this->products_model->archive_product($delid);
			$this->session->set_flashdata("successmsg","Product archived successfully");	
			redirect(base_url().$this->router->class."/manage_product");
		}
		else
		{
			$data=$this->input->post("chk");
			if(!isset($_REQUEST["chk"]) && count($_REQUEST["chk"])==0)
			{
				$this->session->set_flashdata("errormsg","No product selected");	
				redirect(base_url().$this->router->class."/manage_product");	
			}
			foreach($data as $key=>$val)
			{
				$this->products_model->archive_product($val);
			}
			
			$this->session->set_flashdata("successmsg","Selected products archived successfully");	
			redirect(base_url().$this->router->class."/manage_product");
		}	
	}
	
	public function view_product()
	{
		$productid=$this->uri->segment(3);
		$data["resultset"]=$this->products_model->getIndividualProductData($productid);
		$data["item"]="Product";
		$data["master_title"]="View product";   // Please enter the title of page......
		$data["master_body"]="view_product";  //  Please use view name in this field please do not include '.php' for including view name
		$this->load->theme('mainlayout',$data);	
	}
	
	 public function upload_image()
	 {
		 
		
		$image_info = getimagesize($_FILES["uploadfile"]["tmp_name"]);
		$image_width = $image_info[0];
	    $image_height = $image_info[1];
		
		if($image_width < 118 || $image_height < 187)
		{
			echo "failed|::|Please upload an image with a size of 118 X 187 or greater."; die;
		}
		 $type = explode('/',$_FILES['uploadfile']['type']);
		 $ext = $type['1'];
		 
		 //$image_name= "st_".time()."_".$_FILES['uploadfile']['name'];
		  $image_name= "sus_".time().rand(999,9999).".".$ext; //// craete image no. by using time and random integer to protect duplicate name
          $path = $this->config->item("productimages").$image_name;
		  $path = "../productimages/".$image_name;
		  $thumb = "../productimagesthumbs/".$image_name;
		  $thumb_new = "../productimgaes_newthumbs/".$image_name;
		  
		   chmod("$path",0777);  // set permission to the file.
		  if(copy($_FILES['uploadfile']['tmp_name'], $path))//  upload the file to the server
		  {
		    $this->load->library('image_lib');
		    $config['image_library'] = 'gd2';
			$config['source_image'] = $path;
			$config['create_thumb'] = TRUE;
			$config['maintain_ratio'] = TRUE;
			$config['width'] = 200;
			$config['height'] = 167;
			$config['master_dim'] = 'height';
			$config['new_image'] = $thumb;
			
		    $this->image_lib->clear();
            $this->image_lib->initialize($config);
			$this->image_lib->resize();
			/*$this->image_lib->clear();
			$config['image_library'] = 'gd2';
			$config['source_image'] = $path;
			$config['create_thumb'] = TRUE;
			$config['maintain_ratio'] = TRUE;
			$config['width'] = 124;
			$config['height'] = 167;
			$config['master_dim'] = 'width';
			$config['new_image'] = $thumb_new;
			$this->image_lib->clear();
            $this->image_lib->initialize($config);
			$this->image_lib->resize();*/
			
			$arr[0] = "success";
			$arr[1] = $image_name;
			//echo "success|::|".$image_name;die;	
		  }
		   else {
			   $arr[0] = "error";
			   $arr[1] = "There was a technical error uploading image";
			//echo "error"; die;
		   }
		   $msg_arr = implode("|::|",$arr);
		   echo $msg_arr;die;
}
     public function unlink_image(){
		  $image_name = $this->uri->segment(3);
		   
		  chmod("$path",0777);  // set permission to the file.
		  chmod("$path1",0777); 
		  unlink('../productimages/'.$image_name); 
		  unlink('../productimagesthumbs/'.$image_name);
		  unlink('../productimgaes_newthumbs/'.$image_name);
		  return "success"; die;
     }	
	 
	 public function manage_sell_cloth()
	{
		
		$data["item"]="Sell cloth";
		$data["master_title"] = $this->config->item("sitename")." | Manage sell cloth";   // Please enter the title of page......
		$data["master_body"] = "manage_sell_cloth";  //  Please use view name in this field please do not include '.php' for including view name
		
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/manage_sell_cloth/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->products_model->getSellData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$data["resultset"]=$this->products_model->getSellData($searcharray);
		//print_r($data["resultset"]);die;
		#$data["resultset"]=$this->products_model->getProductData($_GET);
		$this->load->theme('mainlayout',$data);	
	}
	
	
	
	public function edit_sell_cloth()
	{
		$data["do"] = "edit";
		$productid = $this->uri->segment(3);
		$data["selldata"] = $this->products_model->getIndividualSellData($productid);
		$data["add_sell_cloth_to_database"] = "add_sell_cloth_to_database";
		$data["master_title"] = $this->config->item("sitename")." | Edit sell cloth";   // Please enter the title of page......
		$data["master_body"]="add_sell_cloth";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		
		if($this->uri->segment(4)!='' && $this->uri->segment(4)=='2')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_sell_cloth");
		}
	}
	
public function enable_disable_sell_cloth()
	{
		$productid=$this->uri->segment(3);
		$status=$this->uri->segment(4);
		if($status==0)
		{
			$show_status="rejected";	
		}	
		else
		{
			$show_status="accepted";	
		}
		
		$this->products_model->enable_disable_sell_cloth($productid,$status);
		$this->session->set_flashdata("successmsg","Bag request ".$show_status." successfully");	
		redirect(base_url().$this->router->class."/manage_sell_cloth");
	}
	public function archive_sell_cloth()
	{
		$delid = $this->uri->segment(3);
		if($delid !='')
		{	
			$this->products_model->archive_sell_cloth($delid);
			$this->session->set_flashdata("successmsg","Bag request archived successfully");	
			redirect(base_url().$this->router->class."/manage_sell_cloth");
		}
	}
	
	public function view_sell_cloth()
	{
		$id=$this->uri->segment(3);
		
		if($id == "" || $id == 0)
		{
			$data["master_item"]="error";
			$data["master_title"]="Page not found";   // Please enter the title of page......
			$data["master_body"]=$this->config->item("error_page");  //  Please use view name in this field please do not include '.php' for including view name
			$this->load->theme('mainlayout',$data);  // Loading theme	
			die;			
		}
		else
		{
			$data["resultset"]=$this->products_model->view_sell_cloth($id);
		}
		$data["item"]="View sell cloth";
		$data["master_title"] = $this->config->item("sitename")." | View sell cloth";   // Please enter the title of page......
		$data["master_body"] = "view_sell_cloth";  //  Please use view name in this field please do not include '.php' for including view name
		$this->load->theme('mainlayout',$data);	
	}
	/**********************************************************Product inventory functions ************************************************/
	
	public function manage_inventory()
	{
		$data["item"]="Inventory";
		$data["resultset"]=$this->products_model->getProductInventory($_GET);
		$data["master_title"]="Manage Inventory";   // Please enter the title of page......
		$data["master_body"]="manage_inventory";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme	
	}
	
	public function update_inventory()
	{
		$inventoryid=$this->uri->segment(3);
		$data["item"]="Inventory";
		$data["do"]="edit";
		if(count($this->session->flashdata("tempdata"))==1)
		{
			$data["inventorydata"]=$this->products_model->getProductIndiviualInventory($inventoryid);
		}
		else
		{
			$data["inventorydata"]=$this->session->flashdata("tempdata");	
		}
		$data["master_title"]="Update Inventory";   // Please enter the title of page......
		$data["master_body"]="update_inventory";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme			
	}
	
	public function update_inventory_to_database()
	{
		$arr["id"]=$this->input->post("id");	
		$arr["online_available"]=$this->input->post("online_available");
		$arr["offline_available"]=$this->input->post("offline_available");
		$arr["differ_online"]=$this->input->post("differ_online");
		$this->session->set_flashdata("tempdata",$arr);
		if($this->validations->validate_stock($arr))
		{
			if($this->products_model->update_stock_to_database($arr))
			{
				$this->session->set_flashdata("successmsg","Stock updated successfully");
				$err=0;
			}
			else
			{
				$this->session->set_flashdata("errormsg","There was an error in updating the stock.");
				$err=1;
			}	
		}
		else
		{
			$err=1;	
		}
		
		if($err==1)
		{
			redirect(base_url()."products/update_inventory/".$arr["id"]);	
		}	
		else
		{
			redirect(base_url()."products/manage_inventory");	
		}	
	}
	
	/**********************************************************Product inventory functions ends ************************************************/
	
	/*******************************************************Product manufacturer functions starts ************************************************/
	
	public function manage_manufacturer()
	{
		
		$data["item"]="Manufacturer";
		$data["master_title"]="Manage manufacturer";   // Please enter the title of page......
		$data["master_body"]="manage_manufacturer";  //  Please use view name in this field please do not include '.php' for including view name
		
			/*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		//$config['base_url'] = site_url("products/manage_manufacturer/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]));	
		$config['base_url']=base_url()."products/manage_manufacturer/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->products_model->getManufacturerData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$data["resultset"]=$this->products_model->getManufacturerData($searcharray);
		
		#$data["resultset"]=$this->products_model->getManufacturerData($_GET);
		$this->load->theme('mainlayout',$data);	
	}
	
	public function add_manufacturer()
	{
		$data["do"]="add";
		$data["item"]="Manufacturer";
		$data["manufacturerdata"]=$this->session->flashdata("tempdata");
		$data["master_title"]="Add Category";   // Please enter the title of page......
		$data["master_body"]="add_manufacturer";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
	}
	
	public function edit_manufacturer()
	{
		$data["do"]="edit";
		$manufacturerid=$this->uri->segment(3);
		$data["manufacturerdata"]=$this->products_model->getIndividualManufacturer($manufacturerid);	
		$data["master_title"]="Edit Category";   // Please enter the title of page......
		$data["master_body"]="add_manufacturer";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
	}
	
	public function add_manufacturer_to_database()
	{
		$arr["id"]=$this->input->post("id");
		$arr["manufacturer_name"]=$this->input->post("manufacturer_name");	
		$this->session->set_flashdata("tempdata",$arr);	
		if($this->validations->validate_product_manufacturer($arr))
		{
			if($this->products_model->add_edit_manufacturer($arr))
			{
				$err=0;	
				$this->session->set_flashdata("successmsg","Manufacturer added succesfully");
			}	
			else
			{
				$this->session->set_flashdata("errormsg","There was an error in adding this category.");
				$err=1;
			}
		}
		else
		{
			$err=1;	
		}
		
		if($err==0)
		{
			redirect(base_url()."products/manage_manufacturer");		
		}
		else
		{
			if($arr["id"]=="")
			{
				redirect(base_url()."products/add_manufacturer");
			}
			else
			{
				redirect(base_url()."products/edit_manufacturer/".$arr["id"]);	
			}
		}	
	}
	
	public function archive_manufacturer()
	{
		$delid=$this->uri->segment(3);
		if($delid!='')
		{	
			$this->products_model->archive_manufacturer($delid);
			$this->session->set_flashdata("successmsg","Manufacturer archived successfully");	
			redirect(base_url()."products/manage_manufacturer");
		}
		else
		{
			$data=$this->input->post("chk");
			if(!isset($_REQUEST["chk"]) && count($_REQUEST["chk"])==0)
			{
				$this->session->set_flashdata("errormsg","No manufacturer selected");	
				redirect(base_url()."products/manage_manufacturer");	
			}
			foreach($data as $key=>$val)
			{
				$this->products_model->archive_manufacturer($val);
			}
			
			$this->session->set_flashdata("successmsg","Selected manufacturer archived successfully");	
			redirect(base_url()."products/manage_manufacturer");
		}	
	}
	
	public function enable_disable_manufacturer()
	{
		$categoryid=$this->uri->segment(3);
		$status=$this->uri->segment(4);
		if($status==0)
		{
			$show_status="deactivated";	
		}	
		else
		{
			$show_status="activated";	
		}
		
		$this->products_model->enable_disable_manufacturer($categoryid,$status);
		$this->session->set_flashdata("successmsg","Manufacturer ".$show_status." successfully");	
		redirect(base_url()."products/manage_manufacturer");
	}
	
	/*********************************************Product manufacturer functions starts ************************************************/
	
	/*********************************************Product images functions starts ************************************************/
	
	public function manage_image()
	{
		$data["do"]="add";
		$data["item"]="Image";
		$data["master_title"]="Manage Image";   // Please enter the title of page......
		$data["master_body"]="manage_image";  //  Please use view name in this field please do not include '.php' for including view name	
		
		
			/*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		//$config['base_url'] = site_url("products/manage_image/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]));	
		$config['base_url']=base_url()."products/manage_image/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->products_model->getProductImages($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$data["resultset"]=$this->products_model->getProductImages($searcharray);
		
		#$data["resultset"]=$this->products_model->getProductImages($_GET);
		
		$this->load->theme('mainlayout',$data);  // Loading theme
	}
	
	public function archive_image()
	{
		$imageid=$this->uri->segment(3);
		$delid=$this->uri->segment(3);
		if($delid!='')
		{	
			$this->products_model->archive_image($imageid);
			$this->session->set_flashdata("successmsg","Image archived successfully");	
			redirect(base_url()."products/manage_image");
		}
		else
		{
			$data=$this->input->post("chk");
			if(!isset($_REQUEST["chk"]) && count($_REQUEST["chk"])==0)
			{
				$this->session->set_flashdata("errormsg","No image selected");	
				redirect(base_url()."products/manage_image");	
			}
			foreach($data as $key=>$val)
			{
				$this->products_model->archive_image($val);
			}
			
			$this->session->set_flashdata("successmsg","Selected image archived successfully");	
			redirect(base_url()."products/manage_image");
		}	
	}
	
	public function enable_disable_image()
	{
		$imageid=$this->uri->segment(3);
		$status=$this->uri->segment(4);
		if($status==0)
		{
			$show_status="deactivated";	
		}	
		else
		{
			$show_status="activated";	
		}
		
		$this->products_model->enable_disable_image($imageid,$status);
		$this->session->set_flashdata("successmsg","Image ".$show_status." successfully");	
		redirect(base_url()."products/manage_image");
	}
	
	public function make_it_default()
	{
		$imageid=$this->uri->segment(3);
		$productid=$this->products_model->make_image_as_default($imageid);
		$this->session->set_flashdata("successmsg","This image has been set as the default image");	
		redirect(base_url()."products/manage_image/?product=".$productid);	
	}
	
	public function manage_product_variations()
	{
		$data["item"]="Variation";
		$product_id=$this->uri->segment(3);
		$data["productid"]=$product_id;
		$data["item"]="Variations";
		$data["resultset"]=$this->products_model->getProductVariations($product_id);
		$data["master_title"]="Manage Variation";   // Please enter the title of page......
		$data["master_body"]="manage_product_variations";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme			
	}
	
	public function enable_disable_product_variation()
	{
		$variation_id=$this->uri->segment(4);
		$status=$this->uri->segment(5);
		$productid=$this->uri->segment(3);
		if($status==0)
		{
			$show_status="deactivated";	
		}	
		else
		{
			$show_status="activated";	
		}
		
		$this->products_model->enable_disable_product_variation($variation_id,$status);
		$this->session->set_flashdata("successmsg","Variations ".$show_status." successfully");	
		redirect(base_url()."products/manage_product_variations/".$productid);
	}
	
	public function archive_product_variations()
	{
		$delid=$this->uri->segment(4);
		$productid=$this->uri->segment(3);
		if($delid!='')
		{	
			$this->products_model->archive_product_variations($delid);
			$this->session->set_flashdata("successmsg","Variations archived successfully");	
			redirect(base_url()."products/manage_product_variations/".$productid);
		}
		else
		{
			$data=$this->input->post("chk");
			$productid=$this->uri->segment(3);
			if(!isset($_REQUEST["chk"]) && count($_REQUEST["chk"])==0)
			{
				$this->session->set_flashdata("errormsg","No variation selected");	
				redirect(base_url()."products/manage_product_variations/".$productid);	
			}
			foreach($data as $key=>$val)
			{
				$this->products_model->archive_product_variations($val);
			}
			
			$this->session->set_flashdata("successmsg","Selected variation archived successfully");	
			redirect(base_url()."products/manage_product_variations/".$productid);
		}	
	}
	
	public function view_product_variations_details()
	{
		$data["item"]="Variation";
		$productid=$this->uri->segment(3);
		$variationid=$this->uri->segment(4);
		$data["variationid"]=$variationid;
		$data["resultset"]=$this->products_model->getVariationDetails($variationid);
		$data["master_title"]="Manage Variation";   // Please enter the title of page......
		$data["master_body"]="view_product_variations_details";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme	
	}
	
	public function featured_product()
	{
		$productid=$this->uri->segment(3);
		$featureid=$this->uri->segment(4);
		if($this->products_model->changefeatureproduct($productid,$featureid))
		{
			$this->session->set_flashdata("successmsg","Product featured successfully");
			redirect(base_url()."products/manage_product");	
		}	
		else
		{
			$this->session->set_flashdata("errormsg","This product has been removed from the featured list");	
			redirect(base_url()."products/manage_product");
		}
	}
	
	public function manage_invite_friend(){ 
		
		$data["item"]="Invite friend";
		$data["master_title"] = $this->config->item("sitename")." | Invite friend";   // Please enter the title of page......
		$data["master_body"]="manage_invite_friend";  //  Please use view name in this field please do not include '.php' for including view name
		
		
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=isset($_GET["per_page"]) ? $_GET["per_page"] : ""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/manage_invite_friend/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->products_model->getFriendData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$data["resultset"]=$this->products_model->getFriendData($searcharray);
		$this->load->theme('mainlayout',$data);	
		}
	
	public function add_invite_friend()
	{
		$data["do"] = "add";
		$data["item"] = "Invite friend";
		$data["frienddata"] = $this->session->flashdata("tempdata");
		$data["add_invite_friend_to_database"] = "add_invite_friend_to_database";
		$data["master_title"] = $this->config->item("sitename")." | Add invite friend";   // Please enter the title of page......
		$data["master_body"] = "add_invite_friend";  //  Please use view name in this field please do not include '.php' for including view name	
		
		$this->load->theme('mainlayout',$data);  // Loading theme
		if($this->uri->segment(3)!='' && $this->uri->segment(3)=='0')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_invite_friend");
		}
	}
	
	public function edit_invite_friend()
	{
		$data["do"] = "edit";
		$id = $this->uri->segment(3);
		$data["frienddata"] = $this->products_model->getIndividualFriend($id);	
		//debug($data["frienddata"]);die;
		$data["add_invite_friend_to_database"] = "add_invite_friend_to_database";
		$data["master_title"] = $this->config->item("sitename")." | edit invite friend";   // Please enter the title of page......
		$data["master_body"] = "add_invite_friend";  //  Please use view name in this field please do not include '.php' for including view name	
		$this->load->theme('mainlayout',$data);  // Loading theme
		
		if($this->uri->segment(4)!='' && $this->uri->segment(4)=='2')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_invite_friend");
		}
	}
	
	public function add_friend_to_database()
	{
		$arr["id"] = $this->input->post("id");
		$arr["number"] = $this->input->post("number");
		$arr["type"] = $this->input->post("type");
		$arr["value"] = $this->input->post("value");
		$arr["invite_friend_status"] = 1;	
		/*debug($arr);
		die;*/
		if($arr["id"]==""){
			$arr["created_time"] = time();
		}
		else{
			$arr["updated_time"] = time();
		}
		
		$this->session->set_flashdata("tempdata",$arr);	
		
		if($this->validations->validate_invite_friend($arr))
		{
			//print_r($arr);
			if($this->products_model->add_edit_invite_friend($arr)){
				if($arr["id"] == ''){
					$err=0;	
					$this->session->set_flashdata("successmsg","invite friend added succesfully");
				}
				else{
					$err=2;	
					$this->session->set_flashdata("successmsg","invite friend edited succesfully");
				}
			}	
			else
			{
				$err=1;
				$this->session->set_flashdata("errormsg","There was error in adding this invite friend.");
			}
			if($err==0){
				redirect(base_url().$this->router->class."/add_invite_friend"."/0");
			}
			else if($err==1){
				redirect(base_url().$this->router->class."/add_invite_friend"."/1");
			}
			else if($err==2){
				redirect(base_url().$this->router->class."/edit_invite_friend/".$arr["id"]."/2");
			}
		}
		else
		{
			if($arr["id"] == ''){
				$err=1;	
				redirect(base_url().$this->router->class."/add_invite_friend/");
			}
			else{
				$err=1;	
				redirect(base_url().$this->router->class."/edit_invite_friend/".$arr["id"]);
			}
		}
	}
	public function archive_invite_friend()
	{
		$delid = $this->uri->segment(3);
		if($delid !='')
		{	
			$this->products_model->archive_invite_friend($delid);
			$this->session->set_flashdata("successmsg","Invite friend archived successfully");	
			redirect(base_url().$this->router->class."/manage_invite_friend/".$productid);
		}
	}
	/*********************************************Product imsges functions ends ************************************************/
}
?>