<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class users extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
		$this->load->helper('url');
	}
		
	public function index()
	{
		$this->manage_user();	
	}
	
	public function add_user()
	{	
		
		$data["item"] = "user";
		$data["do"] = "add";
		$data["userdata"] = $this->session->flashdata("tempdata");
		$data["add_user_to_database"] = "add_user_to_database";
		$data["manage_user"] = "manage_user";
		$data["master_title"] = $this->config->item("sitename")." | Add user";   // Please enter the title of page......
		$data["master_body"] = "add_user";  //  Please use view name in this field please do not include '.php' for including view name
		$this->load->theme('mainlayout',$data);
		
		if($this->uri->segment(3)!=''&& $this->uri->segment(3)=='0')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_user");
		}
	}
	
	public function edit_user()
	{
		$data["item"]="user";
		$data["do"]="edit";
		$userid = $this->uri->segment(3);
		$data["userdata"]=$this->user_model->getIndividualUserData($userid);
		$data["add_user_to_database"]="add_user_to_database";
		$data["manage_user"]="manage_user";
		$data["master_title"]=$this->config->item("sitename")." | Edit user";   // Please enter the title of page......
		$data["master_body"]="add_user";  //  Please use view name in this field please do not include '.php' for including view name
		$this->load->theme('mainlayout',$data);	
		
		if($this->uri->segment(4)!=''&& $this->uri->segment(4)=='2')
		{
			header("Refresh:3;url=".base_url().$this->router->class."/manage_user");
		}
	}	
		

	public function add_user_to_database()
	{
		
		
		$arr["id"] = trim($this->input->post("id"));
		$arr["email"] = trim(mysql_real_escape_string($this->input->post("email")));
		$arr["password"] = trim(mysql_real_escape_string($this->input->post("password")));
		$arr["user_status"]=1;
		$arr["created_on"]=time();
		/*$arr["first_name"] = trim(mysql_real_escape_string($this->input->post("first_name")));
		$arr["last_name"] = trim(mysql_real_escape_string($this->input->post("last_name")));
		$arr["username"] = trim(mysql_real_escape_string($this->input->post("username")));
		$arr["zip"] = trim(mysql_real_escape_string($this->input->post("zip")));
		$arr["address"] = trim(mysql_real_escape_string($this->input->post("address")));
		$arr["phone"] = trim(mysql_real_escape_string($this->input->post("phone")));
		*/
		$this->session->set_flashdata("tempdata",$arr);	
		
			if($this->validations->validate_user_data($arr)){
				//print_r($arr);
				if($this->user_model->add_edit_user($arr)){
					
					if($arr["id"] == ''){
						$err=0;	
						$this->session->set_flashdata("successmsg","user added succesfully");
					}
					else{
						$err=2;	
						$this->session->set_flashdata("successmsg","user Edited succesfully");
					}
				}	
				else
				{
					$this->session->set_flashdata("errormsg","There was error in adding this user.");
					$err=1;
				}
				if($err==0){
					redirect(base_url().$this->router->class."/add_user"."/0");
				}
				else if($err==1){
					redirect(base_url().$this->router->class."/add_user"."/1");
				}
				else if($err==2){
					redirect(base_url().$this->router->class."/edit_user/".$arr["id"]."/2");
				}
			}
			else{
				if($arr["id"]==""){
					redirect(base_url().$this->router->class."/add_user");
				}
				else{
					redirect(base_url().$this->router->class."/edit_user/".$arr["id"]);
				}
			}
	}
	
	public function manage_user()

	{

		$data["item"]="User";
		$data["master_title"]="Manage user";   // Please enter the title of page......
		$data["master_body"]="manage_user";  //  Please use view name in this field please do not include '.php' for including view name
			/*--------------------------Paging code starts---------------------------------------------------*/

		$page=isset($_GET["per_page"])?$_GET["per_page"]:""; //$this->input->get("page");
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            redirect(BASEURL.'404');
            }else{
            $page = $page;
            }
        }
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/manage_user/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		$config['total_rows']=count($this->user_model->getUserdata($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$data["resultset"]=$this->user_model->getUserdata($searcharray);
		$data["count"]=$this->user_model->getTotalUsers();
		$this->load->theme('mainlayout',$data);  // Loading theme
	}
	public function enable_disable_user()
	{
		$userid=$this->uri->segment(3);
		$status=$this->uri->segment(4);
		if($status==0)
		{
			$show_status="deactivated";	
		}	
		else
		{
			$show_status="activated";	
		}
		$this->user_model->enable_disable_user($userid,$status);
		$this->session->set_flashdata("successmsg","User ".$show_status." successfully");	
		redirect(base_url().$this->router->class."/manage_user");	
	}

	

	public function archive_user()

	{

		$delid=$this->uri->segment(3);

		if($delid!='')

		{	
			$this->user_model->archive_user($delid);
			$this->session->set_flashdata("successmsg","User archived successfully");	
			redirect(base_url().$this->router->class."/manage_user");
		}
		else
		{
			$data=$this->input->post("chk");
			if(!isset($_REQUEST["chk"]) && count($_REQUEST["chk"])==0)
			{
				$this->session->set_flashdata("errormsg","No user selected");	
				redirect(base_url().$this->router->class."/manage_user");	
			}

			foreach($data as $key=>$val)
			{
				$this->user_model->archive_user($val);
			}
			$this->session->set_flashdata("successmsg","Selected users archived successfully");	
			redirect(base_url().$this->router->class."/manage_user");
		}
	}

	

	public function view_user()

	{
		$userid=$this->uri->segment(3);
		if($userid=="" || $userid==0)
		{
			$data["master_title"]="Page not found";   // Please enter the title of page......
			$data["master_body"]=$this->config->item("error_page");  //  Please use view name in this field please do not include '.php' for including view name
			$this->load->theme('mainlayout',$data);  // Loading theme	
			die;			
		}
		else
		{
			$data["resultset"]=$this->user_model->getIndividualUserData($userid);	
		}
		$data["master_title"]="View user";   // Please enter the title of page......
		$data["master_body"]="view_user";  //  Please use view name in this field please do not include '.php' for including view name
		$this->load->theme('mainlayout',$data);  // Loading theme	
	}
	/**********************************************************user functions ************************************************/
	}
?>