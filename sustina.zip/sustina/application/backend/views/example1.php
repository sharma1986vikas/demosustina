<body>
 <div id="container">

   <p><?php echo $links; ?></p>
  </div>
 </div>
</body>