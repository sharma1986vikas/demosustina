	<div class="content">
  <div class="header">
    <h1 class="page-title">Edit User</h1>
  </div>
  <ul class="breadcrumb">
    <li><a href="<?php echo base_url();?>dashboard">Home</a> <span class="divider">/</span></li>
    <li><a href="<?php echo base_url();?><?php echo $this->router->class;?>/manage_user">Users</a> <span class="divider">/</span></li>
    <li class="active">User</li>
  </ul>
  <div class="container-fluid">
    <div class="row-fluid">
      <?php 
			 $error= $this->session->flashdata('errormsg');
			 $successmsg= $this->session->flashdata('successmsg');
			 if($error!="" || $successmsg!="") { ?>
      <div class="alert alert-info">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong> <font color='red'> <?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font></strong> </div>
      <?php } ?>
      <div class="well">
        <ul class="nav nav-tabs">
          <li ><a href="#home" data-toggle="tab">Profile</a></li>
        </ul>
        <div id="myTabContent" class="tab-content">
          <div class="tab-pane active in" id="home">
            <form action="<?php echo base_url();?><?php echo $this->router->class;?>/<?php echo $add_user_to_database;?>" method="post" name="frm" >
             <?php if($do=="edit"){?>
            <input type="hidden" name="id" value="<?php echo $userdata['id'];?>">
            <?php }?>
            
            
              <label>Email</label>
              <input id="email" name="email" class="input-xlarge" type="text" value="<?php echo $userdata['email']; ?>" />
             
              <?php if($do=="edit"){?>
              <label>Reset Password</label>
              <input id="password" name="password" class="input-xlarge" type="text" value="" />
              <?php }else{?>
              <label>Password</label>
              <input id="password" name="password" class="input-xlarge" type="text" value="<?php echo $userdata['password'];?>" />
              <?php }?>
             
              <div class="btn-toolbar">
                <input class="btn btn-primary" name="submitbut" value="Submit" type="submit" />
                <a href="<?php echo base_url();?>users/manage_user"  class="btn">Close</a>
                <div class="btn-group"> </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
