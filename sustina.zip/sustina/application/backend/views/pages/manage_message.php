<div class="content">
  <div class="header">
    <h1 class="page-title">message </h1>
  </div>
  <ul class="breadcrumb">
    <li><a href="<?php echo base_url();?>dashboard">Home</a> <span class="divider">/</span></li>
    <li class="active">message </li>
  </ul>
  <div class="container-fluid">
    <div class="row-fluid">
      <?php 
			 $error= $this->session->flashdata('errormsg');
			 $successmsg= $this->session->flashdata('successmsg');
			 if($error!="" || $successmsg!="") { ?>
      <div class="alert alert-info">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong> <font color='red'> <?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font></strong> </div>
      <?php } ?>
      <div class="btn-toolbar"> <a href="<?php echo base_url();?>pages/add_message" style="margin-right:5px;">
        </a>
        <!--<button class="btn">Export</button>-->
        <div class="btn-group"> </div>
      </div>
      <div class="well">
    <table class="table" width="100%" >
      <thead>
            <tr>
              <th>#id</th>
              <th >Username</th>
               <th >Message</th>
              <th style="width: 100px;">Actions</th>
            </tr>
          </thead>
          <tbody>
      <?php

			if(count($resultset)!=0){
			$z=0;
			foreach($resultset as $key=>$val)
			{
			?>
      <tr>
        <td><?php echo $val['id']; ?></td >
        <td align='center'><?php echo ucwords($val['sender']); ?></td>
        <td align='center'><?php echo $this->contact_model->last_message($val['sender']);?></td>
        
        <td align="center">
        <a style="margin-right:10px;" href="<?php echo base_url().$this->router->class;?>/view_message/<?php echo $val['conversation'];?>" title="View message"> <img src="<?php echo base_url() ?>images/view.png" /> </a> 
        <!--<a style="margin-right:10px;" href="<?php echo base_url().$this->router->class;?>/edit_message/<?php echo $val['id'];?>" title="Edit message"> <img src="<?php echo base_url() ?>images/edit.png" /> </a>--> 
        <a style="margin-right:10px;" href="<?php echo base_url().$this->router->class;?>/archive_message/<?php echo $val['conversation'];?>" title="Delete message" onclick="return archive_fun('<?php echo $item?>');"> <img src="<?php echo base_url() ?>images/delete.png" /> </a></td>
      </tr>
      <?php $z++;}}else{?>
      <tr class="scndrow">
        <td colspan="4" align="center">No record found</td>
      </tr>
      <?php	}?>
      </tbody>
    </table>
   </div>
      <div class="pagination">
        <?php
                   echo $this->pagination->create_links();
             ?>
        <!-- <ul>
        <li><a href="#">Prev</a></li>
        <li><a href="#">1</a></li>
        <li><a href="#">2</a></li>
        <li><a href="#">3</a></li>
        <li><a href="#">4</a></li>
        <li><a href="#">Next</a></li>
    </ul>--> 
        
      </div>
      <div class="modal small hide fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h3 id="myModalLabel">Delete Confirmation</h3>
        </div>
        <div class="modal-body">
          <p class="error-text"><i class="icon-warning-sign modal-icon"></i>Are you sure you want to delete the user?</p>
        </div>
        <div class="modal-footer">
          <button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button>
          <button class="btn btn-danger" data-dismiss="modal">Delete</button>
        </div>
      </div>
    </div>
  </div>
</div>
