
      <div style="margin-top:10px">
      </div>
      <div class="form5">
<form id="add" name="add" method="post" action="<?php echo BASEURL;?><?php echo $this->router->class;?>/<?php echo $update_contact_to_database;?>" enctype="multipart/form-data">
            <table width="950" border="0" cellpadding="5">
             <?php if($do=="edit"){?>
                <input type="hidden" name="id" value="<?php echo $resultset['id'];?>">
                <input type="hidden" name="page_name" value="<?php echo $resultset['page_name'];?>">
   		     <?php }?>
             <tr>                
                <td align="right" class="label_form">Title: </td>
                <td>
                <input name="page_title" type="text" class="input_text" value="<?php echo $resultset['page_title'];?>"/><br class="clear" />
                </td>
              </tr>
                <tr>
                  <td align="right" class="label_form">Image </td>
                  <td><input name="userfile" type="file" /></td>
                </tr>
                <?php if($do=="edit"){?>
                <tr>
                  <td align="right" class="label_form">Current Image </td>
                  <td>
                  <img src='<?php if($resultset["image"] <> ""){echo $this->config->item("content_images").$resultset["image"];}
				  else{echo $this->config->item("content_default_images");}?>' height="100" width="100">
                  </td>
                  <input type="hidden" name="image" value="<?php echo $resultset["image"];?>">
                </tr>
                <?php }?>
               <tr>                
                <td align="right" class="label_form" valign="top">Description: </td>
                <td>
               <textarea name="page_content" class="ckeditor">
    		   <?php echo $resultset['page_content'];?>
       		  </textarea>
                </td>
              </tr>
               <tr>                
                <td align="right" class="label_form" valign="top">Description1: </td>
                <td>
               <textarea name="page_content1" class="ckeditor">
 		       <?php echo $resultset['page_content1'];?>
			  </textarea>
                </td>
              </tr>
              <!-- <tr>                
                <td align="right" class="label_form">Publish: </td>
                <td><input name="page_status" type="checkbox" value="1"  <?php if($resultset['page_status'] == 1){ echo 'checked="checked"';}?>  /></td>
              </tr>-->
              <tr>
                <td>&nbsp;</td>
                <td>
                    <div class="btn">
                     <input class="button" name="submitbut" value="Save" type="submit" />
                    </div>
                </td>
              </tr>
            </table>
        </form>
      </div>
      <?php
	  	 include "include/footerlogo.php";
?>