
<div class="content">
  <div class="header">
    <h1 class="page-title">Information </h1>
  </div>
  <ul class="breadcrumb">
    <li><a href="<?php echo base_url();?>dashboard">Home</a> <span class="divider">/</span></li>
    <li class="active">Information </li>
  </ul>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="well">
        <table  class="table table1" width="100%">
        <?php if(count($resultset) > 0){
		$i=0;foreach($resultset as $k=>$v){	
		if($v["sender"] == $this->session->userdata("admin_id")){
			$userid = $v["receiver"];
		}
		else{
			$userid = $v["sender"];
		}
		?>
          <tr>
            <td ><div class="view1">Name:</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $this->common->get_username($v["sender"]);?></div></td>
          </tr>
          <tr>
            <td ><div class="view1">Message :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo !empty($v["message"]) ? stripcslashes($v["message"]) : "";?></div></td>
          </tr>
         <?php $i++;}}else{?>
         No message found
         <?php }?>
        </table>
          <label>Reply<span class="star"></span> : </label>
          <label class="txt1input">
          <form method="post" id="contact_form" action="<?php echo base_url();?>pages/add_request">
          	<input type="hidden" name="conversation" value="<?php echo $conversation;?>" />
            <input type="hidden" name="receiver" value="<?php echo $userid;?>" />
            <textarea  style="width: 340px; height:150px;" name="message"><?php echo $reply['message'];?></textarea>
          </form>
          </label>
        <?php 
			 $error= $this->session->flashdata('errormsg');
			 $successmsg= $this->session->flashdata('successmsg');
			 if($error!="" || $successmsg!="") { ?>
      <div class="alert alert-info">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong> <font color='red'> <?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font></strong> </div>
      <?php } ?>
        <div style="margin-top:20px;">
         <a class="btn btn-primary" href="javascript:void(0);" onClick="return contact_form();">Save</a> 
		 <a class="btn btn-primary" href="<?php echo base_url();?><?php echo $this->router->class;?>/manage_message">Close</a> </div>
      </div>
    </div>
  </div>
</div>
<script>
function contact_form(){
	this.document.getElementById("contact_form").submit();
}
</script>