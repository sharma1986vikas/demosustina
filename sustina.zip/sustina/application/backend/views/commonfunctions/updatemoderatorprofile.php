<div class="form5">
        <form name="update" class="upload" action="<?php echo BASEURL;?>commonfunctions/update_moderator_profile" method='post'>
          <table border="0" cellpadding="0" cellspacing="10" align="center">
            <tbody>
             <tr class="blacktext">
                <td atd width="200" class="login1"><b>New Name:</b></td>
                <td width="400" class="logintxt"><input class="field" type="text"  name="username" autocomplete="off" value="<?php echo $resultset['username']?>">
                  <br />
                  (Leave Blank, If you don't want to change userid) </td>
              </tr>
              <tr class="blacktext">
                <td width="200" class="login1"><b>Current Password:</b></td>
                <td colspan="2" class="logintxt"><input class="field" type="password" name="oldpassword" autocomplete="off" value="<?php echo $resultset['oldpassword']?>"></td>
                <td><span class="red1">*</span></td>
              </tr>
              <tr class="blacktext">
                <td td width="200" class="login1"><b>New Password:</b></td>
                <td width="400" class="logintxt"><input class="field" type=password  name="newpassword" autocomplete="off" value="<?php echo $resultset['newpassword']?>">
                  <br />
                  (Leave Blank, If you don't want to change Password) </td>
              </tr>
              <tr class="blacktext">
                <td td width="200" class="login1"><b>Confirm Password:</b></td>
                <td width="400" class="logintxt"><input class="field" type=password  name="confirmnewpassword" autocomplete="off">
                  <br />
                  (Leave Blank, If you don't want to change Password) </td>
              </tr>
              <tr>
                <td  class=" login3"><input name="submitbut" value="Submit" type="submit"  /></td>
              </tr>
            </tbody>
          </table>
        </form>
      </div>
    </div>
    <div class="clear"></div>
  </div>
</div>