
 <div class="content">
        
        <div class="header">
            
            <h1 class="page-title">My Account</h1>
        </div>
        
                <ul class="breadcrumb">
            <li><a href="<?php echo base_url();?>dashboard">Home</a> <span class="divider">/</span></li>
           
            <li class="active">My Account</li>
        </ul>

        <div class="container-fluid">
            <div class="row-fluid">
        <?php 
			 $error= $this->session->flashdata('errormsg');
			 $successmsg= $this->session->flashdata('successmsg');
			 if($error!="" || $successmsg!="") { ?>
             <div class="alert alert-info">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>  <font color='red'> <?php echo $this->session->flashdata('errormsg'); ?></font>
         <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font></strong>
         </div>
         <?php } ?>         
            

<div class="well">
    <ul class="nav nav-tabs">
      <li ><a href="#home" data-toggle="tab">Admin</a></li>
   
    </ul>
    <div id="myTabContent" class="tab-content">
      <div class="tab-pane active in" id="home">
   <form name="update" class="upload" action="<?php echo  base_url();?>commonfunctions/update_admin_profile" method='post'>
         
       
        <label>New User Name</label>
       
        <input class="input-xlarge" type="text"  name="username" autocomplete="off" value="<?php echo $resultset['username']?>"> 
        (Leave Blank, If you don't want to change userid) 
        
        <label>Current Password</label>
        <input class="input-xlarge" type="password" name="oldpassword" autocomplete="off" value="<?php echo $resultset['oldpassword']?>">
       
      
        <label>New Password</label>
        <input class="input-xlarge" type=password  name="newpassword" autocomplete="off" value="<?php echo $resultset['newpassword']?>">
         (Leave Blank, If you don't want to change Password)
        
        <label>Confirm Password</label>
        <input class="input-xlarge" type=password  name="confirmnewpassword" autocomplete="off">
        (Leave Blank, If you don't want to change Password)
        
      <div class="btn-toolbar">
       
        <input class="btn btn-primary" name="submitbut" value="Submit" type="submit" />
        
      <a href="<?php echo base_url();?>dashboard"  class="btn">Close</a>
  <div class="btn-group">
  </div>
</div>  
        
        
    </form>
      </div>
      
  </div>

</div>

        
            </div>
        </div>
    </div>