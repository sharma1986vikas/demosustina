<div class="content">
  <div class="header">
    <h1 class="page-title">Brands </h1>
  </div>
  <ul class="breadcrumb">
    <li><a href="<?php echo base_url();?>dashboard">Home</a> <span class="divider">/</span></li>
    <li class="active">View brand </li>
  </ul>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="well">
        <table class="table table1" width="100%">
          <tr>
            <td ><div class="view1">Name :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $resultset["brand_name"];?></div></td>
          </tr>
          <tr>
            <td align="center" class="label_form"><div class="view1"> Status :</div></td>
            <td align="left"><div class="view2">
                <?php if($resultset["brand_status"]==1){echo "<span style='color:green'>Active</span>";}else{echo "<span style='color:red'>Inactive</span>";}?>
              </div></td>
          </tr>
        </table>
        <div tyle="margin-top:20px;"> <a class="btn btn-primary" href="<?php echo base_url();?><?php echo $this->router->class;?>/manage_brand">Close</a> </div>
      </div>
    </div>
  </div>
</div>
