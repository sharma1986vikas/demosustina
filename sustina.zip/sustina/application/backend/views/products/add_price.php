
<div class="content">
  <div class="header">
    <h1 class="page-title">Price</h1>
  </div>
  <ul class="breadcrumb">
    <li><a href="<?php echo base_url();?>dashboard">Home</a> <span class="divider">/</span></li>
    <li><a href="<?php echo base_url();?>products/manage_price">Price</a> <span class="divider">/</span></li>
    <li class="active">
      <?php if($do =="add"){echo 'Add';}else{echo 'Edit';}?>
      Price</li>
  </ul>
  <div class="container-fluid">
    <div class="row-fluid">
      <?php 
			 $error= $this->session->flashdata('errormsg');
			 $successmsg= $this->session->flashdata('successmsg');
			 if($error!="" || $successmsg!="") {?>
      <div class="alert alert-info">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong> <font color='red'> <?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font></strong> </div>
      <?php } ?>
      <div class="well">
        <div id="myTabContent" class="tab-content">
          <div class="tab-pane active in" id="home">
            <form id="add" name="add" method="post" action="<?php echo base_url();?><?php echo $this->router->class;?>/<?php echo $add_price_to_database ;?>" enctype="multipart/form-data">
              <?php if($do=="edit"){?>
              <input type="hidden" name="price_id" value="<?php echo $pricedata['price_id'];?>">
              <?php }?>
              
              
              <label>Category</label>
              <?php $category = $this->products_model->get_all_category();?>
			  <select name="category_id">
              <option value="">-Select category-</option>
				<?php  if(count($category !=0)){
				  foreach($category as $key=>$val){
			  ?>
              <option value="<?php echo $val["id"];?>"<?php if($val["id"] == $pricedata["category_id"]){echo 'selected=selected';}?>><?php echo $val["category_name"];?></option>
             <?php }}?>
              </select>
              
               <label>Brand</label>
              <?php $brand = $this->products_model->get_all_brands();?>
			  <select name="brand_id">
              <option value="">-Select brand-</option>
				<?php  if(count($brand !=0)){
				  foreach($brand as $key=>$val){
			  ?>
              <option value="<?php echo $val["brand_id"];?>"<?php if($val["brand_id"] == $pricedata["brand_id"]){echo 'selected=selected';}?>><?php echo $val["brand_name"];?></option>
             <?php }}?>
              </select>
             
             <label>Price from</label>
             <input type="text" name="price_from" value="<?php echo $pricedata['price_from'];?>">
              
              <label>Price to</label>
             <input type="text" name="price_to" value="<?php echo $pricedata['price_to'];?>">
              
              <div class="btn-toolbar">
                <input class="btn btn-primary" name="submitbut" value="Submit" type="submit" />
                <a href="<?php echo base_url();?><?php echo $this->router->class;?>/manage_brand"  class="btn">Close</a>
                <div class="btn-group"> </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
