<div class="content">
  <div class="header">
    <h1 class="page-title">Attribute </h1>
  </div>
  <ul class="breadcrumb">
    <li><a href="<?php echo base_url();?>dashboard">Home</a> <span class="divider">/</span></li>
    <li class="active">Attribute </li>
  </ul>
  <div class="container-fluid">
    <div class="row-fluid">
      <?php 
			 $error= $this->session->flashdata('errormsg');
			 $successmsg= $this->session->flashdata('successmsg');
			 if($error!="" || $successmsg!="") { ?>
      <div class="alert alert-info">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong> <font color='red'> <?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font></strong> </div>
      <?php } ?>
      <div class="btn-toolbar"> <a href="<?php echo base_url();?><?php echo $this->router->class;?>/add_category" style="margin-right:5px;">
        <button class="btn btn-primary"><i class="icon-plus"></i>Attribute</button>
        </a>
        <!--<button class="btn">Export</button>-->
        <div class="btn-group"> </div>
      </div>
      <div class="well">
     <table class="table" width="100%">
          <thead>
            <tr>
              <th > Name</th>
              <th >Displayed</th>
              <th style="width: 100px;">Actions</th>
               <td align="center" width="15%"> Add Property</td>
            </tr>
          </thead>
          <tbody>
      <?php
			if(count($resultset)!=0){
			$z=0;
			foreach($resultset as $key=>$val)
			{
				//<?php echo $z%2 ? '' : 'alternate';
				$property = $this->products_model->get_property_by_attribute($val["attribute_id"]);
			?>
      <tr class="scndrow">
        <td height="10px">
           <img src="<?php echo base_url();?>images/success0.png" title="No issues found with this product" style="width: 12px; height: 12px;">
         	<?php echo $val['attribute_name']; ?>
         </td>
         
        <td align="center"><?php if($val['attribute_status'] == '1'){ ?>
          <a href="<?php echo base_url().$this->router->class;?>/enable_disable_attribute/<?php echo $val['attribute_id'];?>/0" onclick="return dis_fun('<?php echo $item?>');"><img src='<?php echo base_url();?>images/enabled.gif' title='Disable' width='16' height='16' /></a>
          <?php }else{ ?>
          <a href="<?php echo base_url().$this->router->class;?>/enable_disable_attribute/<?php echo $val['attribute_id'];?>/1" onclick="return enb_fun('<?php echo $item?>');"><img src='<?php echo base_url();?>images/disabled.gif' title='Enable' width='16' height='16' /></a>
          <?php } ?></td>
          <td></td>
        <!--<td style="white-space: nowrap; text-align: center;"><a style="margin:0px 10px;" href="view_dish.php?do=view&id=<?php echo $fetch['id'].$q_string_pg; ?>" title="View"> <img src="<?php echo base_url()?>images/view.png" /> </a> <a href="add_edit_dish.php?do=edit&id=<?php echo $fetch['id']; ?>"><img src="<?php echo base_url()?>images/Edit.gif" title="Edit" width="16" height="16" /></a> &nbsp; <a href="<?php echo $page_n; ?>?do=delete&id=<?php echo $fetch['id']; ?>&pid=<?php echo $fetch['uniq'];?>" onclick="return del_fun();"><img src="<?php echo base_url()?>images/delete.png" /></a></td>-->
        <td style="text-align: center;"><a  class="fancybox"  href="<?php echo base_url();?>products/add_property/<?php echo $val['attribute_id'];?>"><img src="<?php echo base_url()?>images/add.png" title="Add Combination"></a></td>
      </tr>
      <td style="border-spacing: 0px; border-collapse:none; width:20%">
        <?php foreach($property as $k=>$v){
			echo '<tr>
			<td style="border-spacing: 0px; border-collapse:none;">
			<img src="'.base_url().'images/'; if($z == count($resultset)){echo 'tvil.gif';} else{echo 'tvi.gif';}
			echo '" align="left" bordor="0"> &nbsp; ';
			echo "".$v["attribute_name"]. "<br/>";
		?>
        </td>
        <td align="center"  width"20%"><?php if($v['attribute_status'] == '1'){ ?>
          <a href="<?php echo base_url().$this->router->class;?>/enable_disable_attribute/<?php echo $v['attribute_id'];?>/0" onclick="return dis_fun('<?php echo $item?>');"><img src='<?php echo base_url();?>images/enabled.gif' title='Disable' width='16' height='16' /></a>
          <?php }else{ ?>
          <a href="<?php echo base_url().$this->router->class;?>/enable_disable_attribute/<?php echo $v['attribute_id'];?>/1" onclick="return enb_fun('<?php echo $item?>');"><img src='<?php echo base_url();?>images/disabled.gif' title='Enable' width='16' height='16' /></a>
          <?php } ?></td>
       
        <td>
        <!--<a style="margin:0px 10px;" href="<?php echo base_url().$this->router->class;?>/view_property/<?php echo $v['attribute_id'];?>" title="View properties under attribute"> <img src="<?php echo base_url() ?>images/view.png" /> </a>-->
        <a style="margin:0px 10px;" class="fancybox" href="<?php echo base_url().$this->router->class;?>/edit_property/<?php echo $v['attribute_id'];?>" title="edir property"> <img src="<?php echo base_url() ?>images/edit.png" /> </a> 
        <a style="margin:0px 10px;" href="<?php echo base_url().$this->router->class;?>/archive_property/<?php echo $v['attribute_id'];?>" title="Delete property" onclick="return archive_fun('<?php echo $item?>');"> <img src="<?php echo base_url() ?>images/delete.png" /> </a>
          </td>
          <td width"30%"> </td>
      </tr>
        <?php }?>
      <?php $z++;}}else{?>
      <tr class="scndrow">
        <td colspan="6" align="center">No record found</td>
      </tr>
      <?php	}?>
      </tbody>
    </table>
    </div>
      <div class="pagination">
        <?php
                   echo $this->pagination->create_links();
             ?>
        <!-- <ul>
        <li><a href="#">Prev</a></li>
        <li><a href="#">1</a></li>
        <li><a href="#">2</a></li>
        <li><a href="#">3</a></li>
        <li><a href="#">4</a></li>
        <li><a href="#">Next</a></li>
    </ul>--> 
        
      </div>
      <div class="modal small hide fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h3 id="myModalLabel">Delete Confirmation</h3>
        </div>
        <div class="modal-body">
          <p class="error-text"><i class="icon-warning-sign modal-icon"></i>Are you sure you want to delete the user?</p>
        </div>
        <div class="modal-footer">
          <button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button>
          <button class="btn btn-danger" data-dismiss="modal">Delete</button>
        </div>
      </div>
    </div>
  </div>
</div>
