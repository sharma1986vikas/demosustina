




  
        <div class="tab-pane active in" id="home">
          
          <div style=" position:absolute; float:left; left:0px;;" id="message"> <font color='red'><?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font> </div>
          <div class="form5">
            <form id="add" name="add" method="post" action="<?php echo base_url();?>products/add_property_to_database">
             
              <input type="text" name="attribute_relation" value="<?php echo $attribute_relation;?>">
            
              <?php if($do=="edit"){?>
             <input type="text" name="attribute_id" value="<?php echo $propertydata['attribute_id'] ;?>">
             <?php }?>
             
            <input type="hidden" name="type"  value="<?php echo $do ;?>">
              <label>Name:</label>
              <input name="attribute_name" type="text" class="input_text" value="<?php echo $propertydata['attribute_name'];?>"  />
              <div class="btn-toolbar">
                <input class="btn btn-primary" name="submitbut" value="Submit" type="submit" />
                <a href="<?php echo base_url();?><?php echo $this->router->class;?>/manage_category"  class="btn">Close</a>
                <div class="btn-group"> </div>
              </div>
            </form>
          </div>
        </div>
     
   