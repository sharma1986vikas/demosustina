<div class="content">
  <div class="header">
    <h1 class="page-title">Product </h1>
  </div>
  <ul class="breadcrumb">
    <li><a href="<?php echo base_url();?>dashboard">Home</a> <span class="divider">/</span></li>
    <li class="active">Product</li>
  </ul>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="well">
        <table  class="table table1" width="100%">
         
          <tr>
            <td ><div class="view1">Name :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $resultset["title"];?></div></td>
          </tr>
          
           <tr>
            <td ><div class="view1">Category :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $this->common->get_category_name($resultset['category']); ?></div></td>
          </tr>
          
            <tr>
            <td ><div class="view1">SubCategory :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $this->common->get_subcategory_name($resultset['subcategory']);?></div></td>
          </tr>
          
            <tr>
            <td ><div class="view1">Brand :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $this->common->get_brand_name($resultset['brand']);?></div></td>
          </tr>
          
            <tr>
            <td ><div class="view1">Short description :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $resultset['short_description'];?></div></td>
          </tr>
          
            <tr>
            <td ><div class="view1">Long description :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $resultset['long_description'];?></div></td>
          </tr>
          
          
            <tr>
            <td ><div class="view1">Price :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $resultset['price'];?></div></td>
          </tr>
          
            <tr>
            <td ><div class="view1">Condition :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $this->common->get_condition_name($resultset['condition']);?></div></td>
          </tr>
          
           <tr>
            <td ><div class="view1">Meta tags :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $resultset['meta_tag'];?></div></td>
          </tr>
          
          
           <tr>
            <td ><div class="view1">Availability :</div></td>
            <td><div class="view2" style="width:620px;"><?php if($resultset['product_availability']==1){echo '<span style="color:green">In stock</span>';}else{echo '<span style="color:red">Out of stock</span>';};?></div></td>
          </tr>
          
            <?php $data = $this->products_model->get_variations_edit($resultset["product_id"]);
				//debug($data);
			?>
           <tr>
            <td ><div class="view1">Variation :</div></td>
            
            <td>
            <?php if(count($data) > 0){
				//debug($data);
				$size = array();
				$color = array();
				$i=0;foreach($data as $k => $v){
					$size[] = $v["size_id"];
					$color[] = $v["color_id"];
				?>
                <?php 
				$i++;}
				}?>
            <div class="view2" style="width:620px;">
           <strong>Size : </strong><?php echo $this->products_model->get_size_comma_id($size);?><br/>
           <strong>Color : </strong><?php echo $this->products_model->get_color_comma_id($color);?>
           
<!--            <img src="<?php if($v["image_name"] <> ""){echo $this->config->item("productimages").$v["image_name"];}else{echo base_url()."images/1.png";}?>">
-->            
            </div></td>
          </tr>
          
          <tr>
            <td align="right" class="label_form"><div class="view1"> Status :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo ($resultset['product_status']=="1")?"<font color='green'>Active</font>":"<font color='red'>Inactive</font>"; ?></div></td>
          </tr>
        </table>
        <div tyle="margin-top:20px;"> <a class="btn btn-primary" href="<?php echo base_url();?><?php echo $this->router->class;?>/manage_product">Close</a> </div>
      </div>
    </div>
  </div>
</div>
