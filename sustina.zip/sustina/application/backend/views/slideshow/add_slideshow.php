<div class="form5">
<form id="add" name="add" method="post" action="<?php echo BASEURL;?><?php echo $this->router->class;?>/add_slideshow_to_database" enctype="multipart/form-data">
  <table width="850" border="0" cellpadding="5">
    <?php if($do=="edit"){ ?>
    <input type="hidden" name="id" value="<?php echo $slideshowdata['sld_id'];?>">
    <?php }	?>
    <tr>
    <tr>
      <td align="right" class="label_form">Image </td>
      <td><input name="userfile" type="file" /></td>
    </tr>
    <?php if($do=="edit"){ ?>
    <tr>
      <td align="right" class="label_form">Current Image </td>
      <td><img src='<?php echo $this->config->item("slideshowimages");?><?php echo $slideshowdata["sld_images"];?>' height="120px" width="120px"></td>
      <input type="hidden" name="sld_images" value="<?php echo $slideshowdata["sld_images"];?>">
    </tr>
    <?php } ?>
        <tr>
      <td>&nbsp;</td>
      <td><div class="btn">
          <input class="button" name="submitbut" value="Save" type="submit" />
          <a class="a_button" href="<?php echo base_url(); ?>slideshow/manage_slideshow">Cancel</a> </div></td>
    </tr>
  </table>
</form>
