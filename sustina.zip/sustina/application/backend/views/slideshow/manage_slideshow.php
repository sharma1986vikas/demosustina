<?php $sld='active'; ?>

<div style="margin-top: 20px;"></div>
<div class="down_category" style="margin-top:30px">
  <div class="head"> <span class="head_text"><?php echo $item; ?></span>
    <div class="add"> <a href="<?php echo BASEURL;?>slideshow/add_slideshow"> <span class="add1"> <span class="head_text1" style="font-size:14px;"> <?php echo $item; ?></span> </span> </a></div>
    <div class="resetallpage"><a href="<?php echo base_url(); ?>slideshow/manage_slideshow">Reset</a></div>
  </div>
  <div class="clear"></div>
  <form action="<?php echo BASEURL;?>slideshow/archive_slideshow" method="post" name="<?php echo $item; ?>" onsubmit="return archive_fun('<?php echo $item?>');">
    <input name="done" type="hidden" value="send" />
    <table width="100%" cellspacing="0" cellpadding="0"  class="maintbl" >
      <tr class="fstrow">
        <td width="5%"><input class="check" type="checkbox" id="mainchbx" name="chk" /></td>
        <td align="center" width="35%">Image</td>
        <td align="center" width="25%">Displayed</td>
        <td align="center" width="30%">Actions</td>
      </tr>
      <?php if(count($resultset)!=0){
			$z=0;
			foreach($resultset as $key=>$val){
				//echo $val["blog_images"];
			?>
      <tr class="scndrow <?php echo $z%2 ? '' : 'alternate';?>">
        <td><input type='checkbox' name='chk[]' value="<?php echo $val['sld_id'] ?>" id='checkme<?php echo $z; ?>' /></td >
        <td align='center'><img src="<?php if($val["sld_images"] <> ""){echo $this->config->item("slideshowimages").$val["sld_images"];}
			else{echo $this->config->item("default_slideshowimages");}?>" height="120px" width="120px"/></td>
        <td align="center"><?php if($val['status'] == '1'){ ?>
          <a href="<?php echo BASEURL?>slideshow/enable_disable_slideshow/<?php echo $val['sld_id'];?>/0" onclick="return dis_fun('<?php echo $item?>');"><img src='<?php echo BASEURL;?>images/enabled.gif' title='Disable' width='16' height='16' /></a>
          <?php }else{ ?>
          <a href="<?php echo BASEURL?>slideshow/enable_disable_slideshow/<?php echo $val['sld_id'];?>/1" onclick="return enb_fun('<?php echo $item?>');"><img src='<?php echo BASEURL;?>images/disabled.gif' title='Enable' width='16' height='16' /></a>
          <?php } ?></td>
        <td align="center"><a style="margin:0px 10px;" href="<?php echo BASEURL?>slideshow/edit_slideshow/<?php echo $val['sld_id'];?>" title="Edit"> <img src="<?php echo BASEURL ?>images/edit.png" /> </a> <a style="margin:0px 10px;" href="<?php echo BASEURL?>slideshow/archive_slideshow/<?php echo $val['sld_id'];?>" title="Delete" 
            onclick="return archive_fun('<?php echo $item?>');"> <img src="<?php echo BASEURL ?>images/delete.png" /> </a></td>
      </tr>
      <?php	$z++;
			}
			}
			else{
			?>
      <tr class="scndrow">
        <td colspan="5" align="center">No record found</td>
      </tr>
      <?php	} ?>
    </table>
    <?php // $this->output->enable_profiler(TRUE);?>
	<div class="clear"></div>
     <div class="khattra_class" style="margin-top:20px;">
     <?php  echo $this->pagination->create_links();?>
     </div>
    <div class="clear"></div>
    <?php  if(count($resultset)!=0){  ?>
    <div class="slideshowdelend">
      <input type="submit" name="Delete" value="Delete Selected" class="formbutton" />
    </div>
    <?php } ?>
  </form>
</div>
