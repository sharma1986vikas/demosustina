//add clone
var BASEURL_FRONT = 'http://localhost/sustina/'

var prev_file="";
	 var url = BASEURL+'products/upload_image';
///////////////////display image ////////////////////
/*$(document).ready(function(e) {
    alert(url);
	alert(BASEURL_FRONT);
});*/
	$(function(){
		/* $.noConflict();*/
		var btnUpload=$('#display_image');
		var mestatus=$('#mestatus');
		var files=$('#files');
		var prevfile=prevfile;
		new AjaxUpload(btnUpload, 
		{
			prevfile:prevfile,
			action: url,
			name: 'uploadfile',
			onSubmit: function(file,ext){
				if (! (ext && /^(jpg|png|jpeg|gif)$/.test(ext))){ 
                   alert('Only JPG, PNG or GIF files are allowed');
					return false;
				}
			},
			onComplete: function(file, response){
			
			  response_array_t = response.split('|::|');
			  //Add uploaded file to list
				if(response_array_t[0]==="success"){
					
					$('#display_image').html('<img src="'+BASEURL_FRONT+'productimagesthumbs/'+response_array_t[1]+'" height="170" width="270" alt="pic" />');
					prevfile = response_array_t[1];
				    unlink_image($('#displayimage').val()); /////unlink prev image
					$('#displayimage').val(response_array_t[1]);
				}
				else
				{
				    alert(response_array_t[1]);
				}
			}
		});
	});
   

//////////////////////////////support image 1//////////////////////////////////////////////

$(function(){
		
		var btnUpload=$('#support_image1');
		var mestatus=$('#mestatus');
		var files=$('#files');
		var prevfile=prevfile;
		new AjaxUpload(btnUpload, 
		{
			prevfile:prevfile,
			action: url,
			name: 'uploadfile',
			onSubmit: function(file,ext){
				if (! (ext && /^(jpg|png|jpeg|gif)$/.test(ext))){ 
                   alert('Only JPG, PNG or GIF files are allowed');
					return false;
				}
			},
			onComplete: function(file, response){
			  response_array_t = response.split('|::|');
			  //Add uploaded file to list
				if(response_array_t[0]==="success"){
					
					$('#support_image1').html('<img src="'+BASEURL_FRONT+'productimagesthumbs/'+response_array_t[1]+'" height="95" width="120" alt="pic" />');
					prevfile = response_array_t[1];
				    unlink_image($('#supportimage1').val()); /////unlink prev image
					$('#supportimage1').val(response_array_t[1]);
				}
				else
				{
				    alert(response_array_t[1]);
					
				}
			}
		});
	});
   
/////////////////////////////////////////////////////////////////////////////////////////
$(function(){
		
		var btnUpload=$('#support_image2');
		var mestatus=$('#mestatus');
		var files=$('#files');
		var prevfile=prevfile;
		new AjaxUpload(btnUpload, 
		{
			prevfile:prevfile,
			action: url,
			name: 'uploadfile',
			onSubmit: function(file,ext){
				if (! (ext && /^(jpg|png|jpeg|gif)$/.test(ext))){ 
                   alert('Only JPG, PNG or GIF files are allowed');
					return false;
				}
			},
			onComplete: function(file, response){
			  response_array_t = response.split('|::|');
			  //Add uploaded file to list
				if(response_array_t[0]==="success"){
					
					$('#support_image2').html('<img src="'+BASEURL_FRONT+'productimagesthumbs/'+response_array_t[1]+'" height="95" width="120" alt="pic" />');
					prevfile = response_array_t[1];
				    unlink_image($('#supportimage2').val()); /////unlink prev image
					$('#supportimage2').val(response_array_t[1]);
				}
				else
				{
				    alert(response_array_t[1]);
					
				}
			}
		});
	});
   
////////////////////////////////////////////////////////////////
$(function(){
		
		var btnUpload=$('#support_image3');
		var mestatus=$('#mestatus');
		var files=$('#files');
		var prevfile=prevfile;
		new AjaxUpload(btnUpload, 
		{
			prevfile:prevfile,
			action: url,
			name: 'uploadfile',
			onSubmit: function(file,ext){
				if (! (ext && /^(jpg|png|jpeg|gif)$/.test(ext))){ 
                   alert('Only JPG, PNG or GIF files are allowed');
					return false;
				}
			},
			onComplete: function(file, response){
			  response_array_t = response.split('|::|');
			  //Add uploaded file to list
				if(response_array_t[0]==="success"){
					
					$('#support_image3').html('<img src="'+BASEURL_FRONT+'productimagesthumbs/'+response_array_t[1]+'" height="95" width="120" alt="pic" />');
					prevfile = response_array_t[1];
				    unlink_image($('#supportimage3').val()); /////unlink prev image
					$('#supportimage3').val(response_array_t[1]);
				}
				else
				{
				    alert(response_array_t[1]);
					
				}
			}
		});
	});
   
///////////////////////////////////////////////////////////////////////////////////////////
$(function(){
		
		var btnUpload=$('#support_image4');
		var mestatus=$('#mestatus');
		var files=$('#files');
		var prevfile=prevfile;
		new AjaxUpload(btnUpload, 
		{
			prevfile:prevfile,
			action: url,
			name: 'uploadfile',
			onSubmit: function(file,ext){
				if (! (ext && /^(jpg|png|jpeg|gif)$/.test(ext))){ 
                   alert('Only JPG, PNG or GIF files are allowed');
					return false;
				}
			},
			onComplete: function(file, response){
			  response_array_t = response.split('|::|');
			  //Add uploaded file to list
				if(response_array_t[0]==="success"){
					
					$('#support_image4').html('<img src="'+BASEURL_FRONT+'productimagesthumbs/'+response_array_t[1]+'" height="95" width="120" alt="pic" />');
					prevfile = response_array_t[1];
				    unlink_image($('#supportimage4').val()); /////unlink prev image
					$('#supportimage4').val(response_array_t[1]);
				}
				else
				{
				    alert(response_array_t[1]);
					
				}
			}
		});
	});
   
///////////////////////////////////////////////////////////////////////////////////
$(function(){
		
		var btnUpload=$('#support_image5');
		var mestatus=$('#mestatus');
		var files=$('#files');
		var prevfile=prevfile;
		new AjaxUpload(btnUpload, 
		{
			prevfile:prevfile,
			action: url,
			name: 'uploadfile',
			onSubmit: function(file,ext){
				if (! (ext && /^(jpg|png|jpeg|gif)$/.test(ext))){ 
                   alert('Only JPG, PNG or GIF files are allowed');
					return false;
				}
			},
			onComplete: function(file, response){
			  response_array_t = response.split('|::|');
			  //Add uploaded file to list
				if(response_array_t[0]==="success"){
					
					$('#support_image5').html('<img src="'+BASEURL_FRONT+'productimagesthumbs/'+response_array_t[1]+'" height="95" width="120" alt="pic" />');
					prevfile = response_array_t[1];
				    unlink_image($('#supportimage5').val()); /////unlink prev image
					$('#supportimage5').val(response_array_t[1]);
				}
				else
				{
				    alert(response_array_t[1]);
					location.reload();
				}
			}
		});
	});
   
///////////////////////////////////////////////////////////////////////////////////////////////
$(function(){
		
		var btnUpload=$('#support_image6');
		var mestatus=$('#mestatus');
		var files=$('#files');
		var prevfile=prevfile;
		new AjaxUpload(btnUpload, 
		{
			prevfile:prevfile,
			action: url,
			name: 'uploadfile',
			onSubmit: function(file,ext){
				if (! (ext && /^(jpg|png|jpeg|gif)$/.test(ext))){ 
                   alert('Only JPG, PNG or GIF files are allowed');
					return false;
				}
			},
			onComplete: function(file, response){
			  response_array_t = response.split('|::|');
			  //Add uploaded file to list
				if(response_array_t[0]==="success"){
					
					$('#support_image6').html('<img src="'+BASEURL_FRONT+'productimagesthumbs/'+response_array_t[1]+'" height="95" width="120" alt="pic" />');
					prevfile = response_array_t[1];
				    unlink_image($('#supportimage6').val()); /////unlink prev image
					$('#supportimage6').val(response_array_t[1]);
				}
				else
				{
				    alert(response_array_t[1]);
					location.reload();
				}
			}
		});
	});
   

   
//////////////////////////////////////////////////////////////////////////////////////////
function unlink_image(img)
	{
      $.ajax({
		url:BASEURL+'products/unlink_image/'+img,
		data:'type=json',
		success:function(result)
		{
		   //$("SELECT").selectBox();	
		}	
	});		
	}
  