<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class pages extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('page_model');
	}
	/**********************************************************Page functions starts ************************************************/
	public function index()
	{
		$this->manage_page();	
	}
	public function manage_page()
	{
		$pagename=$this->uri->segment(3);
		
		if($pagename == 'contact')
		{
			$data["do"]="edit";
			$data["resultset"]=$this->page_model->get_contact_data($pagename);
			$data["update_contact_to_database"]='update_contact_to_database';//function to be called on save
			$data["item"]="Contact us";
			$data["master_title"]="Contact us";   
			$data["master_body"]="manage_contact";  
			$this->load->theme('mainlayout',$data);	 
		}
		else if($pagename == 'about_us')
		{
			$data["do"]="edit";
			$data["resultset"]=$this->page_model->get_contact_data($pagename);
			$data["update_aboutus_to_database"]='update_aboutus_to_database';//function to be called on save
			$data["item"]="About us";
			$data["master_title"]="About us";   
			$data["master_body"]="manage_about";  
			$this->load->theme('mainlayout',$data);	 
		}
		else if($pagename == 'partners')
		{
			$data["do"]="edit";
			$data["resultset"]=$this->page_model->get_contact_data($pagename);
			$data["update_parnter_to_database"]='update_parnter_to_database';//function to be called on save
			$data["item"]="Partner Content";
			$data["master_title"]="Partner Content";   
			$data["master_body"]="manage_partner"; 
			$this->load->theme('mainlayout',$data);	 
		}
		
		else if($pagename == 'food_club')
		{
			$data["do"]="edit";
			$data["resultset"]=$this->page_model->get_contact_data($pagename);
			$data["update_club_to_database"]='update_club_to_database';//function to be called on save
			$data["item"]="Food Club Content";
			$data["master_title"]="Food Club Content";   
			$data["master_body"]="manage_club_content"; 
			//echo  "<pre>";
			//print_r($data);die;
			$this->load->theme('mainlayout',$data);	 
		}
		else if($pagename == 'week_rest')
		{
			$data["do"]="edit";
			$data["resultset"]=$this->page_model->get_contact_data($pagename);
			$data["update_week_rest_to_database"]='update_week_rest_to_database';//function to be called on save
			$data["item"]="Week's  restaurants";
			$data["master_title"]="Week's  restaurants";   
			$data["master_body"]="manage_week_rest"; 
			$this->load->theme('mainlayout',$data);	 
		}
		else if($pagename == 'quick_easy')
		{
			$data["do"] = "edit";
			$data["resultset"] = $this->page_model->get_contact_data($pagename);
			$data["update_quick_easy_to_database"] = 'update_quick_easy_to_database';//function to be called on save
			$data["item"]="Quick & easy";
			$data["master_title"] = "Quick & easy";   
			$data["master_body"] = "manage_quick_easy"; 
			$this->load->theme('mainlayout',$data);	 
		}
		else{
		}
	}
	
	//update week rest.
	public function update_quick_easy_to_database()
	{
		$arr["id"]=$this->input->post("id");
		$arr["page_name"] = trim($this->input->post("page_name"));
		$arr["page_title"] = trim($this->input->post("page_title"));
		$arr["page_content"] = trim($this->input->post("page_content"));
		$arr["image"] = $_FILES["userfile"]["name"];
		$arr["page_status"] = 1;
		
		if($arr["image"] != "")
		{
			$arr["image"] = time().".".$this->common->get_extension($_FILES["userfile"]["name"]);
		}
		else
		{
			$arr["image"] = $this->input->post("image");	
		}
		//echo "<pre>"; 
		//print_r($arr);die;
		if($this->validations->validate_week_rest_us($arr))
		{
			if($this->page_model->update_contact_data($arr))
			{
				if($arr["image"] != $this->input->post("image"))
				{
					$config['upload_path'] = '../uploads/';
					$config['allowed_types'] = '*';
					$config['file_name'] = $arr["image"];
					$this->upload->initialize($config);
					if($this->upload->do_upload()){
						$err=0;
					}		
					else {
						//echo $this->upload->display_errors();die;
						$this->session->set_flashdata("successmsg","There is some error uploading the files to server. Please contact server admin");		
					}		
				}
				$this->session->set_flashdata("successmsg","quick easy updated successffuly");
				$err=0;
			}
			else
			{
				$this->session->set_flashdata("errormsg","There is error editing quick easy. Please contact database admin");
				$err=1;
			}
		}
		else
		{
			redirect(base_url()."pages/manage_page/quick_easy/edit");
			$err=1;	
		}
		//echo "hiii";die;
		redirect(base_url()."pages/manage_page/quick_easy/edit");
	}
	
	//update week rest.
	public function update_week_rest_to_database()
	{
		$arr["id"]=$this->input->post("id");
		$arr["page_name"] = trim($this->input->post("page_name"));
		$arr["page_title"] = trim($this->input->post("page_title"));
		$arr["page_content"] = trim($this->input->post("page_content"));
		$arr["image"] = $_FILES["userfile"]["name"];
		$arr["page_status"] = 1;
		
		if($arr["image"] != "")
		{
			$arr["image"] = time().".".$this->common->get_extension($_FILES["userfile"]["name"]);
		}
		else
		{
			$arr["image"] = $this->input->post("image");	
		}
		//echo "<pre>"; 
		//print_r($arr);die;
		if($this->validations->validate_week_rest_us($arr))
		{
			if($this->page_model->update_contact_data($arr))
			{
				if($arr["image"] != $this->input->post("image"))
				{
					$config['upload_path'] = '../uploads/';
					$config['allowed_types'] = '*';
					$config['file_name'] = $arr["image"];
					$this->upload->initialize($config);
					if($this->upload->do_upload()){
						$err=0;
					}		
					else {
						//echo $this->upload->display_errors();die;
						$this->session->set_flashdata("successmsg","There is some error uploading the files to server. Please contact server admin");		
					}		
				}
				$this->session->set_flashdata("successmsg","week restaurants updated successffuly");
				$err=0;
			}
			else
			{
				$this->session->set_flashdata("errormsg","There is error editing week restaurants . Please contact database admin");
				$err=1;
			}
		}
		else
		{
			redirect(base_url()."pages/manage_page/week_rest/edit");
			$err=1;	
		}
		//echo "hiii";die;
		redirect(base_url()."pages/manage_page/week_rest/edit");
	}
	
	//update contact us page to admin
	public function update_contact_to_database()
	{
		$arr["id"]=$this->input->post("id");
		$arr["page_name"] = trim($this->input->post("page_name"));
		$arr["page_title"] = trim($this->input->post("page_title"));
		$arr["page_content"] = trim($this->input->post("page_content"));
		$arr["page_content1"] = trim($this->input->post("page_content1"));
		$arr["image"] = $_FILES["userfile"]["name"];
		$arr["page_status"] = 1;
		
		if($arr["image"] != "")
		{
			$arr["image"] = time().".".$this->common->get_extension($_FILES["userfile"]["name"]);
		}
		else
		{
			$arr["image"] = $this->input->post("image");	
		}
		//echo "<pre>"; 
		//print_r($arr);die;
		if($this->validations->validate_contact_us($arr))
		{
			if($this->page_model->update_contact_data($arr))
			{
				if($arr["image"] != $this->input->post("image"))
				{
					$config['upload_path'] = '../uploads/';
					$config['allowed_types'] = '*';
					$config['file_name'] = $arr["image"];
					$this->upload->initialize($config);
					if($this->upload->do_upload()){
						$err=0;
					}		
					else {
						//echo $this->upload->display_errors();die;
						$this->session->set_flashdata("successmsg","There is some error uploading the files to server. Please contact server admin");		
					}		
				}
				$this->session->set_flashdata("successmsg","Contact us updated successffuly");
				$err=0;
			}
			else
			{
				$this->session->set_flashdata("errormsg","There is error editing contact us page . Please contact database admin");
				$err=1;
			}
		}
		else
		{
			redirect(base_url()."pages/manage_page/contact/edit");
			$err=1;	
		}
		redirect(base_url()."pages/manage_page/contact/edit");
	}
//update about us data
	public function update_aboutus_to_database()
	{
		$arr["page_content"] = trim($this->input->post("page_content"));
		$arr["page_name"] = trim($this->input->post("page_name"));
		//print_r($arr);die;
		if($this->validations->validate_aboutus($arr))
		{
			
			if($this->page_model->update_aboutus_to_database($arr))
			{
				$this->session->set_flashdata("successmsg","about us updated successffuly");
				$err=0;
			}
			else
			{
				$this->session->set_flashdata("errormsg","there was a problem updating about us ");
				$err=1;	
			}
		}
		else
		{
			
			$err=1;	
		}
		redirect(base_url()."pages/manage_page/about_us/edit");	
	}
	//partner content for admin
	public function update_parnter_to_database()
	{
		$arr["page_content"] = trim($this->input->post("page_content"));
		$arr["page_name"] = trim($this->input->post("page_name"));
		if($this->validations->validate_aboutus($arr))
		{
			
			if($this->page_model->update_aboutus_to_database($arr))
			{
				$this->session->set_flashdata("successmsg","partner updated successffuly");
				$err=0;
			}
			else
			{
				$this->session->set_flashdata("errormsg","there was a problem updating partner");
				$err=1;	
			}
		}
		else
		{
			redirect(base_url()."pages/manage_page/partners/edit");
			$err=1;	
		}
		redirect(base_url()."pages/manage_page/partners/edit");	
	}
	//food club content for admin
	public function update_club_to_database()
	{
		$arr["page_title"] = trim($this->input->post("page_title"));
		$arr["page_content"] = trim($this->input->post("page_content"));
		$arr["page_name"] = trim($this->input->post("page_name"));
		if($this->validations->validate_foodclub($arr))
		{
			
			if($this->page_model->update_aboutus_to_database($arr))
			{
				$this->session->set_flashdata("successmsg","club updated successffuly");
				$err=0;
			}
			else
			{
				$this->session->set_flashdata("errormsg","there was a problem updating club content");
				$err=1;	
			}
		}
		else
		{
			redirect(base_url()."pages/manage_page/food_club/edit");
			$err=1;	
		}
		redirect(base_url()."pages/manage_page/food_club/edit");	
	}
	
	/*public function update_contact_information()
	{
		$arr["contact_number"]=$this->input->post("contact_number");
		$arr["contact_email"]=$this->input->post("contact_email");
		$arr["contact_fax"]=$this->input->post("contact_fax");	
		if($this->validations->validate_contact_information($arr))
		{
			if($this->page_model->update_contact_information($arr))
			{
				$this->session->set_flashdata("successmsg","Contact Information updated successffuly");
				$err=0;
			}
			else
			{
				$err=1;	
			}
		}
		else
		{
			$err=1;	
		}
		redirect(base_url()."pages/manage_page/contact_info");	
	}*/
	public function get_image_Extension($imagename)
	{
		$imagename=explode(".",$imagename);
		return $imagename[1];
	}

	public function upload_images()
	{
		$config['upload_path'] = '../ckeditorimages/';
		$config['allowed_types'] = '*';
		$config['file_name']=$_FILES['upload']['name'];
		$this->upload->initialize($config);
		$validimages=array("jpg","gif","png","jpeg","bmp");
		if(in_array($this->get_image_Extension($_FILES['upload']['name']),$validimages))
		{
			if($this->upload->do_upload('upload'))
			{
				$arr=$this->upload->data();
				$url = $this->config->item("ckeditorimages").$arr['file_name'];
			}
			else
			{
				$message = "Error moving uploaded file. Check the script is granted Read/Write/Modify permissions.";	
			}
		}
		else
		{
			$message = "Only images file with ".implode(",",$validimages)." extensions are allowed";	
		}
		 $funcNum = $_GET['CKEditorFuncNum'] ;
		echo "<script type='text/javascript'>window.parent.CKEDITOR.tools.callFunction($funcNum, '$url', '$message');</script>";
	}
	/**********************************************************Page functions starts ************************************************/
}

?>