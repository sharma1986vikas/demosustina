
<div class="sidebar-nav"> <a href="<?php echo base_url();?>/dashboard" class="nav-header" ><i class="icon-dashboard"></i>Dashboard</a> <a href="#user" class="nav-header collapsed" data-toggle="collapse"><i class="icon-dashboard"></i>Manage Users<i class="icon-chevron-up"></i></a>
  <ul id="user" class="nav nav-list collapse">
    <li ><a href="<?php echo base_url();?>users/manage_user">Users</a></li>
  </ul>
  
  <!--<a href="#srores" class="nav-header collapsed" data-toggle="collapse"><i class="icon-dashboard"></i>Manage Store<i class="icon-chevron-up"></i></a>
         <ul id="srores" class="nav nav-list collapse">
            <li ><a href="<?php echo base_url();?>stores/manage_store">Stores</a></li>
            
          </ul>
          --> 
  <a href="#bag" class="nav-header collapsed" data-toggle="collapse"><i class="icon-briefcase"></i>Request a bag<i class="icon-chevron-up"></i><span class="label label-info">+3</span></a>
  <ul id="bag" class="nav nav-list collapse">
    <li ><a href="<?php echo base_url();?>products/manage_sell_cloth">Request a bag</a></li>
  </ul>
  <a href="#accounts-menu" class="nav-header collapsed" data-toggle="collapse"><i class="icon-briefcase"></i>Manage Products<i class="icon-chevron-up"></i><span class="label label-info">+3</span></a>
  <ul id="accounts-menu" class="nav nav-list collapse">
    <li ><a href="<?php echo base_url();?>products/manage_category">Categories</a></li>
    <li ><a href="<?php echo base_url();?>products/manage_sub_category">SubCategories</a></li>
    <li ><a href="<?php echo base_url();?>products/manage_attribute">Attributes</a></li>
    <li ><a href="<?php echo base_url();?>products/manage_brand">Brands</a></li>
    <li ><a href="<?php echo base_url();?>products/manage_price">Price</a></li>
    <li ><a href="<?php echo base_url();?>products/manage_product">Products</a></li>
  </ul>
  <a href="<?php echo base_url();?>orders/manage_order" class="nav-header collapsed" ><i class="icon-briefcase"></i>Manage Orders<i class="icon-chevron-up"></i><span class="label label-info">+3</span></a> <a href="#Withdrawls" class="nav-header collapsed" data-toggle="collapse"><i class="icon-legal"></i>Withdrawls<i class="icon-chevron-up"></i><span class="label label-info">+3</span></a>
  <ul id="Withdrawls" class="nav nav-list collapse">
    <li ><a href="<?php echo base_url();?>withdrawl/manage_tier_withdrawl">User Withdrawls</a></li>
    <li ><a href="<?php echo base_url();?>withdrawl/manage_withdrawl">Stores Withdrawls</a></li>
  </ul>
  <a href="#configuration" class="nav-header collapsed" data-toggle="collapse"><i class="icon-briefcase"></i>Configuration<i class="icon-chevron-up"></i><span class="label label-info">+3</span></a>
  <ul id="configuration" class="nav nav-list collapse">
    <li ><a href="<?php echo base_url();?>slideshow/manage_slideshow">Slideshow</a></li>
    <li ><a href="<?php echo base_url();?>pages/manage_page/information">Information</a></li>
  </ul>
   <a href="#friend" class="nav-header collapsed" data-toggle="collapse"><i class="icon-briefcase"></i>Invite friend<i class="icon-chevron-up"></i><span class="label label-info">+3</span></a>
  <ul id="friend" class="nav nav-list collapse">
    <li ><a href="<?php echo base_url();?>products/manage_invite_friend">Invite friend</a></li>
  </ul>
  <!--           <a href="help.html" class="nav-header" ><i class="icon-question-sign"></i>Help</a>
        <a href="faq.html" class="nav-header" ><i class="icon-comment"></i>Faq</a>
--> </div>
